
  # AgriVault Mobile App Prototype

  This is a code bundle for AgriVault Mobile App Prototype. The original project is available at https://www.figma.com/design/XYp63vtN8iZIyujcbVOZvh/AgriVault-Mobile-App-Prototype.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  