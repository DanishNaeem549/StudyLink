import { Users, Warehouse, Truck, GraduationCap, TrendingUp, AlertCircle, CheckCircle2 } from 'lucide-react';
import { Button } from '../ui/button';

interface AdminDashboardProps {
  onLogout: () => void;
}

export default function AdminDashboard({ onLogout }: AdminDashboardProps) {
  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <div className="bg-gradient-to-r from-gray-700 to-gray-800 text-white p-6">
        <h2 className="text-2xl mb-1">Admin Dashboard</h2>
        <p className="text-white/80 text-sm">AgriVault Platform Management</p>
      </div>

      <div className="p-4 space-y-4">
        {/* User Stats */}
        <div className="grid grid-cols-2 gap-3">
          <div className="bg-white rounded-2xl p-4">
            <Users className="w-6 h-6 text-green-500 mb-2" />
            <p className="text-2xl text-gray-800 mb-1">2,450</p>
            <p className="text-sm text-gray-600">Farmers</p>
          </div>

          <div className="bg-white rounded-2xl p-4">
            <Warehouse className="w-6 h-6 text-purple-500 mb-2" />
            <p className="text-2xl text-gray-800 mb-1">125</p>
            <p className="text-sm text-gray-600">Storage Owners</p>
          </div>

          <div className="bg-white rounded-2xl p-4">
            <Truck className="w-6 h-6 text-orange-500 mb-2" />
            <p className="text-2xl text-gray-800 mb-1">380</p>
            <p className="text-sm text-gray-600">Transporters</p>
          </div>

          <div className="bg-white rounded-2xl p-4">
            <GraduationCap className="w-6 h-6 text-blue-500 mb-2" />
            <p className="text-2xl text-gray-800 mb-1">45</p>
            <p className="text-sm text-gray-600">Experts</p>
          </div>
        </div>

        {/* Platform Stats */}
        <div className="bg-gradient-to-r from-[#1E7F43] to-[#15593A] text-white rounded-2xl p-5">
          <h3 className="text-lg mb-4">Platform Performance</h3>
          <div className="grid grid-cols-2 gap-4">
            <div>
              <p className="text-white/80 text-sm mb-1">Total Bookings</p>
              <p className="text-3xl">3,240</p>
            </div>
            <div>
              <p className="text-white/80 text-sm mb-1">Revenue</p>
              <p className="text-3xl">₨2.4M</p>
            </div>
          </div>
        </div>

        {/* Pending Approvals */}
        <div className="bg-white rounded-2xl p-5">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-gray-800">Pending Approvals</h3>
            <span className="bg-orange-100 text-orange-700 px-2 py-1 rounded-full text-xs">8 new</span>
          </div>
          <div className="space-y-3">
            <div className="flex items-center justify-between p-3 bg-orange-50 rounded-xl">
              <div className="flex items-center gap-3">
                <Warehouse className="w-5 h-5 text-purple-500" />
                <div>
                  <p className="text-sm text-gray-800">New Storage Listing</p>
                  <p className="text-xs text-gray-500">FarmFresh Hub, Multan</p>
                </div>
              </div>
              <div className="flex gap-2">
                <button className="p-2 bg-green-500 text-white rounded-lg">
                  <CheckCircle2 className="w-4 h-4" />
                </button>
                <button className="p-2 bg-red-500 text-white rounded-lg">
                  <AlertCircle className="w-4 h-4" />
                </button>
              </div>
            </div>

            <div className="flex items-center justify-between p-3 bg-orange-50 rounded-xl">
              <div className="flex items-center gap-3">
                <Truck className="w-5 h-5 text-orange-500" />
                <div>
                  <p className="text-sm text-gray-800">New Transporter</p>
                  <p className="text-xs text-gray-500">Bilal Transport, Lahore</p>
                </div>
              </div>
              <div className="flex gap-2">
                <button className="p-2 bg-green-500 text-white rounded-lg">
                  <CheckCircle2 className="w-4 h-4" />
                </button>
                <button className="p-2 bg-red-500 text-white rounded-lg">
                  <AlertCircle className="w-4 h-4" />
                </button>
              </div>
            </div>
          </div>
        </div>

        {/* Analytics */}
        <div className="bg-white rounded-2xl p-5">
          <h3 className="text-gray-800 mb-4">System Analytics</h3>
          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <span className="text-gray-600 text-sm">Active Users (24h)</span>
              <span className="text-gray-800">1,245</span>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-gray-600 text-sm">New Registrations</span>
              <span className="text-gray-800">+45</span>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-gray-600 text-sm">Completed Bookings</span>
              <span className="text-gray-800">28</span>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-gray-600 text-sm">Total Loss Prevented</span>
              <span className="text-green-600">₨450K</span>
            </div>
          </div>
        </div>

        {/* Quick Actions */}
        <div className="grid grid-cols-2 gap-3">
          <button className="bg-blue-500 text-white rounded-2xl p-5 text-left hover:shadow-lg transition-shadow">
            <Users className="w-6 h-6 mb-2" />
            <p className="text-sm">Manage Users</p>
          </button>
          <button className="bg-purple-500 text-white rounded-2xl p-5 text-left hover:shadow-lg transition-shadow">
            <TrendingUp className="w-6 h-6 mb-2" />
            <p className="text-sm">View Reports</p>
          </button>
        </div>

        <Button onClick={onLogout} variant="destructive" className="w-full">
          Logout
        </Button>
      </div>
    </div>
  );
}
