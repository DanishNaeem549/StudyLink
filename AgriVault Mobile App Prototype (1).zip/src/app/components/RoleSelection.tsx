import { UserRole } from '../App';
import { Tractor, Warehouse, Truck, GraduationCap, ShieldCheck } from 'lucide-react';
import { motion } from 'motion/react';

interface RoleSelectionProps {
  onSelectRole: (role: UserRole) => void;
}

export default function RoleSelection({ onSelectRole }: RoleSelectionProps) {
  const roles = [
    {
      id: 'farmer' as UserRole,
      icon: Tractor,
      title: 'Farmer',
      description: 'Manage crops, storage & market',
      color: 'from-green-500 to-green-600'
    },
    {
      id: 'supplier' as UserRole,
      icon: Warehouse,
      title: 'Input Supplier',
      description: 'Sell seeds, fertilizers & tools',
      color: 'from-emerald-500 to-emerald-600'
    },
    {
      id: 'buyer' as UserRole,
      icon: ShieldCheck,
      title: 'Crop Buyer',
      description: 'Purchase crops & inputs',
      color: 'from-teal-500 to-teal-600'
    },
    {
      id: 'storage' as UserRole,
      icon: Warehouse,
      title: 'Cold Storage Owner',
      description: 'Manage capacity & bookings',
      color: 'from-blue-500 to-blue-600'
    },
    {
      id: 'transporter' as UserRole,
      icon: Truck,
      title: 'Transport Provider',
      description: 'Accept transport requests',
      color: 'from-orange-500 to-orange-600'
    },
    {
      id: 'expert' as UserRole,
      icon: GraduationCap,
      title: 'Agriculture Expert',
      description: 'Provide expert advice',
      color: 'from-purple-500 to-purple-600'
    },
    {
      id: 'admin' as UserRole,
      icon: ShieldCheck,
      title: 'Admin',
      description: 'Manage platform & users',
      color: 'from-gray-700 to-gray-800'
    }
  ];

  return (
    <div 
      className="min-h-screen p-6 flex flex-col"
      style={{
        backgroundImage: 'linear-gradient(to bottom, rgba(255, 255, 255, 0.95), rgba(249, 250, 251, 0.98)), url(https://images.unsplash.com/photo-1625246333195-78d9c38ad449?w=1200)',
        backgroundSize: 'cover',
        backgroundPosition: 'center'
      }}
    >
      <motion.div 
        className="text-center mb-8 mt-8"
        initial={{ y: -20, opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
      >
        <h1 className="text-[#1E7F43] text-3xl mb-2">Welcome to AgriVault</h1>
        <p className="text-gray-600">Select your role to continue</p>
      </motion.div>

      <div className="flex-1 flex flex-col gap-4 max-w-md mx-auto w-full">
        {roles.map((role, index) => {
          const Icon = role.icon;
          return (
            <motion.button
              key={role.id}
              className={`bg-gradient-to-r ${role.color} text-white rounded-2xl p-6 flex items-center gap-4 shadow-lg hover:shadow-xl transition-shadow active:scale-95`}
              onClick={() => onSelectRole(role.id)}
              initial={{ x: -50, opacity: 0 }}
              animate={{ x: 0, opacity: 1 }}
              transition={{ delay: index * 0.1 }}
              whileHover={{ scale: 1.02 }}
              whileTap={{ scale: 0.98 }}
            >
              <div className="bg-white/20 rounded-xl p-3">
                <Icon className="w-8 h-8" />
              </div>
              <div className="flex-1 text-left">
                <h3 className="text-xl mb-1">{role.title}</h3>
                <p className="text-white/80 text-sm">{role.description}</p>
              </div>
            </motion.button>
          );
        })}
      </div>

      <p className="text-center text-gray-500 text-sm mt-8">
        Powered by AgriVault • Pakistan's First Post-Harvest Platform
      </p>
    </div>
  );
}