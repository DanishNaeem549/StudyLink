import { useState } from 'react';
import { Warehouse, MapPin, Star, Phone, Clock, Thermometer, Package, Calendar, CreditCard, CheckCircle2, ArrowLeft } from 'lucide-react';
import { Button } from '../ui/button';
import { Input } from '../ui/input';

type View = 'list' | 'detail' | 'booking' | 'confirmation';

interface Storage {
  id: number;
  name: string;
  distance: string;
  price: number;
  rating: number;
  capacity: string;
  available: string;
  temp: string;
  image: string;
  address: string;
  features: string[];
}

export default function StorageModule() {
  const [view, setView] = useState<View>('list');
  const [selectedStorage, setSelectedStorage] = useState<Storage | null>(null);
  const [bookingData, setBookingData] = useState({
    quantity: '',
    duration: '',
    grade: 'A',
    packaging: 'Crate'
  });

  const storages: Storage[] = [
    {
      id: 1,
      name: 'Green Valley Cold Storage',
      distance: '3.2 km',
      price: 8,
      rating: 4.8,
      capacity: '500 tons',
      available: '200 tons',
      temp: '2-4°C',
      image: '🏭',
      address: 'GT Road, Lahore',
      features: ['24/7 Monitoring', 'Grading Service', 'Packaging', 'Transport Support']
    },
    {
      id: 2,
      name: 'Premium Agri Hub',
      distance: '5.0 km',
      price: 10,
      rating: 4.9,
      capacity: '800 tons',
      available: '350 tons',
      temp: '0-4°C',
      image: '🏢',
      address: 'Multan Road, Lahore',
      features: ['Advanced Climate Control', 'Quality Certification', 'Direct Market Access', 'Insurance']
    },
    {
      id: 3,
      name: 'FarmFresh Storage',
      distance: '7.5 km',
      price: 7,
      rating: 4.6,
      capacity: '300 tons',
      available: '150 tons',
      temp: '2-5°C',
      image: '🏪',
      address: 'Ferozepur Road, Lahore',
      features: ['Affordable Rates', 'Flexible Duration', 'Pickup Service']
    }
  ];

  const handleViewDetail = (storage: Storage) => {
    setSelectedStorage(storage);
    setView('detail');
  };

  const handleStartBooking = () => {
    setView('booking');
  };

  const handleConfirmBooking = () => {
    setView('confirmation');
  };

  const calculateTotal = () => {
    const qty = parseInt(bookingData.quantity) || 0;
    const days = parseInt(bookingData.duration) || 0;
    const storagePrice = selectedStorage?.price || 0;
    const gradingFee = bookingData.grade !== 'C' ? 2 : 0;
    const packagingFee = bookingData.packaging === 'Crate' ? 5 : bookingData.packaging === 'Box' ? 3 : 1;
    
    return {
      storage: qty * days * storagePrice,
      grading: qty * gradingFee,
      packaging: qty * packagingFee,
      total: (qty * days * storagePrice) + (qty * gradingFee) + (qty * packagingFee)
    };
  };

  // Confirmation View
  if (view === 'confirmation') {
    const total = calculateTotal();
    return (
      <div className="min-h-screen bg-gray-50 p-4 flex flex-col items-center justify-center">
        <div className="bg-white rounded-3xl p-8 max-w-md w-full text-center">
          <div className="bg-green-100 rounded-full w-20 h-20 flex items-center justify-center mx-auto mb-6">
            <CheckCircle2 className="w-12 h-12 text-green-600" />
          </div>
          <h2 className="text-2xl text-gray-800 mb-2">Booking Confirmed!</h2>
          <p className="text-gray-600 mb-6">Your storage has been successfully booked</p>
          
          <div className="bg-gray-50 rounded-2xl p-5 mb-6 text-left">
            <div className="flex justify-between mb-3">
              <span className="text-gray-600">Booking ID</span>
              <span className="text-gray-800">#AV-{Date.now().toString().slice(-6)}</span>
            </div>
            <div className="flex justify-between mb-3">
              <span className="text-gray-600">Storage</span>
              <span className="text-gray-800">{selectedStorage?.name}</span>
            </div>
            <div className="flex justify-between mb-3">
              <span className="text-gray-600">Quantity</span>
              <span className="text-gray-800">{bookingData.quantity} kg</span>
            </div>
            <div className="flex justify-between mb-3">
              <span className="text-gray-600">Duration</span>
              <span className="text-gray-800">{bookingData.duration} days</span>
            </div>
            <div className="flex justify-between pt-3 border-t-2 border-gray-200">
              <span className="text-gray-800">Total Amount</span>
              <span className="text-gray-800 text-xl">₨{total.total}</span>
            </div>
          </div>

          <Button 
            onClick={() => setView('list')}
            className="w-full h-12 bg-[#1E7F43] hover:bg-[#15593A]"
          >
            Back to Storage List
          </Button>
        </div>
      </div>
    );
  }

  // Booking Form View
  if (view === 'booking' && selectedStorage) {
    const total = calculateTotal();
    return (
      <div className="p-4 space-y-4">
        <div className="flex items-center gap-3 mb-4">
          <button onClick={() => setView('detail')} className="text-[#1E7F43]">
            <ArrowLeft className="w-6 h-6" />
          </button>
          <h2 className="text-gray-800 text-xl">Complete Booking</h2>
        </div>

        {/* Storage Summary */}
        <div className="bg-white rounded-2xl p-4 border-2 border-gray-200">
          <div className="flex items-center gap-3">
            <span className="text-4xl">{selectedStorage.image}</span>
            <div className="flex-1">
              <h3 className="text-gray-800">{selectedStorage.name}</h3>
              <p className="text-sm text-gray-500">₨{selectedStorage.price}/kg per day</p>
            </div>
          </div>
        </div>

        {/* Booking Details */}
        <div className="bg-white rounded-2xl p-5">
          <h3 className="text-gray-800 mb-4">Booking Details</h3>
          
          <div className="space-y-4">
            <div>
              <label className="block text-gray-700 mb-2 text-sm">Quantity (kg)</label>
              <Input
                type="number"
                placeholder="Enter quantity"
                value={bookingData.quantity}
                onChange={(e) => setBookingData({...bookingData, quantity: e.target.value})}
                className="h-12 rounded-xl"
              />
            </div>

            <div>
              <label className="block text-gray-700 mb-2 text-sm">Duration (days)</label>
              <Input
                type="number"
                placeholder="Enter duration"
                value={bookingData.duration}
                onChange={(e) => setBookingData({...bookingData, duration: e.target.value})}
                className="h-12 rounded-xl"
              />
            </div>

            <div>
              <label className="block text-gray-700 mb-2 text-sm">Grade Selection</label>
              <div className="grid grid-cols-3 gap-2">
                {['A', 'B', 'C'].map((grade) => (
                  <button
                    key={grade}
                    onClick={() => setBookingData({...bookingData, grade})}
                    className={`py-3 rounded-xl border-2 transition-all ${
                      bookingData.grade === grade
                        ? 'border-[#1E7F43] bg-green-50 text-[#1E7F43]'
                        : 'border-gray-200 text-gray-600'
                    }`}
                  >
                    Grade {grade}
                  </button>
                ))}
              </div>
              <p className="text-xs text-gray-500 mt-2">
                Grade A: Premium quality • Grade B: Standard • Grade C: Basic
              </p>
            </div>

            <div>
              <label className="block text-gray-700 mb-2 text-sm">Packaging Type</label>
              <div className="grid grid-cols-3 gap-2">
                {['Crate', 'Box', 'Sack'].map((pkg) => (
                  <button
                    key={pkg}
                    onClick={() => setBookingData({...bookingData, packaging: pkg})}
                    className={`py-3 rounded-xl border-2 transition-all ${
                      bookingData.packaging === pkg
                        ? 'border-[#1E7F43] bg-green-50 text-[#1E7F43]'
                        : 'border-gray-200 text-gray-600'
                    }`}
                  >
                    {pkg}
                  </button>
                ))}
              </div>
            </div>
          </div>
        </div>

        {/* Price Breakdown */}
        <div className="bg-white rounded-2xl p-5">
          <h3 className="text-gray-800 mb-4">Price Breakdown</h3>
          <div className="space-y-3">
            <div className="flex justify-between text-gray-600">
              <span>Storage ({bookingData.quantity || 0} kg × {bookingData.duration || 0} days × ₨{selectedStorage.price})</span>
              <span>₨{total.storage}</span>
            </div>
            <div className="flex justify-between text-gray-600">
              <span>Grading Service</span>
              <span>₨{total.grading}</span>
            </div>
            <div className="flex justify-between text-gray-600">
              <span>Packaging ({bookingData.packaging})</span>
              <span>₨{total.packaging}</span>
            </div>
            <div className="pt-3 border-t-2 border-gray-200 flex justify-between">
              <span className="text-gray-800">Total Amount</span>
              <span className="text-gray-800 text-2xl">₨{total.total}</span>
            </div>
          </div>
        </div>

        {/* Payment Method */}
        <div className="bg-white rounded-2xl p-5">
          <h3 className="text-gray-800 mb-4">Payment Method</h3>
          <div className="space-y-2">
            <div className="flex items-center justify-between p-4 border-2 border-[#1E7F43] bg-green-50 rounded-xl">
              <div className="flex items-center gap-3">
                <CreditCard className="w-5 h-5 text-[#1E7F43]" />
                <span className="text-gray-800">Cash on Delivery</span>
              </div>
              <div className="w-5 h-5 rounded-full bg-[#1E7F43] flex items-center justify-center">
                <div className="w-2 h-2 rounded-full bg-white"></div>
              </div>
            </div>
          </div>
        </div>

        <Button 
          onClick={handleConfirmBooking}
          className="w-full h-14 bg-[#1E7F43] hover:bg-[#15593A] text-lg"
          disabled={!bookingData.quantity || !bookingData.duration}
        >
          Confirm Booking - ₨{total.total}
        </Button>
      </div>
    );
  }

  // Detail View
  if (view === 'detail' && selectedStorage) {
    return (
      <div className="space-y-4">
        <div className="bg-gradient-to-br from-[#1E7F43] to-[#15593A] text-white p-6">
          <button onClick={() => setView('list')} className="mb-4 flex items-center gap-2">
            <ArrowLeft className="w-5 h-5" />
            <span>Back</span>
          </button>
          <div className="flex items-start justify-between">
            <div>
              <span className="text-6xl block mb-3">{selectedStorage.image}</span>
              <h2 className="text-2xl mb-2">{selectedStorage.name}</h2>
              <p className="text-white/80 text-sm flex items-center gap-2">
                <MapPin className="w-4 h-4" />
                {selectedStorage.address}
              </p>
            </div>
          </div>
        </div>

        <div className="p-4 space-y-4">
          {/* Quick Info */}
          <div className="grid grid-cols-2 gap-3">
            <div className="bg-white rounded-2xl p-4 text-center">
              <Star className="w-6 h-6 text-yellow-500 mx-auto mb-2" />
              <p className="text-2xl text-gray-800 mb-1">{selectedStorage.rating}</p>
              <p className="text-sm text-gray-600">Rating</p>
            </div>
            <div className="bg-white rounded-2xl p-4 text-center">
              <MapPin className="w-6 h-6 text-blue-500 mx-auto mb-2" />
              <p className="text-2xl text-gray-800 mb-1">{selectedStorage.distance}</p>
              <p className="text-sm text-gray-600">Distance</p>
            </div>
          </div>

          {/* Pricing */}
          <div className="bg-gradient-to-r from-purple-500 to-purple-600 text-white rounded-2xl p-5">
            <h3 className="text-lg mb-3">Pricing</h3>
            <div className="flex items-end gap-2">
              <span className="text-4xl">₨{selectedStorage.price}</span>
              <span className="text-lg text-white/80 mb-1">/kg per day</span>
            </div>
          </div>

          {/* Details */}
          <div className="bg-white rounded-2xl p-5 space-y-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <Thermometer className="w-5 h-5 text-blue-500" />
                <span className="text-gray-800">Temperature</span>
              </div>
              <span className="text-gray-600">{selectedStorage.temp}</span>
            </div>
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <Warehouse className="w-5 h-5 text-purple-500" />
                <span className="text-gray-800">Total Capacity</span>
              </div>
              <span className="text-gray-600">{selectedStorage.capacity}</span>
            </div>
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <Package className="w-5 h-5 text-green-500" />
                <span className="text-gray-800">Available</span>
              </div>
              <span className="text-green-600">{selectedStorage.available}</span>
            </div>
          </div>

          {/* Features */}
          <div className="bg-white rounded-2xl p-5">
            <h3 className="text-gray-800 mb-3">Features & Services</h3>
            <div className="grid grid-cols-2 gap-2">
              {selectedStorage.features.map((feature, idx) => (
                <div key={idx} className="flex items-center gap-2 text-sm text-gray-700">
                  <CheckCircle2 className="w-4 h-4 text-green-500 flex-shrink-0" />
                  <span>{feature}</span>
                </div>
              ))}
            </div>
          </div>

          {/* Contact */}
          <div className="bg-white rounded-2xl p-5">
            <h3 className="text-gray-800 mb-3">Contact</h3>
            <div className="flex gap-2">
              <Button variant="outline" className="flex-1 h-12">
                <Phone className="w-4 h-4 mr-2" />
                Call Now
              </Button>
              <Button variant="outline" className="flex-1 h-12">
                <Clock className="w-4 h-4 mr-2" />
                Hours
              </Button>
            </div>
          </div>

          <Button 
            onClick={handleStartBooking}
            className="w-full h-14 bg-[#1E7F43] hover:bg-[#15593A] text-lg"
          >
            Book Now
          </Button>
        </div>
      </div>
    );
  }

  // List View
  return (
    <div className="p-4 space-y-4">
      <div>
        <h2 className="text-gray-800 text-xl mb-1">ThandaHub Storage</h2>
        <p className="text-gray-600 text-sm">Find nearby cold storage facilities</p>
      </div>

      {/* Filters */}
      <div className="flex gap-2 overflow-x-auto pb-2">
        <button className="px-4 py-2 bg-[#1E7F43] text-white rounded-full text-sm whitespace-nowrap">
          All
        </button>
        <button className="px-4 py-2 bg-white text-gray-700 rounded-full text-sm whitespace-nowrap border border-gray-300">
          Nearest
        </button>
        <button className="px-4 py-2 bg-white text-gray-700 rounded-full text-sm whitespace-nowrap border border-gray-300">
          Best Price
        </button>
        <button className="px-4 py-2 bg-white text-gray-700 rounded-full text-sm whitespace-nowrap border border-gray-300">
          High Rated
        </button>
      </div>

      {/* Storage List */}
      <div className="space-y-3">
        {storages.map((storage) => (
          <div 
            key={storage.id}
            onClick={() => handleViewDetail(storage)}
            className="bg-white rounded-2xl p-4 border-2 border-gray-200 hover:border-[#1E7F43] hover:shadow-md transition-all cursor-pointer"
          >
            <div className="flex gap-4">
              <div className="text-5xl">{storage.image}</div>
              <div className="flex-1">
                <h3 className="text-gray-800 mb-1">{storage.name}</h3>
                <div className="flex items-center gap-3 text-sm text-gray-600 mb-2">
                  <span className="flex items-center gap-1">
                    <MapPin className="w-4 h-4" />
                    {storage.distance}
                  </span>
                  <span className="flex items-center gap-1">
                    <Star className="w-4 h-4 text-yellow-500 fill-yellow-500" />
                    {storage.rating}
                  </span>
                </div>
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-gray-500">Available: {storage.available}</p>
                  </div>
                  <div className="text-right">
                    <p className="text-[#1E7F43] text-xl">₨{storage.price}</p>
                    <p className="text-xs text-gray-500">/kg per day</p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* My Bookings */}
      <div className="bg-white rounded-2xl p-5">
        <div className="flex items-center justify-between mb-4">
          <h3 className="text-gray-800">My Bookings</h3>
          <button className="text-[#1E7F43] text-sm">View All</button>
        </div>
        <div className="bg-gray-50 rounded-xl p-4">
          <div className="flex items-center justify-between mb-2">
            <span className="text-gray-800">Green Valley Cold Storage</span>
            <span className="bg-green-100 text-green-700 px-2 py-1 rounded-full text-xs">Active</span>
          </div>
          <div className="grid grid-cols-2 gap-2 text-sm text-gray-600">
            <span>Quantity: 500 kg</span>
            <span>Days left: 12</span>
          </div>
        </div>
      </div>
    </div>
  );
}
