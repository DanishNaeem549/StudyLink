import { AlertTriangle, CloudRain, Thermometer, TrendingUp, Warehouse, Bell } from 'lucide-react';

export default function AlertsModule() {
  const alerts = [
    {
      id: 1,
      type: 'critical',
      icon: AlertTriangle,
      title: 'High Spoilage Risk',
      message: 'Heatwave expected in 48 hours. Book cold storage now to prevent 30% crop loss!',
      time: '2 hours ago',
      action: 'Book Storage'
    },
    {
      id: 2,
      type: 'warning',
      icon: CloudRain,
      title: 'Heavy Rain Expected',
      message: 'Rain forecast for Friday. Complete harvesting before rainfall to avoid crop damage.',
      time: '5 hours ago',
      action: 'View Weather'
    },
    {
      id: 3,
      type: 'success',
      icon: TrendingUp,
      title: 'Price Increase Alert',
      message: 'Tomato prices increased by 12%. Excellent time to sell in Lahore Mandi!',
      time: '1 day ago',
      action: 'Check Prices'
    },
    {
      id: 4,
      type: 'info',
      icon: Warehouse,
      title: 'Storage Availability',
      message: 'New cold storage facility opened 3km from your location at ₨7/kg per day.',
      time: '2 days ago',
      action: 'View Details'
    },
    {
      id: 5,
      type: 'warning',
      icon: Thermometer,
      title: 'Frost Warning',
      message: 'Temperature may drop below 5°C tonight. Protect sensitive crops.',
      time: '3 days ago',
      action: 'View Advisory'
    }
  ];

  const getAlertColor = (type: string) => {
    switch (type) {
      case 'critical':
        return 'from-red-500 to-red-600';
      case 'warning':
        return 'from-orange-500 to-orange-600';
      case 'success':
        return 'from-green-500 to-green-600';
      default:
        return 'from-blue-500 to-blue-600';
    }
  };

  const getAlertBg = (type: string) => {
    switch (type) {
      case 'critical':
        return 'bg-red-50 border-red-300';
      case 'warning':
        return 'bg-orange-50 border-orange-300';
      case 'success':
        return 'bg-green-50 border-green-300';
      default:
        return 'bg-blue-50 border-blue-300';
    }
  };

  return (
    <div className="p-4 space-y-4">
      <div>
        <h2 className="text-gray-800 text-xl mb-1">Risk Alerts</h2>
        <p className="text-gray-600 text-sm">Stay informed about harvest risks</p>
      </div>

      {/* Notification Settings */}
      <div className="bg-gradient-to-r from-[#1E7F43] to-[#15593A] text-white rounded-2xl p-5">
        <div className="flex items-center gap-3 mb-3">
          <Bell className="w-6 h-6" />
          <div className="flex-1">
            <h3 className="text-lg">Push Notifications</h3>
            <p className="text-white/80 text-sm">Get real-time alerts</p>
          </div>
          <div className="bg-white rounded-full w-12 h-6 flex items-center px-1 cursor-pointer">
            <div className="bg-[#1E7F43] rounded-full w-5 h-5 ml-auto"></div>
          </div>
        </div>
      </div>

      {/* Alert Categories */}
      <div className="flex gap-2 overflow-x-auto pb-2">
        <button className="px-4 py-2 bg-[#1E7F43] text-white rounded-full text-sm whitespace-nowrap">
          All (5)
        </button>
        <button className="px-4 py-2 bg-white text-gray-700 rounded-full text-sm whitespace-nowrap border border-gray-300">
          Critical (1)
        </button>
        <button className="px-4 py-2 bg-white text-gray-700 rounded-full text-sm whitespace-nowrap border border-gray-300">
          Weather (2)
        </button>
        <button className="px-4 py-2 bg-white text-gray-700 rounded-full text-sm whitespace-nowrap border border-gray-300">
          Market (1)
        </button>
      </div>

      {/* Alerts List */}
      <div className="space-y-3">
        {alerts.map((alert) => {
          const Icon = alert.icon;
          return (
            <div 
              key={alert.id}
              className={`${getAlertBg(alert.type)} rounded-2xl p-4 border-2`}
            >
              <div className="flex gap-3">
                <div className={`bg-gradient-to-br ${getAlertColor(alert.type)} rounded-full w-12 h-12 flex items-center justify-center flex-shrink-0`}>
                  <Icon className="w-6 h-6 text-white" />
                </div>
                <div className="flex-1">
                  <div className="flex items-start justify-between mb-2">
                    <h3 className="text-gray-800">{alert.title}</h3>
                    <span className="text-xs text-gray-500">{alert.time}</span>
                  </div>
                  <p className="text-sm text-gray-700 mb-3">{alert.message}</p>
                  <button className={`bg-gradient-to-r ${getAlertColor(alert.type)} text-white px-4 py-2 rounded-full text-sm hover:shadow-md transition-shadow`}>
                    {alert.action}
                  </button>
                </div>
              </div>
            </div>
          );
        })}
      </div>

      {/* Alert Preferences */}
      <div className="bg-white rounded-2xl p-5">
        <h3 className="text-gray-800 mb-4">Alert Preferences</h3>
        <div className="space-y-3">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-gray-800 text-sm">Weather Warnings</p>
              <p className="text-xs text-gray-500">Frost, heatwave, rain alerts</p>
            </div>
            <div className="bg-green-500 rounded-full w-12 h-6 flex items-center px-1">
              <div className="bg-white rounded-full w-5 h-5 ml-auto"></div>
            </div>
          </div>
          <div className="flex items-center justify-between">
            <div>
              <p className="text-gray-800 text-sm">Market Price Changes</p>
              <p className="text-xs text-gray-500">Price increases & decreases</p>
            </div>
            <div className="bg-green-500 rounded-full w-12 h-6 flex items-center px-1">
              <div className="bg-white rounded-full w-5 h-5 ml-auto"></div>
            </div>
          </div>
          <div className="flex items-center justify-between">
            <div>
              <p className="text-gray-800 text-sm">Storage Availability</p>
              <p className="text-xs text-gray-500">New facilities & capacity</p>
            </div>
            <div className="bg-green-500 rounded-full w-12 h-6 flex items-center px-1">
              <div className="bg-white rounded-full w-5 h-5 ml-auto"></div>
            </div>
          </div>
          <div className="flex items-center justify-between">
            <div>
              <p className="text-gray-800 text-sm">Crop Calendar Reminders</p>
              <p className="text-xs text-gray-500">Fertilizer, irrigation alerts</p>
            </div>
            <div className="bg-gray-300 rounded-full w-12 h-6 flex items-center px-1">
              <div className="bg-white rounded-full w-5 h-5"></div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
