import { useState } from 'react';
import { TrendingUp, TrendingDown, DollarSign, Package, Truck, Warehouse, PlusCircle } from 'lucide-react';
import { BarChart, Bar, LineChart, Line, PieChart, Pie, Cell, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from 'recharts';
import { Button } from '../ui/button';
import { Input } from '../ui/input';

export default function Analytics() {
  const [showCostForm, setShowCostForm] = useState(false);

  const monthlyData = [
    { month: 'Jul', revenue: 45000, cost: 30000, profit: 15000 },
    { month: 'Aug', revenue: 52000, cost: 32000, profit: 20000 },
    { month: 'Sep', revenue: 48000, cost: 31000, profit: 17000 },
    { month: 'Oct', revenue: 61000, cost: 35000, profit: 26000 },
    { month: 'Nov', revenue: 68000, cost: 38000, profit: 30000 },
    { month: 'Dec', revenue: 75000, cost: 40000, profit: 35000 }
  ];

  const expenseBreakdown = [
    { name: 'Seeds', value: 8000, color: '#1E7F43' },
    { name: 'Fertilizer', value: 12000, color: '#F59E0B' },
    { name: 'Pesticides', value: 5000, color: '#EF4444' },
    { name: 'Labor', value: 10000, color: '#3B82F6' },
    { name: 'Transport', value: 3000, color: '#8B5CF6' },
    { name: 'Storage', value: 2000, color: '#EC4899' }
  ];

  const impactData = [
    { metric: 'With AgriVault', value: 75000 },
    { metric: 'Without AgriVault', value: 58000 }
  ];

  return (
    <div className="p-4 space-y-4">
      <div>
        <h2 className="text-gray-800 text-xl mb-1">Farm Analytics</h2>
        <p className="text-gray-600 text-sm">Track your financial performance</p>
      </div>

      {/* Summary Cards */}
      <div className="grid grid-cols-2 gap-3">
        <div className="bg-gradient-to-br from-green-500 to-green-600 text-white rounded-2xl p-4">
          <TrendingUp className="w-6 h-6 mb-2" />
          <p className="text-white/80 text-sm mb-1">Total Revenue</p>
          <p className="text-2xl">₨349K</p>
          <p className="text-xs text-white/70 mt-1">+18% this month</p>
        </div>

        <div className="bg-gradient-to-br from-blue-500 to-blue-600 text-white rounded-2xl p-4">
          <DollarSign className="w-6 h-6 mb-2" />
          <p className="text-white/80 text-sm mb-1">Net Profit</p>
          <p className="text-2xl">₨143K</p>
          <p className="text-xs text-white/70 mt-1">+22% this month</p>
        </div>

        <div className="bg-gradient-to-br from-orange-500 to-orange-600 text-white rounded-2xl p-4">
          <Package className="w-6 h-6 mb-2" />
          <p className="text-white/80 text-sm mb-1">Total Investment</p>
          <p className="text-2xl">₨206K</p>
          <p className="text-xs text-white/70 mt-1">6 months</p>
        </div>

        <div className="bg-gradient-to-br from-purple-500 to-purple-600 text-white rounded-2xl p-4">
          <Warehouse className="w-6 h-6 mb-2" />
          <p className="text-white/80 text-sm mb-1">Loss Prevented</p>
          <p className="text-2xl">₨42K</p>
          <p className="text-xs text-white/70 mt-1">via cold storage</p>
        </div>
      </div>

      {/* Profit & Loss Chart */}
      <div className="bg-white rounded-2xl p-5">
        <h3 className="text-gray-800 mb-4">Profit & Loss Trends</h3>
        <ResponsiveContainer width="100%" height={250}>
          <LineChart data={monthlyData}>
            <CartesianGrid strokeDasharray="3 3" stroke="#f0f0f0" />
            <XAxis dataKey="month" tick={{ fontSize: 12 }} stroke="#999" />
            <YAxis tick={{ fontSize: 12 }} stroke="#999" />
            <Tooltip 
              contentStyle={{ backgroundColor: '#fff', border: '1px solid #e0e0e0', borderRadius: '8px' }}
              formatter={(value) => `₨${value}`}
            />
            <Legend />
            <Line type="monotone" dataKey="revenue" stroke="#1E7F43" strokeWidth={2} name="Revenue" />
            <Line type="monotone" dataKey="cost" stroke="#F59E0B" strokeWidth={2} name="Cost" />
            <Line type="monotone" dataKey="profit" stroke="#3B82F6" strokeWidth={2} name="Profit" />
          </LineChart>
        </ResponsiveContainer>
      </div>

      {/* Expense Breakdown */}
      <div className="bg-white rounded-2xl p-5">
        <h3 className="text-gray-800 mb-4">Expense Breakdown</h3>
        <div className="flex items-center justify-center mb-4">
          <ResponsiveContainer width="100%" height={200}>
            <PieChart>
              <Pie
                data={expenseBreakdown}
                cx="50%"
                cy="50%"
                innerRadius={60}
                outerRadius={80}
                paddingAngle={2}
                dataKey="value"
              >
                {expenseBreakdown.map((entry, index) => (
                  <Cell key={`cell-${index}`} fill={entry.color} />
                ))}
              </Pie>
              <Tooltip formatter={(value) => `₨${value}`} />
            </PieChart>
          </ResponsiveContainer>
        </div>
        <div className="grid grid-cols-2 gap-2">
          {expenseBreakdown.map((item, idx) => (
            <div key={idx} className="flex items-center gap-2 text-sm">
              <div className="w-3 h-3 rounded-full" style={{ backgroundColor: item.color }}></div>
              <span className="text-gray-700">{item.name}</span>
              <span className="text-gray-600 ml-auto">₨{item.value}</span>
            </div>
          ))}
        </div>
      </div>

      {/* AgriVault Impact Comparison */}
      <div className="bg-white rounded-2xl p-5">
        <h3 className="text-gray-800 mb-4">AgriVault Impact (This Month)</h3>
        <ResponsiveContainer width="100%" height={200}>
          <BarChart data={impactData}>
            <CartesianGrid strokeDasharray="3 3" stroke="#f0f0f0" />
            <XAxis dataKey="metric" tick={{ fontSize: 12 }} stroke="#999" />
            <YAxis tick={{ fontSize: 12 }} stroke="#999" />
            <Tooltip 
              contentStyle={{ backgroundColor: '#fff', border: '1px solid #e0e0e0', borderRadius: '8px' }}
              formatter={(value) => `₨${value}`}
            />
            <Bar dataKey="value" fill="#1E7F43" radius={[8, 8, 0, 0]} />
          </BarChart>
        </ResponsiveContainer>
        <div className="mt-4 bg-green-50 rounded-xl p-4">
          <p className="text-green-800 text-sm">
            💡 Cold storage increased your profit by <span className="font-bold">18%</span> this month by preventing spoilage and enabling better market timing.
          </p>
        </div>
      </div>

      {/* Add Costs Button */}
      <Button 
        onClick={() => setShowCostForm(true)}
        className="w-full h-12 bg-[#1E7F43] hover:bg-[#15593A]"
      >
        <PlusCircle className="w-5 h-5 mr-2" />
        Add Crop Costs
      </Button>

      {/* Cost Input Form (Simple Modal) */}
      {showCostForm && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center p-4 z-50">
          <div className="bg-white rounded-3xl p-6 max-w-md w-full max-h-[80vh] overflow-y-auto">
            <h3 className="text-xl text-gray-800 mb-4">Add Crop Costs</h3>
            <div className="space-y-3">
              <div>
                <label className="block text-sm text-gray-700 mb-1">Crop Type</label>
                <Input placeholder="e.g., Tomatoes" className="rounded-xl" />
              </div>
              <div>
                <label className="block text-sm text-gray-700 mb-1">Seed Cost</label>
                <Input type="number" placeholder="₨" className="rounded-xl" />
              </div>
              <div>
                <label className="block text-sm text-gray-700 mb-1">Fertilizer Cost</label>
                <Input type="number" placeholder="₨" className="rounded-xl" />
              </div>
              <div>
                <label className="block text-sm text-gray-700 mb-1">Pesticide Cost</label>
                <Input type="number" placeholder="₨" className="rounded-xl" />
              </div>
              <div>
                <label className="block text-sm text-gray-700 mb-1">Labor Cost</label>
                <Input type="number" placeholder="₨" className="rounded-xl" />
              </div>
              <div>
                <label className="block text-sm text-gray-700 mb-1">Transport Cost</label>
                <Input type="number" placeholder="₨" className="rounded-xl" />
              </div>
              <div>
                <label className="block text-sm text-gray-700 mb-1">Storage Cost</label>
                <Input type="number" placeholder="₨" className="rounded-xl" />
              </div>
            </div>
            <div className="flex gap-2 mt-6">
              <Button 
                variant="outline" 
                onClick={() => setShowCostForm(false)}
                className="flex-1"
              >
                Cancel
              </Button>
              <Button 
                onClick={() => setShowCostForm(false)}
                className="flex-1 bg-[#1E7F43] hover:bg-[#15593A]"
              >
                Save
              </Button>
            </div>
          </div>
        </div>
      )}

      {/* Performance Summary */}
      <div className="bg-gradient-to-r from-[#1E7F43] to-[#15593A] text-white rounded-2xl p-5">
        <h3 className="text-lg mb-3">Performance Summary</h3>
        <div className="space-y-3 text-sm">
          <div className="flex items-center justify-between">
            <span className="text-white/80">Higher selling price</span>
            <span className="text-white">+₨12K</span>
          </div>
          <div className="flex items-center justify-between">
            <span className="text-white/80">Reduced spoilage</span>
            <span className="text-white">+₨8K</span>
          </div>
          <div className="flex items-center justify-between">
            <span className="text-white/80">Transport savings</span>
            <span className="text-white">+₨5K</span>
          </div>
          <div className="pt-3 border-t border-white/20 flex items-center justify-between">
            <span>Total Benefit</span>
            <span className="text-2xl">+₨25K</span>
          </div>
        </div>
      </div>
    </div>
  );
}
