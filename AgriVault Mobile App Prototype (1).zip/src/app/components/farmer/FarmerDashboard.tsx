import { useState } from 'react';
import { Home, TrendingUp, Warehouse, AlertTriangle, User } from 'lucide-react';
import { LanguageToggleCompact } from '../ui/LanguageToggle';
import { useLanguage } from '../../contexts/LanguageContext';
import FarmerHome from './FarmerHome';
import MarketModule from './MarketModule';
import StorageModule from './StorageModule';
import AlertsModule from './AlertsModule';
import ProfileModule from './ProfileModule';

interface FarmerDashboardProps {
  onLogout: () => void;
}

export default function FarmerDashboard({ onLogout }: FarmerDashboardProps) {
  const [activeTab, setActiveTab] = useState<'home' | 'market' | 'storage' | 'alerts' | 'profile'>('home');

  const tabs = [
    { id: 'home', icon: Home, label: 'Home' },
    { id: 'market', icon: TrendingUp, label: 'Market' },
    { id: 'storage', icon: Warehouse, label: 'Storage' },
    { id: 'alerts', icon: AlertTriangle, label: 'Alerts' },
    { id: 'profile', icon: User, label: 'Profile' }
  ];

  return (
    <div className="min-h-screen bg-gray-50 pb-20">
      {/* Content */}
      <div className="min-h-[calc(100vh-5rem)]">
        {activeTab === 'home' && <FarmerHome />}
        {activeTab === 'market' && <MarketModule />}
        {activeTab === 'storage' && <StorageModule />}
        {activeTab === 'alerts' && <AlertsModule />}
        {activeTab === 'profile' && <ProfileModule onLogout={onLogout} />}
      </div>

      {/* Bottom Navigation */}
      <div className="fixed bottom-0 left-0 right-0 bg-white border-t border-gray-200 shadow-lg">
        <div className="flex justify-around items-center h-20 max-w-md mx-auto">
          {tabs.map((tab) => {
            const Icon = tab.icon;
            const isActive = activeTab === tab.id;
            return (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id as any)}
                className={`flex flex-col items-center justify-center gap-1 px-4 py-2 transition-colors ${
                  isActive ? 'text-[#1E7F43]' : 'text-gray-500'
                }`}
              >
                <Icon className={`w-6 h-6 ${isActive ? 'fill-[#1E7F43]/10' : ''}`} />
                <span className="text-xs">{tab.label}</span>
              </button>
            );
          })}
        </div>
      </div>
    </div>
  );
}