import { useState } from 'react';
import { Camera, Upload, Loader2, AlertCircle, CheckCircle2, Bug } from 'lucide-react';
import { Button } from '../ui/button';

export default function PestDetection() {
  const [selectedImage, setSelectedImage] = useState<string | null>(null);
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [result, setResult] = useState<any>(null);

  const handleImageUpload = (type: 'camera' | 'gallery') => {
    // Simulate image upload
    setSelectedImage('uploaded');
    setIsAnalyzing(true);
    
    // Simulate AI analysis
    setTimeout(() => {
      setIsAnalyzing(false);
      setResult({
        pest: 'Tomato Leaf Curl Virus',
        severity: 'Moderate',
        confidence: 87,
        treatment: [
          'Remove and destroy infected plants',
          'Apply neem oil spray every 7 days',
          'Use resistant tomato varieties',
          'Control whitefly population'
        ],
        prevention: [
          'Use yellow sticky traps',
          'Maintain proper plant spacing',
          'Regular monitoring of crops',
          'Avoid over-fertilization'
        ]
      });
    }, 2500);
  };

  const handleReset = () => {
    setSelectedImage(null);
    setResult(null);
  };

  if (result) {
    return (
      <div className="p-4 space-y-4">
        <div className="flex items-center gap-3 mb-4">
          <button onClick={handleReset} className="text-[#1E7F43]">
            ← Scan Another
          </button>
        </div>

        {/* Result Header */}
        <div className="bg-gradient-to-r from-red-500 to-red-600 text-white rounded-2xl p-5">
          <div className="flex items-center gap-3 mb-3">
            <Bug className="w-8 h-8" />
            <div>
              <h2 className="text-2xl">{result.pest}</h2>
              <p className="text-white/80 text-sm">{result.confidence}% Confidence</p>
            </div>
          </div>
          <div className="bg-white/20 rounded-xl p-3">
            <div className="flex items-center justify-between">
              <span>Severity Level</span>
              <span className={`px-3 py-1 rounded-full text-sm ${
                result.severity === 'High' ? 'bg-red-200 text-red-800' :
                result.severity === 'Moderate' ? 'bg-yellow-200 text-yellow-800' :
                'bg-green-200 text-green-800'
              }`}>
                {result.severity}
              </span>
            </div>
          </div>
        </div>

        {/* MVP Note */}
        <div className="bg-blue-50 rounded-2xl p-4 border-2 border-blue-200">
          <p className="text-blue-800 text-sm">
            ✓ This diagnosis has been reviewed by our agriculture expert team
          </p>
        </div>

        {/* Treatment Steps */}
        <div className="bg-white rounded-2xl p-5">
          <h3 className="text-gray-800 mb-3 flex items-center gap-2">
            <AlertCircle className="w-5 h-5 text-red-500" />
            Treatment Steps
          </h3>
          <div className="space-y-3">
            {result.treatment.map((step: string, idx: number) => (
              <div key={idx} className="flex gap-3">
                <div className="bg-red-100 text-red-600 rounded-full w-6 h-6 flex items-center justify-center flex-shrink-0 text-sm">
                  {idx + 1}
                </div>
                <p className="text-gray-700 text-sm pt-0.5">{step}</p>
              </div>
            ))}
          </div>
        </div>

        {/* Prevention Tips */}
        <div className="bg-white rounded-2xl p-5">
          <h3 className="text-gray-800 mb-3 flex items-center gap-2">
            <CheckCircle2 className="w-5 h-5 text-green-500" />
            Prevention Tips
          </h3>
          <div className="space-y-3">
            {result.prevention.map((tip: string, idx: number) => (
              <div key={idx} className="flex gap-3">
                <CheckCircle2 className="w-5 h-5 text-green-500 flex-shrink-0" />
                <p className="text-gray-700 text-sm">{tip}</p>
              </div>
            ))}
          </div>
        </div>

        {/* Actions */}
        <div className="grid grid-cols-2 gap-3">
          <Button variant="outline" className="h-12">
            Share Report
          </Button>
          <Button className="h-12 bg-[#1E7F43] hover:bg-[#15593A]">
            Talk to Expert
          </Button>
        </div>
      </div>
    );
  }

  if (isAnalyzing) {
    return (
      <div className="min-h-screen bg-gray-50 flex flex-col items-center justify-center p-4">
        <div className="bg-white rounded-3xl p-8 text-center max-w-sm">
          <Loader2 className="w-16 h-16 text-[#1E7F43] mx-auto mb-4 animate-spin" />
          <h3 className="text-xl text-gray-800 mb-2">Analyzing Image...</h3>
          <p className="text-gray-600 text-sm">Our AI is detecting pests and diseases</p>
        </div>
      </div>
    );
  }

  return (
    <div className="p-4 space-y-4">
      <div>
        <h2 className="text-gray-800 text-xl mb-1">AI Pest Detection</h2>
        <p className="text-gray-600 text-sm">Upload crop photo for instant diagnosis</p>
      </div>

      {/* Instructions */}
      <div className="bg-green-50 rounded-2xl p-5 border-2 border-green-200">
        <h3 className="text-green-800 mb-3">📸 How to get best results</h3>
        <ul className="space-y-2 text-sm text-gray-700">
          <li className="flex items-start gap-2">
            <span className="text-green-600">•</span>
            <span>Take photo in good lighting</span>
          </li>
          <li className="flex items-start gap-2">
            <span className="text-green-600">•</span>
            <span>Focus on affected leaf or plant part</span>
          </li>
          <li className="flex items-start gap-2">
            <span className="text-green-600">•</span>
            <span>Avoid blurry images</span>
          </li>
          <li className="flex items-start gap-2">
            <span className="text-green-600">•</span>
            <span>Include entire affected area</span>
          </li>
        </ul>
      </div>

      {/* Upload Options */}
      <div className="space-y-3">
        <button 
          onClick={() => handleImageUpload('camera')}
          className="w-full bg-gradient-to-r from-[#1E7F43] to-[#15593A] text-white rounded-2xl p-6 flex items-center justify-center gap-3 hover:shadow-lg transition-shadow"
        >
          <Camera className="w-8 h-8" />
          <div className="text-left">
            <h3 className="text-lg">Take Photo</h3>
            <p className="text-white/80 text-sm">Use camera to capture</p>
          </div>
        </button>

        <button 
          onClick={() => handleImageUpload('gallery')}
          className="w-full bg-white text-gray-800 rounded-2xl p-6 flex items-center justify-center gap-3 border-2 border-gray-200 hover:border-[#1E7F43] hover:shadow-md transition-all"
        >
          <Upload className="w-8 h-8 text-[#1E7F43]" />
          <div className="text-left">
            <h3 className="text-lg">Upload from Gallery</h3>
            <p className="text-gray-600 text-sm">Select existing photo</p>
          </div>
        </button>
      </div>

      {/* Recent Scans */}
      <div className="bg-white rounded-2xl p-5">
        <h3 className="text-gray-800 mb-4">Recent Scans</h3>
        <div className="space-y-3">
          <div className="flex items-center gap-3 p-3 bg-gray-50 rounded-xl">
            <div className="bg-red-100 rounded-lg w-12 h-12 flex items-center justify-center">
              <Bug className="w-6 h-6 text-red-600" />
            </div>
            <div className="flex-1">
              <h4 className="text-gray-800 text-sm">Leaf Curl Virus</h4>
              <p className="text-xs text-gray-500">Dec 19, 2024</p>
            </div>
            <button className="text-[#1E7F43] text-sm">View</button>
          </div>

          <div className="flex items-center gap-3 p-3 bg-gray-50 rounded-xl">
            <div className="bg-yellow-100 rounded-lg w-12 h-12 flex items-center justify-center">
              <Bug className="w-6 h-6 text-yellow-600" />
            </div>
            <div className="flex-1">
              <h4 className="text-gray-800 text-sm">Aphid Infestation</h4>
              <p className="text-xs text-gray-500">Dec 17, 2024</p>
            </div>
            <button className="text-[#1E7F43] text-sm">View</button>
          </div>
        </div>
      </div>
    </div>
  );
}
