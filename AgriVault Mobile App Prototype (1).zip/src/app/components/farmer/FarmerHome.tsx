import { useState } from 'react';
import { 
  CloudSun, Droplets, Wind, Thermometer, 
  Calendar, Package, TrendingUp, Camera, 
  MessageCircle, Warehouse, Leaf, BarChart3,
  ArrowRight, AlertCircle, ShoppingCart, Shield, Gavel, Users, TrendingDown
} from 'lucide-react';
import { Button } from '../ui/button';
import { LanguageToggleCompact } from '../ui/LanguageToggle';
import { useLanguage } from '../../contexts/LanguageContext';
import WeatherModule from './WeatherModule';
import CropCalendar from './CropCalendar';
import MarketModule from './MarketModule';
import StorageModule from './StorageModule';
import PestDetection from './PestDetection';
import ExpertChat from './ExpertChat';
import Analytics from './Analytics';
import SupplierMarketplace from './SupplierMarketplace';
import GovernmentSchemes from './GovernmentSchemes';
import TradingFloor from './TradingFloor';

export default function FarmerHome() {
  const [activeModule, setActiveModule] = useState<string | null>(null);
  const { t } = useLanguage();

  if (activeModule) {
    return (
      <div>
        <div className="bg-white border-b px-4 py-3 sticky top-0 z-10 flex items-center justify-between">
          <button onClick={() => setActiveModule(null)} className="text-[#1E7F43] flex items-center gap-2 hover:bg-green-50 p-2 rounded-full transition-colors">
            <div className="bg-green-50 rounded-full p-1">
              <ArrowRight className="w-5 h-5 rotate-180" />
            </div>
            <span>Back to Home</span>
          </button>
          
          {/* Language Toggle in Sub-module Header */}
          <LanguageToggleCompact />
        </div>
        {activeModule === 'weather' && <WeatherModule />}
        {activeModule === 'calendar' && <CropCalendar />}
        {activeModule === 'market' && <MarketModule />}
        {activeModule === 'storage' && <StorageModule />}
        {activeModule === 'pest' && <PestDetection />}
        {activeModule === 'expert' && <ExpertChat />}
        {activeModule === 'analytics' && <Analytics />}
        {activeModule === 'supplier' && <SupplierMarketplace />}
        {activeModule === 'schemes' && <GovernmentSchemes />}
        {activeModule === 'trading' && <TradingFloor />}
      </div>
    );
  }

  return (
    <div className="p-4 space-y-6" style={{
      backgroundImage: 'linear-gradient(to bottom, rgba(30, 127, 67, 0.03), rgba(255, 255, 255, 1) 30%), url(https://images.unsplash.com/photo-1560493676-04071c5f467b?w=800)',
      backgroundSize: 'cover',
      backgroundPosition: 'center top',
      backgroundRepeat: 'no-repeat',
      minHeight: '100vh'
    }}>
      {/* Header with Language Toggle */}
      <div className="bg-gradient-to-r from-[#1E7F43] to-[#15593A] text-white rounded-3xl p-6 relative">
        {/* Language Toggle - Top Right */}
        <div className="absolute top-4 right-4">
          <LanguageToggleCompact />
        </div>
        
        <h2 className="text-2xl mb-1 pr-24">Welcome Back, Ahmed! 👋</h2>
        <p className="text-white/80 text-sm">Here's your farm overview</p>
      </div>

      {/* Critical Alert */}
      <div className="bg-gradient-to-r from-orange-500 to-red-500 text-white rounded-2xl p-4 flex items-start gap-3 shadow-lg">
        <AlertCircle className="w-6 h-6 flex-shrink-0 mt-0.5" />
        <div className="flex-1">
          <h3 className="mb-1">High Spoilage Risk Alert</h3>
          <p className="text-sm text-white/90 mb-3">Heatwave expected in 48 hours. Book cold storage now to prevent 30% crop loss!</p>
          <Button size="sm" variant="secondary" className="bg-white text-orange-600 hover:bg-white/90">
            Book Storage Now
          </Button>
        </div>
      </div>

      {/* Weather Summary */}
      <div 
        className="bg-gradient-to-br from-blue-500 to-blue-600 text-white rounded-2xl p-5 cursor-pointer hover:shadow-lg transition-shadow"
        onClick={() => setActiveModule('weather')}
      >
        <div className="flex items-center justify-between mb-4">
          <h3 className="text-lg">Today's Weather</h3>
          <CloudSun className="w-8 h-8" />
        </div>
        <div className="grid grid-cols-3 gap-4">
          <div>
            <div className="flex items-center gap-1 text-white/80 text-sm mb-1">
              <Thermometer className="w-4 h-4" />
              <span>Temp</span>
            </div>
            <p className="text-2xl">32°C</p>
          </div>
          <div>
            <div className="flex items-center gap-1 text-white/80 text-sm mb-1">
              <Droplets className="w-4 h-4" />
              <span>Humidity</span>
            </div>
            <p className="text-2xl">65%</p>
          </div>
          <div>
            <div className="flex items-center gap-1 text-white/80 text-sm mb-1">
              <Wind className="w-4 h-4" />
              <span>Wind</span>
            </div>
            <p className="text-2xl">12km/h</p>
          </div>
        </div>
        <div className="mt-4 flex items-center text-sm text-white/90">
          <span>View 7-day forecast</span>
          <ArrowRight className="w-4 h-4 ml-1" />
        </div>
      </div>

      {/* Crop Status Cards */}
      <div>
        <h3 className="text-gray-800 mb-3">My Crops</h3>
        <div className="grid grid-cols-2 gap-3">
          <div 
            className="bg-white rounded-2xl p-4 border-2 border-green-200 cursor-pointer hover:shadow-md transition-shadow"
            onClick={() => setActiveModule('calendar')}
          >
            <div className="bg-green-100 rounded-full w-12 h-12 flex items-center justify-center mb-3">
              <Leaf className="w-6 h-6 text-green-600" />
            </div>
            <h4 className="text-gray-800 mb-1">Tomatoes</h4>
            <p className="text-sm text-gray-600 mb-2">5 acres • Harvest ready</p>
            <div className="bg-green-100 text-green-700 px-2 py-1 rounded-full text-xs inline-block">
              Ready in 3 days
            </div>
          </div>

          <div 
            className="bg-white rounded-2xl p-4 border-2 border-yellow-200 cursor-pointer hover:shadow-md transition-shadow"
            onClick={() => setActiveModule('calendar')}
          >
            <div className="bg-yellow-100 rounded-full w-12 h-12 flex items-center justify-center mb-3">
              <Package className="w-6 h-6 text-yellow-600" />
            </div>
            <h4 className="text-gray-800 mb-1">Wheat</h4>
            <p className="text-sm text-gray-600 mb-2">10 acres • Growing</p>
            <div className="bg-yellow-100 text-yellow-700 px-2 py-1 rounded-full text-xs inline-block">
              Fertilizer due
            </div>
          </div>
        </div>
      </div>

      {/* Storage Availability */}
      <div 
        className="bg-gradient-to-r from-purple-500 to-purple-600 text-white rounded-2xl p-5 cursor-pointer hover:shadow-lg transition-shadow"
        onClick={() => setActiveModule('storage')}
      >
        <div className="flex items-center justify-between mb-3">
          <h3 className="text-lg">ThandaHub Storage</h3>
          <Warehouse className="w-6 h-6" />
        </div>
        <p className="text-white/90 text-sm mb-3">3 cold storages available within 5km</p>
        <div className="bg-white/20 rounded-xl p-3">
          <div className="flex items-center justify-between">
            <span className="text-sm">Starting from</span>
            <span className="text-2xl">₨8/kg</span>
          </div>
        </div>
      </div>

      {/* Market Price Highlight */}
      <div 
        className="bg-gradient-to-r from-green-500 to-green-600 text-white rounded-2xl p-5 cursor-pointer hover:shadow-lg transition-shadow"
        onClick={() => setActiveModule('market')}
      >
        <div className="flex items-center justify-between mb-3">
          <h3 className="text-lg">Market Prices Today</h3>
          <TrendingUp className="w-6 h-6" />
        </div>
        <div className="space-y-2">
          <div className="flex items-center justify-between">
            <span>Tomatoes</span>
            <div className="flex items-center gap-2">
              <span className="text-2xl">₨45/kg</span>
              <span className="bg-white/20 px-2 py-1 rounded-full text-xs">↑12%</span>
            </div>
          </div>
          <p className="text-white/80 text-sm">Best time to sell! Prices up in Lahore Mandi</p>
        </div>
      </div>

      {/* Quick Actions */}
      <div>
        <h3 className="text-gray-800 mb-3">Quick Actions</h3>
        <div className="grid grid-cols-2 gap-3">
          <button 
            onClick={() => setActiveModule('storage')}
            className="bg-white rounded-2xl p-4 border-2 border-gray-200 hover:border-[#1E7F43] hover:shadow-md transition-all text-left"
          >
            <div className="bg-purple-100 rounded-full w-12 h-12 flex items-center justify-center mb-3">
              <Warehouse className="w-6 h-6 text-purple-600" />
            </div>
            <h4 className="text-gray-800 text-sm">Book Storage</h4>
          </button>

          <button 
            onClick={() => setActiveModule('market')}
            className="bg-white rounded-2xl p-4 border-2 border-gray-200 hover:border-[#1E7F43] hover:shadow-md transition-all text-left"
          >
            <div className="bg-green-100 rounded-full w-12 h-12 flex items-center justify-center mb-3">
              <TrendingUp className="w-6 h-6 text-green-600" />
            </div>
            <h4 className="text-gray-800 text-sm">Check Prices</h4>
          </button>

          <button 
            onClick={() => setActiveModule('pest')}
            className="bg-white rounded-2xl p-4 border-2 border-gray-200 hover:border-[#1E7F43] hover:shadow-md transition-all text-left"
          >
            <div className="bg-red-100 rounded-full w-12 h-12 flex items-center justify-center mb-3">
              <Camera className="w-6 h-6 text-red-600" />
            </div>
            <h4 className="text-gray-800 text-sm">Detect Pest</h4>
          </button>

          <button 
            onClick={() => setActiveModule('expert')}
            className="bg-white rounded-2xl p-4 border-2 border-gray-200 hover:border-[#1E7F43] hover:shadow-md transition-all text-left"
          >
            <div className="bg-blue-100 rounded-full w-12 h-12 flex items-center justify-center mb-3">
              <MessageCircle className="w-6 h-6 text-blue-600" />
            </div>
            <h4 className="text-gray-800 text-sm">Chat Expert</h4>
          </button>

          <button 
            onClick={() => setActiveModule('supplier')}
            className="bg-white rounded-2xl p-4 border-2 border-gray-200 hover:border-[#1E7F43] hover:shadow-md transition-all text-left"
          >
            <div className="bg-orange-100 rounded-full w-12 h-12 flex items-center justify-center mb-3">
              <ShoppingCart className="w-6 h-6 text-orange-600" />
            </div>
            <h4 className="text-gray-800 text-sm">Buy Inputs</h4>
          </button>

          <button 
            onClick={() => setActiveModule('schemes')}
            className="bg-white rounded-2xl p-4 border-2 border-gray-200 hover:border-[#1E7F43] hover:shadow-md transition-all text-left"
          >
            <div className="bg-blue-100 rounded-full w-12 h-12 flex items-center justify-center mb-3">
              <Shield className="w-6 h-6 text-blue-600" />
            </div>
            <h4 className="text-gray-800 text-sm">Govt Schemes</h4>
          </button>

          <button 
            onClick={() => setActiveModule('trading')}
            className="bg-white rounded-2xl p-4 border-2 border-gray-200 hover:border-[#1E7F43] hover:shadow-md transition-all text-left"
          >
            <div className="bg-green-100 rounded-full w-12 h-12 flex items-center justify-center mb-3">
              <Gavel className="w-6 h-6 text-green-600" />
            </div>
            <h4 className="text-gray-800 text-sm">Trading Floor</h4>
          </button>

          <button 
            onClick={() => setActiveModule('analytics')}
            className="bg-white rounded-2xl p-4 border-2 border-gray-200 hover:border-[#1E7F43] hover:shadow-md transition-all text-left"
          >
            <div className="bg-indigo-100 rounded-full w-12 h-12 flex items-center justify-center mb-3">
              <BarChart3 className="w-6 h-6 text-indigo-600" />
            </div>
            <h4 className="text-gray-800 text-sm">Analytics</h4>
          </button>
        </div>
      </div>

      {/* Community Insights */}
      <div>
        <div className="flex items-center justify-between mb-3">
          <h3 className="text-gray-800">📊 Community Insights</h3>
          <Users className="w-5 h-5 text-gray-400" />
        </div>
        <div className="space-y-3">
          <div className="bg-white rounded-2xl p-4 shadow-md border-l-4 border-green-500">
            <div className="flex items-center justify-between mb-2">
              <h4 className="text-sm">Popular Crops This Season</h4>
              <TrendingUp className="w-4 h-4 text-green-600" />
            </div>
            <div className="space-y-2">
              <div className="flex items-center justify-between text-sm">
                <span className="text-gray-600">🌾 Wheat</span>
                <span className="text-green-600">+45% farmers</span>
              </div>
              <div className="flex items-center justify-between text-sm">
                <span className="text-gray-600">🍅 Tomato</span>
                <span className="text-green-600">+32% farmers</span>
              </div>
              <div className="flex items-center justify-between text-sm">
                <span className="text-gray-600">🌾 Rice</span>
                <span className="text-green-600">+28% farmers</span>
              </div>
            </div>
          </div>

          <div className="bg-white rounded-2xl p-4 shadow-md border-l-4 border-purple-500">
            <div className="flex items-center justify-between mb-2">
              <h4 className="text-sm">Storage Booking Trends</h4>
              <Warehouse className="w-4 h-4 text-purple-600" />
            </div>
            <p className="text-sm text-gray-600 mb-2">
              2,340 farmers booked cold storage this month
            </p>
            <div className="bg-purple-50 rounded-lg p-2">
              <p className="text-xs text-purple-800">
                💡 Peak booking hours: 9 AM - 11 AM
              </p>
            </div>
          </div>

          <div className="bg-white rounded-2xl p-4 shadow-md border-l-4 border-blue-500">
            <div className="flex items-center justify-between mb-2">
              <h4 className="text-sm">Market Movement</h4>
              <TrendingUp className="w-4 h-4 text-blue-600" />
            </div>
            <p className="text-sm text-gray-600 mb-2">
              Wheat prices increased 8% in last 7 days
            </p>
            <div className="bg-blue-50 rounded-lg p-2">
              <p className="text-xs text-blue-800">
                📈 Best selling time: Next 3-5 days
              </p>
            </div>
          </div>

          <div className="bg-gray-50 rounded-2xl p-3 border border-gray-200">
            <p className="text-xs text-gray-500 text-center">
              🔒 All data is anonymous & aggregated<br />
              Individual farmer information is never shared
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}