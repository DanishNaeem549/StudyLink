import { User, MapPin, Phone, Mail, Leaf, Settings, HelpCircle, FileText, LogOut, ChevronRight } from 'lucide-react';
import { Button } from '../ui/button';

interface ProfileModuleProps {
  onLogout: () => void;
}

export default function ProfileModule({ onLogout }: ProfileModuleProps) {
  const menuItems = [
    { icon: User, label: 'Edit Profile', color: 'text-blue-500' },
    { icon: Leaf, label: 'My Crops', color: 'text-green-500' },
    { icon: FileText, label: 'Booking History', color: 'text-purple-500' },
    { icon: Settings, label: 'Settings', color: 'text-gray-500' },
    { icon: HelpCircle, label: 'Help & Support', color: 'text-orange-500' },
    { icon: FileText, label: 'Terms & Privacy', color: 'text-gray-500' }
  ];

  return (
    <div className="p-4 space-y-4">
      {/* Profile Header */}
      <div className="bg-gradient-to-r from-[#1E7F43] to-[#15593A] text-white rounded-3xl p-6">
        <div className="flex items-center gap-4 mb-4">
          <div className="bg-white rounded-full w-20 h-20 flex items-center justify-center">
            <User className="w-10 h-10 text-[#1E7F43]" />
          </div>
          <div>
            <h2 className="text-2xl mb-1">Ahmed Ali</h2>
            <p className="text-white/80 text-sm">Farmer ID: #FAR-2024-1543</p>
          </div>
        </div>
        <div className="grid grid-cols-2 gap-3 mt-4">
          <div className="bg-white/10 rounded-xl p-3 text-center">
            <p className="text-white/70 text-sm mb-1">Total Crops</p>
            <p className="text-2xl">5</p>
          </div>
          <div className="bg-white/10 rounded-xl p-3 text-center">
            <p className="text-white/70 text-sm mb-1">Total Area</p>
            <p className="text-2xl">15 acres</p>
          </div>
        </div>
      </div>

      {/* Contact Info */}
      <div className="bg-white rounded-2xl p-5">
        <h3 className="text-gray-800 mb-4">Contact Information</h3>
        <div className="space-y-3">
          <div className="flex items-center gap-3">
            <div className="bg-blue-100 rounded-full w-10 h-10 flex items-center justify-center">
              <Phone className="w-5 h-5 text-blue-600" />
            </div>
            <div>
              <p className="text-sm text-gray-500">Phone</p>
              <p className="text-gray-800">+92 300 1234567</p>
            </div>
          </div>
          <div className="flex items-center gap-3">
            <div className="bg-purple-100 rounded-full w-10 h-10 flex items-center justify-center">
              <Mail className="w-5 h-5 text-purple-600" />
            </div>
            <div>
              <p className="text-sm text-gray-500">Email</p>
              <p className="text-gray-800">ahmed.ali@example.com</p>
            </div>
          </div>
          <div className="flex items-center gap-3">
            <div className="bg-green-100 rounded-full w-10 h-10 flex items-center justify-center">
              <MapPin className="w-5 h-5 text-green-600" />
            </div>
            <div>
              <p className="text-sm text-gray-500">Location</p>
              <p className="text-gray-800">Lahore, Punjab</p>
            </div>
          </div>
        </div>
      </div>

      {/* Menu Items */}
      <div className="bg-white rounded-2xl overflow-hidden">
        {menuItems.map((item, idx) => {
          const Icon = item.icon;
          return (
            <button
              key={idx}
              className={`w-full flex items-center justify-between p-4 hover:bg-gray-50 transition-colors ${
                idx !== menuItems.length - 1 ? 'border-b border-gray-100' : ''
              }`}
            >
              <div className="flex items-center gap-3">
                <Icon className={`w-5 h-5 ${item.color}`} />
                <span className="text-gray-800">{item.label}</span>
              </div>
              <ChevronRight className="w-5 h-5 text-gray-400" />
            </button>
          );
        })}
      </div>

      {/* App Version */}
      <div className="bg-gray-50 rounded-2xl p-5 text-center">
        <p className="text-sm text-gray-600 mb-1">AgriVault Version</p>
        <p className="text-gray-800">1.0.0 (Beta)</p>
      </div>

      {/* Logout Button */}
      <Button 
        onClick={onLogout}
        variant="destructive" 
        className="w-full h-12 bg-red-500 hover:bg-red-600"
      >
        <LogOut className="w-5 h-5 mr-2" />
        Logout
      </Button>
    </div>
  );
}
