import { useState } from 'react';
import { ArrowLeft, ShoppingCart, Search, Filter, Star, MapPin, Package, Truck, Plus, Minus, Check, Clock } from 'lucide-react';
import { Button } from '../ui/button';
import { Input } from '../ui/input';
import { Badge } from '../ui/badge';

type View = 'home' | 'category' | 'product' | 'cart' | 'checkout' | 'confirmation' | 'orders' | 'orderDetail';

interface Product {
  id: string;
  name: string;
  brand: string;
  category: string;
  price: number;
  unit: string;
  image: string;
  rating: number;
  stock: 'In Stock' | 'Low Stock' | 'Out of Stock';
  cropTags: string[];
  description: string;
  usage: string;
}

interface CartItem extends Product {
  quantity: number;
}

interface Order {
  id: string;
  date: string;
  status: 'Confirmed' | 'Dispatched' | 'Delivered';
  items: CartItem[];
  total: number;
}

const categories = [
  { id: 'seeds', name: 'Seeds', icon: '🌱', color: 'from-green-500 to-green-600' },
  { id: 'fertilizers', name: 'Fertilizers', icon: '🧪', color: 'from-amber-500 to-amber-600' },
  { id: 'pesticides', name: 'Pesticides', icon: '🧴', color: 'from-red-500 to-red-600' },
  { id: 'medicines', name: 'Crop Medicines', icon: '💊', color: 'from-blue-500 to-blue-600' }
];

const products: Product[] = [
  {
    id: '1',
    name: 'Hybrid Wheat Seeds',
    brand: 'AgroMax',
    category: 'seeds',
    price: 2500,
    unit: 'per 10kg',
    image: 'https://images.unsplash.com/photo-1574943320219-553eb213f72d?w=400',
    rating: 4.5,
    stock: 'In Stock',
    cropTags: ['Wheat', 'Winter'],
    description: 'High-yield hybrid wheat seeds suitable for Punjab climate. Disease resistant variety with 15% higher yield.',
    usage: 'Sow in October-November. Use 50kg seeds per acre. Apply pre-sowing treatment.'
  },
  {
    id: '2',
    name: 'BT Cotton Seeds',
    brand: 'CropGen',
    category: 'seeds',
    price: 3200,
    unit: 'per 5kg',
    image: 'https://images.unsplash.com/photo-1615485290382-441e4d049cb5?w=400',
    rating: 4.8,
    stock: 'In Stock',
    cropTags: ['Cotton', 'Summer'],
    description: 'Bollworm resistant BT cotton seeds. Excellent fiber quality and yield potential of 35-40 maunds/acre.',
    usage: 'Plant in April-May. Maintain 2.5 feet row spacing. Requires regular irrigation.'
  },
  {
    id: '3',
    name: 'NPK Fertilizer (20-20-20)',
    brand: 'FertiFarm',
    category: 'fertilizers',
    price: 4500,
    unit: 'per 50kg',
    image: 'https://images.unsplash.com/photo-1625246333195-78d9c38ad449?w=400',
    rating: 4.3,
    stock: 'In Stock',
    cropTags: ['All Crops', 'Universal'],
    description: 'Balanced NPK fertilizer suitable for all crops. Promotes healthy growth and maximum yield.',
    usage: 'Apply 2-3 bags per acre based on soil test. Split application recommended for best results.'
  },
  {
    id: '4',
    name: 'Organic Compost',
    brand: 'GreenGold',
    category: 'fertilizers',
    price: 1200,
    unit: 'per 40kg',
    image: 'https://images.unsplash.com/photo-1615485736677-9e5a4d8f9e6e?w=400',
    rating: 4.6,
    stock: 'In Stock',
    cropTags: ['Organic', 'All Crops'],
    description: 'Premium organic compost made from farm waste. Improves soil structure and water retention.',
    usage: 'Mix into soil before planting. Use 10-15 bags per acre for best results.'
  },
  {
    id: '5',
    name: 'Insect Spray (Cypermethrin)',
    brand: 'CropShield',
    category: 'pesticides',
    price: 850,
    unit: 'per 500ml',
    image: 'https://images.unsplash.com/photo-1588681664899-f142ff2dc9b1?w=400',
    rating: 4.4,
    stock: 'Low Stock',
    cropTags: ['Cotton', 'Vegetables'],
    description: 'Effective against whitefly, aphids, and caterpillars. Fast acting with 15-day protection.',
    usage: 'Mix 200ml in 100L water. Spray in evening. Wear protective gear. Do not apply before rain.'
  },
  {
    id: '6',
    name: 'Fungicide (Mancozeb)',
    brand: 'FungiFix',
    category: 'pesticides',
    price: 1100,
    unit: 'per 1kg',
    image: 'https://images.unsplash.com/photo-1582719366960-bba0aa1ae5bb?w=400',
    rating: 4.7,
    stock: 'In Stock',
    cropTags: ['Tomato', 'Potato', 'Wheat'],
    description: 'Broad-spectrum fungicide for leaf spots, blight, and rust diseases.',
    usage: 'Mix 300g per 100L water. Apply at first disease symptoms. Repeat after 10-15 days.'
  },
  {
    id: '7',
    name: 'Plant Growth Booster',
    brand: 'VitaCrop',
    category: 'medicines',
    price: 650,
    unit: 'per 250ml',
    image: 'https://images.unsplash.com/photo-1603537662364-986a6b9ec75a?w=400',
    rating: 4.5,
    stock: 'In Stock',
    cropTags: ['All Crops'],
    description: 'Liquid plant growth promoter with micronutrients. Increases flowering and fruit setting.',
    usage: 'Spray 50ml per 15L water at flowering stage. Repeat every 15 days during fruiting.'
  },
  {
    id: '8',
    name: 'Calcium Supplement',
    brand: 'StrongPlant',
    category: 'medicines',
    price: 550,
    unit: 'per 500g',
    image: 'https://images.unsplash.com/photo-1607619056574-7b8d3ee536b2?w=400',
    rating: 4.2,
    stock: 'In Stock',
    cropTags: ['Tomato', 'Pepper', 'Apple'],
    description: 'Prevents blossom end rot and strengthens plant cell walls.',
    usage: 'Apply as foliar spray or soil drench. Mix 100g per 20L water. Apply weekly during fruit development.'
  }
];

export default function SupplierMarketplace() {
  const [view, setView] = useState<View>('home');
  const [selectedCategory, setSelectedCategory] = useState<string>('');
  const [selectedProduct, setSelectedProduct] = useState<Product | null>(null);
  const [cart, setCart] = useState<CartItem[]>([]);
  const [searchQuery, setSearchQuery] = useState('');
  const [orders] = useState<Order[]>([
    {
      id: 'ORD001',
      date: '2024-12-15',
      status: 'Delivered',
      items: [
        { ...products[0], quantity: 2 },
        { ...products[2], quantity: 1 }
      ],
      total: 9500
    },
    {
      id: 'ORD002',
      date: '2024-12-20',
      status: 'Dispatched',
      items: [
        { ...products[5], quantity: 3 }
      ],
      total: 3300
    }
  ]);
  const [selectedOrder, setSelectedOrder] = useState<Order | null>(null);
  const [deliveryAddress, setDeliveryAddress] = useState('Village Chak 23, Tehsil Jaranwala, Faisalabad');

  const filteredProducts = products.filter(p => 
    p.category === selectedCategory &&
    (searchQuery === '' || p.name.toLowerCase().includes(searchQuery.toLowerCase()) || 
     p.cropTags.some(tag => tag.toLowerCase().includes(searchQuery.toLowerCase())))
  );

  const addToCart = (product: Product) => {
    const existing = cart.find(item => item.id === product.id);
    if (existing) {
      setCart(cart.map(item => 
        item.id === product.id ? { ...item, quantity: item.quantity + 1 } : item
      ));
    } else {
      setCart([...cart, { ...product, quantity: 1 }]);
    }
  };

  const updateQuantity = (productId: string, delta: number) => {
    setCart(cart.map(item => {
      if (item.id === productId) {
        const newQuantity = item.quantity + delta;
        return { ...item, quantity: Math.max(1, newQuantity) };
      }
      return item;
    }).filter(item => item.quantity > 0));
  };

  const cartTotal = cart.reduce((sum, item) => sum + item.price * item.quantity, 0);

  // Background image style for agriculture theme
  const bgStyle = {
    backgroundImage: 'linear-gradient(to bottom, rgba(30, 127, 67, 0.08), rgba(255, 255, 255, 1) 40%), url(https://images.unsplash.com/photo-1560493676-04071c5f467b?w=800)',
    backgroundSize: 'cover',
    backgroundPosition: 'center top',
    backgroundRepeat: 'no-repeat'
  };

  // Marketplace Home
  if (view === 'home') {
    return (
      <div className="min-h-screen" style={bgStyle}>
        {/* Header */}
        <div className="bg-gradient-to-r from-[#1E7F43] to-[#15593A] text-white p-6 pb-8 rounded-b-3xl shadow-lg">
          <h1 className="mb-2 flex items-center gap-3">
            <ShoppingCart className="w-8 h-8" />
            Input Supplier Marketplace
          </h1>
          <p className="text-white/90 text-sm">Quality inputs at transparent prices</p>
        </div>

        <div className="p-4 space-y-4">
          {/* Categories */}
          <div className="grid grid-cols-2 gap-3">
            {categories.map((cat) => (
              <button
                key={cat.id}
                onClick={() => {
                  setSelectedCategory(cat.id);
                  setView('category');
                }}
                className={`bg-gradient-to-br ${cat.color} text-white rounded-2xl p-6 shadow-lg hover:shadow-xl transition-all transform hover:scale-105`}
              >
                <div className="text-4xl mb-2">{cat.icon}</div>
                <h3 className="text-white">{cat.name}</h3>
              </button>
            ))}
          </div>

          {/* Quick Actions */}
          <div className="bg-white rounded-2xl p-4 shadow-md space-y-3">
            <button
              onClick={() => setView('cart')}
              className="w-full flex items-center justify-between p-4 bg-gray-50 rounded-xl hover:bg-gray-100 transition-colors"
            >
              <div className="flex items-center gap-3">
                <ShoppingCart className="w-5 h-5 text-[#1E7F43]" />
                <span>My Cart</span>
              </div>
              {cart.length > 0 && (
                <Badge className="bg-[#1E7F43]">{cart.length}</Badge>
              )}
            </button>

            <button
              onClick={() => setView('orders')}
              className="w-full flex items-center justify-between p-4 bg-gray-50 rounded-xl hover:bg-gray-100 transition-colors"
            >
              <div className="flex items-center gap-3">
                <Package className="w-5 h-5 text-[#1E7F43]" />
                <span>Order History</span>
              </div>
            </button>
          </div>

          {/* Trust Indicators */}
          <div className="bg-gradient-to-r from-blue-50 to-green-50 rounded-2xl p-4 border border-blue-100">
            <div className="flex items-center gap-2 mb-2">
              <Check className="w-5 h-5 text-green-600" />
              <h4 className="text-gray-800">Why Buy Here?</h4>
            </div>
            <ul className="space-y-1 text-sm text-gray-600">
              <li>✓ Verified suppliers only</li>
              <li>✓ Transparent pricing</li>
              <li>✓ Quality guaranteed</li>
              <li>✓ Doorstep delivery</li>
            </ul>
          </div>
        </div>
      </div>
    );
  }

  // Category Product Listing
  if (view === 'category') {
    const category = categories.find(c => c.id === selectedCategory);
    
    return (
      <div className="min-h-screen bg-gray-50">
        {/* Header */}
        <div className="bg-white border-b sticky top-0 z-10">
          <div className="p-4">
            <button
              onClick={() => setView('home')}
              className="flex items-center gap-2 text-[#1E7F43] mb-3 hover:bg-green-50 p-2 rounded-full transition-colors"
            >
              <div className="bg-green-50 rounded-full p-1">
                <ArrowLeft className="w-5 h-5" />
              </div>
              <span>Back</span>
            </button>
            <h2 className="mb-3">{category?.icon} {category?.name}</h2>
            
            {/* Search */}
            <div className="relative">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
              <Input
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="Search products or crops..."
                className="pl-10 rounded-xl"
              />
            </div>
          </div>

          {/* Filters */}
          <div className="px-4 pb-3 flex gap-2 overflow-x-auto">
            <Button variant="outline" size="sm" className="rounded-full">
              <Filter className="w-4 h-4 mr-1" />
              Filters
            </Button>
            <Button variant="outline" size="sm" className="rounded-full whitespace-nowrap">Price: Low to High</Button>
            <Button variant="outline" size="sm" className="rounded-full whitespace-nowrap">In Stock</Button>
          </div>
        </div>

        {/* Products Grid */}
        <div className="p-4 grid grid-cols-2 gap-3 pb-20">
          {filteredProducts.map((product) => (
            <button
              key={product.id}
              onClick={() => {
                setSelectedProduct(product);
                setView('product');
              }}
              className="bg-white rounded-2xl overflow-hidden shadow-md hover:shadow-lg transition-shadow text-left"
            >
              <div className="aspect-square bg-gray-100 relative">
                <img src={product.image} alt={product.name} className="w-full h-full object-cover" />
                <Badge 
                  className={`absolute top-2 right-2 ${
                    product.stock === 'In Stock' ? 'bg-green-500' : 
                    product.stock === 'Low Stock' ? 'bg-orange-500' : 'bg-red-500'
                  }`}
                >
                  {product.stock}
                </Badge>
              </div>
              <div className="p-3">
                <p className="text-xs text-gray-500 mb-1">{product.brand}</p>
                <h4 className="text-sm mb-2 line-clamp-2">{product.name}</h4>
                
                <div className="flex flex-wrap gap-1 mb-2">
                  {product.cropTags.slice(0, 2).map((tag, idx) => (
                    <span key={idx} className="text-xs bg-green-50 text-green-700 px-2 py-0.5 rounded-full">
                      {tag}
                    </span>
                  ))}
                </div>

                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-green-600">PKR {product.price.toLocaleString()}</p>
                    <p className="text-xs text-gray-500">{product.unit}</p>
                  </div>
                  <div className="flex items-center gap-1 text-xs">
                    <Star className="w-3 h-3 fill-yellow-400 text-yellow-400" />
                    <span>{product.rating}</span>
                  </div>
                </div>
              </div>
            </button>
          ))}
        </div>

        {/* Cart FAB */}
        {cart.length > 0 && (
          <button
            onClick={() => setView('cart')}
            className="fixed bottom-6 right-6 bg-[#1E7F43] text-white rounded-full p-4 shadow-2xl hover:bg-[#15593A] z-50 flex items-center gap-2"
          >
            <ShoppingCart className="w-6 h-6" />
            <Badge className="bg-white text-[#1E7F43]">{cart.length}</Badge>
          </button>
        )}
      </div>
    );
  }

  // Product Detail Page
  if (view === 'product' && selectedProduct) {
    return (
      <div className="min-h-screen bg-gray-50 pb-24">
        {/* Header */}
        <div className="bg-white sticky top-0 z-10 border-b">
          <button
            onClick={() => setView('category')}
            className="flex items-center gap-2 text-[#1E7F43] p-4 hover:bg-green-50 transition-colors"
          >
            <div className="bg-green-50 rounded-full p-1">
              <ArrowLeft className="w-5 h-5" />
            </div>
            <span>Back</span>
          </button>
        </div>

        {/* Image Gallery */}
        <div className="bg-white">
          <div className="aspect-square bg-gray-100">
            <img src={selectedProduct.image} alt={selectedProduct.name} className="w-full h-full object-cover" />
          </div>
        </div>

        {/* Product Info */}
        <div className="p-4 space-y-4">
          <div className="bg-white rounded-2xl p-4 shadow-md">
            <div className="flex items-start justify-between mb-2">
              <div className="flex-1">
                <p className="text-sm text-gray-500 mb-1">{selectedProduct.brand}</p>
                <h2 className="mb-2">{selectedProduct.name}</h2>
              </div>
              <Badge className={`${
                selectedProduct.stock === 'In Stock' ? 'bg-green-500' : 
                selectedProduct.stock === 'Low Stock' ? 'bg-orange-500' : 'bg-red-500'
              }`}>
                {selectedProduct.stock}
              </Badge>
            </div>

            <div className="flex items-center gap-2 mb-3">
              <div className="flex items-center gap-1">
                <Star className="w-4 h-4 fill-yellow-400 text-yellow-400" />
                <span>{selectedProduct.rating}</span>
              </div>
              <span className="text-gray-400">•</span>
              <span className="text-sm text-gray-600">250+ orders</span>
            </div>

            <div className="flex flex-wrap gap-2 mb-4">
              {selectedProduct.cropTags.map((tag, idx) => (
                <Badge key={idx} variant="outline" className="bg-green-50 text-green-700 border-green-200">
                  {tag}
                </Badge>
              ))}
            </div>

            <div className="bg-gradient-to-r from-green-50 to-green-100 rounded-xl p-4 mb-4">
              <p className="text-2xl text-green-600 mb-1">PKR {selectedProduct.price.toLocaleString()}</p>
              <p className="text-sm text-gray-600">{selectedProduct.unit}</p>
            </div>

            <div className="space-y-3">
              <div>
                <h4 className="mb-2 flex items-center gap-2">
                  📝 Description
                </h4>
                <p className="text-sm text-gray-600">{selectedProduct.description}</p>
              </div>

              <div>
                <h4 className="mb-2 flex items-center gap-2">
                  💡 Usage Instructions
                </h4>
                <p className="text-sm text-gray-600">{selectedProduct.usage}</p>
              </div>
            </div>
          </div>

          {/* Supplier Info */}
          <div className="bg-white rounded-2xl p-4 shadow-md">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="w-12 h-12 bg-gradient-to-br from-[#1E7F43] to-[#15593A] rounded-full flex items-center justify-center text-white">
                  ✓
                </div>
                <div>
                  <p className="text-sm mb-0.5">Verified Supplier</p>
                  <div className="flex items-center gap-1 text-sm text-gray-500">
                    <MapPin className="w-3 h-3" />
                    <span>12 km away</span>
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* Delivery Options */}
          <div className="bg-white rounded-2xl p-4 shadow-md">
            <h4 className="mb-3">Delivery Options</h4>
            <div className="space-y-2">
              <div className="flex items-center gap-3 p-3 bg-green-50 rounded-xl border border-green-200">
                <Truck className="w-5 h-5 text-green-600" />
                <div className="flex-1">
                  <p className="text-sm mb-0.5">Home Delivery</p>
                  <p className="text-xs text-gray-600">2-3 days • Free over PKR 5000</p>
                </div>
                <input type="radio" name="delivery" defaultChecked className="accent-green-600" />
              </div>
              <div className="flex items-center gap-3 p-3 bg-gray-50 rounded-xl">
                <Package className="w-5 h-5 text-gray-600" />
                <div className="flex-1">
                  <p className="text-sm mb-0.5">Self Pickup</p>
                  <p className="text-xs text-gray-600">Available immediately</p>
                </div>
                <input type="radio" name="delivery" className="accent-green-600" />
              </div>
            </div>
          </div>
        </div>

        {/* Bottom Actions */}
        <div className="fixed bottom-0 left-0 right-0 bg-white border-t p-4 shadow-lg">
          <div className="flex gap-3 max-w-md mx-auto">
            <Button 
              variant="outline" 
              size="lg"
              onClick={() => addToCart(selectedProduct)}
              className="flex-1 rounded-xl border-[#1E7F43] text-[#1E7F43] hover:bg-green-50"
            >
              Add to Cart
            </Button>
            <Button 
              size="lg"
              onClick={() => {
                addToCart(selectedProduct);
                setView('cart');
              }}
              className="flex-1 rounded-xl bg-[#1E7F43] hover:bg-[#15593A]"
            >
              Order Now
            </Button>
          </div>
        </div>
      </div>
    );
  }

  // Cart View
  if (view === 'cart') {
    return (
      <div className="min-h-screen bg-gray-50 pb-32">
        {/* Header */}
        <div className="bg-white border-b sticky top-0 z-10">
          <button
            onClick={() => setView('home')}
            className="flex items-center gap-2 text-[#1E7F43] p-4 hover:bg-green-50 transition-colors"
          >
            <div className="bg-green-50 rounded-full p-1">
              <ArrowLeft className="w-5 h-5" />
            </div>
            <span>Back</span>
          </button>
          <div className="px-4 pb-4">
            <h2>My Cart ({cart.length})</h2>
          </div>
        </div>

        {cart.length === 0 ? (
          <div className="flex flex-col items-center justify-center p-8 mt-12">
            <ShoppingCart className="w-16 h-16 text-gray-300 mb-4" />
            <p className="text-gray-500 mb-4">Your cart is empty</p>
            <Button onClick={() => setView('home')} className="bg-[#1E7F43]">
              Start Shopping
            </Button>
          </div>
        ) : (
          <div className="p-4 space-y-3">
            {cart.map((item) => (
              <div key={item.id} className="bg-white rounded-2xl p-4 shadow-md">
                <div className="flex gap-3">
                  <img src={item.image} alt={item.name} className="w-20 h-20 object-cover rounded-xl" />
                  <div className="flex-1">
                    <p className="text-xs text-gray-500">{item.brand}</p>
                    <h4 className="text-sm mb-1">{item.name}</h4>
                    <p className="text-green-600 mb-2">PKR {item.price.toLocaleString()} <span className="text-xs text-gray-500">{item.unit}</span></p>
                    
                    <div className="flex items-center gap-3">
                      <div className="flex items-center gap-2 bg-gray-100 rounded-lg">
                        <button
                          onClick={() => updateQuantity(item.id, -1)}
                          className="p-2 hover:bg-gray-200 rounded-l-lg"
                        >
                          <Minus className="w-4 h-4" />
                        </button>
                        <span className="px-3">{item.quantity}</span>
                        <button
                          onClick={() => updateQuantity(item.id, 1)}
                          className="p-2 hover:bg-gray-200 rounded-r-lg"
                        >
                          <Plus className="w-4 h-4" />
                        </button>
                      </div>
                      <p className="text-sm">
                        Total: <span className="text-green-600">PKR {(item.price * item.quantity).toLocaleString()}</span>
                      </p>
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}

        {/* Bottom Summary */}
        {cart.length > 0 && (
          <div className="fixed bottom-0 left-0 right-0 bg-white border-t p-4 shadow-lg">
            <div className="max-w-md mx-auto space-y-3">
              <div className="flex items-center justify-between text-sm">
                <span className="text-gray-600">Subtotal</span>
                <span>PKR {cartTotal.toLocaleString()}</span>
              </div>
              <div className="flex items-center justify-between text-sm">
                <span className="text-gray-600">Delivery</span>
                <span className="text-green-600">Free</span>
              </div>
              <div className="border-t pt-2 flex items-center justify-between">
                <span>Total</span>
                <span className="text-xl text-green-600">PKR {cartTotal.toLocaleString()}</span>
              </div>
              <Button 
                size="lg"
                onClick={() => setView('checkout')}
                className="w-full rounded-xl bg-[#1E7F43] hover:bg-[#15593A]"
              >
                Proceed to Checkout
              </Button>
            </div>
          </div>
        )}
      </div>
    );
  }

  // Checkout View
  if (view === 'checkout') {
    return (
      <div className="min-h-screen bg-gray-50 pb-32">
        {/* Header */}
        <div className="bg-white border-b sticky top-0 z-10">
          <button
            onClick={() => setView('cart')}
            className="flex items-center gap-2 text-[#1E7F43] p-4 hover:bg-green-50 transition-colors"
          >
            <div className="bg-green-50 rounded-full p-1">
              <ArrowLeft className="w-5 h-5" />
            </div>
            <span>Back</span>
          </button>
          <div className="px-4 pb-4">
            <h2>Checkout</h2>
          </div>
        </div>

        <div className="p-4 space-y-4">
          {/* Delivery Address */}
          <div className="bg-white rounded-2xl p-4 shadow-md">
            <h4 className="mb-3 flex items-center gap-2">
              <MapPin className="w-5 h-5 text-[#1E7F43]" />
              Delivery Address
            </h4>
            <div className="p-3 bg-green-50 rounded-xl border border-green-200">
              <p className="text-sm mb-2">{deliveryAddress}</p>
              <button className="text-[#1E7F43] text-sm hover:underline">Change Address</button>
            </div>
          </div>

          {/* Order Summary */}
          <div className="bg-white rounded-2xl p-4 shadow-md">
            <h4 className="mb-3">Order Summary</h4>
            <div className="space-y-2 mb-3">
              {cart.map((item) => (
                <div key={item.id} className="flex items-center justify-between text-sm">
                  <span className="text-gray-600">{item.name} x{item.quantity}</span>
                  <span>PKR {(item.price * item.quantity).toLocaleString()}</span>
                </div>
              ))}
            </div>
            <div className="border-t pt-2 flex items-center justify-between">
              <span>Total Amount</span>
              <span className="text-xl text-green-600">PKR {cartTotal.toLocaleString()}</span>
            </div>
          </div>

          {/* Payment Options */}
          <div className="bg-white rounded-2xl p-4 shadow-md">
            <h4 className="mb-3">Payment Method</h4>
            <div className="space-y-2">
              <div className="flex items-center gap-3 p-3 bg-green-50 rounded-xl border-2 border-green-500">
                <input type="radio" name="payment" defaultChecked className="accent-green-600" />
                <div className="flex-1">
                  <p className="text-sm mb-0.5">Cash on Delivery</p>
                  <p className="text-xs text-gray-600">Pay when you receive</p>
                </div>
                <Badge className="bg-green-600">Available Now</Badge>
              </div>
              <div className="flex items-center gap-3 p-3 bg-gray-50 rounded-xl border-2 border-gray-200 opacity-60">
                <input type="radio" name="payment" disabled className="accent-green-600" />
                <div className="flex-1">
                  <p className="text-sm mb-0.5">AgriVault Wallet</p>
                  <p className="text-xs text-gray-600">Balance: PKR 0</p>
                </div>
                <Badge variant="outline">Coming Soon</Badge>
              </div>
            </div>
          </div>
        </div>

        {/* Bottom Actions */}
        <div className="fixed bottom-0 left-0 right-0 bg-white border-t p-4 shadow-lg">
          <div className="max-w-md mx-auto">
            <Button 
              size="lg"
              onClick={() => {
                setView('confirmation');
                setCart([]);
              }}
              className="w-full rounded-xl bg-[#1E7F43] hover:bg-[#15593A]"
            >
              Place Order • PKR {cartTotal.toLocaleString()}
            </Button>
          </div>
        </div>
      </div>
    );
  }

  // Order Confirmation
  if (view === 'confirmation') {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center p-4">
        <div className="bg-white rounded-3xl p-8 shadow-xl max-w-md w-full text-center">
          <div className="w-20 h-20 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-4">
            <Check className="w-10 h-10 text-green-600" />
          </div>
          <h2 className="mb-2">Order Placed Successfully! 🎉</h2>
          <p className="text-gray-600 mb-6">Your order has been confirmed and will be delivered in 2-3 days.</p>
          
          <div className="bg-green-50 rounded-2xl p-4 mb-6">
            <p className="text-sm text-gray-600 mb-1">Order ID</p>
            <p className="text-xl text-green-600">ORD{Date.now().toString().slice(-6)}</p>
          </div>

          <div className="space-y-2">
            <Button 
              size="lg"
              onClick={() => setView('orders')}
              className="w-full rounded-xl bg-[#1E7F43] hover:bg-[#15593A]"
            >
              Track Order
            </Button>
            <Button 
              size="lg"
              variant="outline"
              onClick={() => setView('home')}
              className="w-full rounded-xl"
            >
              Continue Shopping
            </Button>
          </div>
        </div>
      </div>
    );
  }

  // Order History
  if (view === 'orders') {
    return (
      <div className="min-h-screen bg-gray-50">
        {/* Header */}
        <div className="bg-white border-b sticky top-0 z-10">
          <button
            onClick={() => setView('home')}
            className="flex items-center gap-2 text-[#1E7F43] p-4 hover:bg-green-50 transition-colors"
          >
            <div className="bg-green-50 rounded-full p-1">
              <ArrowLeft className="w-5 h-5" />
            </div>
            <span>Back</span>
          </button>
          <div className="px-4 pb-4">
            <h2>Order History</h2>
          </div>
        </div>

        <div className="p-4 space-y-3">
          {orders.map((order) => (
            <button
              key={order.id}
              onClick={() => {
                setSelectedOrder(order);
                setView('orderDetail');
              }}
              className="w-full bg-white rounded-2xl p-4 shadow-md hover:shadow-lg transition-shadow text-left"
            >
              <div className="flex items-center justify-between mb-3">
                <div>
                  <p className="text-sm text-gray-500">Order {order.id}</p>
                  <p className="text-xs text-gray-400">{new Date(order.date).toLocaleDateString()}</p>
                </div>
                <Badge className={
                  order.status === 'Delivered' ? 'bg-green-500' :
                  order.status === 'Dispatched' ? 'bg-blue-500' : 'bg-orange-500'
                }>
                  {order.status}
                </Badge>
              </div>

              <div className="space-y-1 mb-3">
                {order.items.map((item, idx) => (
                  <p key={idx} className="text-sm text-gray-600">
                    {item.name} x{item.quantity}
                  </p>
                ))}
              </div>

              <div className="flex items-center justify-between pt-3 border-t">
                <span className="text-sm text-gray-600">Total</span>
                <span className="text-green-600">PKR {order.total.toLocaleString()}</span>
              </div>
            </button>
          ))}
        </div>
      </div>
    );
  }

  // Order Detail
  if (view === 'orderDetail' && selectedOrder) {
    return (
      <div className="min-h-screen bg-gray-50">
        {/* Header */}
        <div className="bg-white border-b sticky top-0 z-10">
          <button
            onClick={() => setView('orders')}
            className="flex items-center gap-2 text-[#1E7F43] p-4 hover:bg-green-50 transition-colors"
          >
            <div className="bg-green-50 rounded-full p-1">
              <ArrowLeft className="w-5 h-5" />
            </div>
            <span>Back</span>
          </button>
          <div className="px-4 pb-4">
            <h2>Order {selectedOrder.id}</h2>
            <p className="text-sm text-gray-500">{new Date(selectedOrder.date).toLocaleDateString()}</p>
          </div>
        </div>

        <div className="p-4 space-y-4">
          {/* Status Timeline */}
          <div className="bg-white rounded-2xl p-4 shadow-md">
            <h4 className="mb-4">Order Status</h4>
            <div className="space-y-3">
              <div className="flex items-center gap-3">
                <div className="w-8 h-8 bg-green-500 rounded-full flex items-center justify-center text-white">
                  <Check className="w-5 h-5" />
                </div>
                <div className="flex-1">
                  <p className="text-sm">Confirmed</p>
                  <p className="text-xs text-gray-500">{selectedOrder.date}</p>
                </div>
              </div>

              {(selectedOrder.status === 'Dispatched' || selectedOrder.status === 'Delivered') && (
                <div className="flex items-center gap-3">
                  <div className="w-8 h-8 bg-green-500 rounded-full flex items-center justify-center text-white">
                    <Truck className="w-4 h-4" />
                  </div>
                  <div className="flex-1">
                    <p className="text-sm">Dispatched</p>
                    <p className="text-xs text-gray-500">In transit</p>
                  </div>
                </div>
              )}

              {selectedOrder.status === 'Delivered' && (
                <div className="flex items-center gap-3">
                  <div className="w-8 h-8 bg-green-500 rounded-full flex items-center justify-center text-white">
                    <Package className="w-4 h-4" />
                  </div>
                  <div className="flex-1">
                    <p className="text-sm">Delivered</p>
                    <p className="text-xs text-gray-500">Order completed</p>
                  </div>
                </div>
              )}

              {selectedOrder.status !== 'Delivered' && (
                <div className="flex items-center gap-3 opacity-40">
                  <div className="w-8 h-8 bg-gray-300 rounded-full flex items-center justify-center">
                    <Clock className="w-4 h-4 text-gray-600" />
                  </div>
                  <div className="flex-1">
                    <p className="text-sm">Awaiting Delivery</p>
                    <p className="text-xs text-gray-500">Estimated 1-2 days</p>
                  </div>
                </div>
              )}
            </div>
          </div>

          {/* Items */}
          <div className="bg-white rounded-2xl p-4 shadow-md">
            <h4 className="mb-3">Order Items</h4>
            <div className="space-y-3">
              {selectedOrder.items.map((item, idx) => (
                <div key={idx} className="flex gap-3">
                  <img src={item.image} alt={item.name} className="w-16 h-16 object-cover rounded-xl" />
                  <div className="flex-1">
                    <p className="text-sm mb-1">{item.name}</p>
                    <p className="text-xs text-gray-500">Qty: {item.quantity}</p>
                    <p className="text-green-600 text-sm">PKR {(item.price * item.quantity).toLocaleString()}</p>
                  </div>
                </div>
              ))}
            </div>

            <div className="border-t mt-3 pt-3 flex items-center justify-between">
              <span>Total Amount</span>
              <span className="text-xl text-green-600">PKR {selectedOrder.total.toLocaleString()}</span>
            </div>
          </div>

          {/* Actions */}
          {selectedOrder.status === 'Delivered' && (
            <Button 
              size="lg"
              className="w-full rounded-xl bg-[#1E7F43] hover:bg-[#15593A]"
            >
              Reorder
            </Button>
          )}
        </div>
      </div>
    );
  }

  return null;
}
