import { CloudSun, CloudRain, Wind, Droplets, Thermometer, AlertTriangle, Sun, Cloud } from 'lucide-react';

export default function WeatherModule() {
  const weeklyForecast = [
    { day: 'Mon', temp: 32, icon: Sun, condition: 'Sunny', rain: 0 },
    { day: 'Tue', temp: 34, icon: Sun, condition: 'Hot', rain: 0 },
    { day: 'Wed', temp: 36, icon: AlertTriangle, condition: 'Heatwave', rain: 0 },
    { day: 'Thu', temp: 35, icon: Sun, condition: 'Hot', rain: 5 },
    { day: 'Fri', temp: 30, icon: CloudRain, condition: 'Rain', rain: 80 },
    { day: 'Sat', temp: 28, icon: Cloud, condition: 'Cloudy', rain: 20 },
    { day: 'Sun', temp: 29, icon: CloudSun, condition: 'Partly Cloudy', rain: 10 }
  ];

  return (
    <div className="p-4 space-y-4">
      {/* Location */}
      <div>
        <h2 className="text-gray-800 text-xl mb-1">Weather Forecast</h2>
        <p className="text-gray-600 text-sm">Lahore, Punjab</p>
      </div>

      {/* Critical Weather Alert */}
      <div className="bg-gradient-to-r from-orange-500 to-red-500 text-white rounded-2xl p-5">
        <div className="flex items-start gap-3">
          <AlertTriangle className="w-6 h-6 flex-shrink-0 mt-0.5" />
          <div>
            <h3 className="mb-1">Heatwave Warning</h3>
            <p className="text-sm text-white/90 mb-2">Expected in 48 hours (Wednesday)</p>
            <p className="text-sm text-white/80">
              Temperature may reach 36°C. Consider early morning harvesting and ensure crops are stored in cool conditions.
            </p>
          </div>
        </div>
      </div>

      {/* Current Weather */}
      <div className="bg-gradient-to-br from-blue-500 to-blue-600 text-white rounded-2xl p-6">
        <div className="flex items-start justify-between mb-4">
          <div>
            <p className="text-white/80 text-sm mb-1">Today, Dec 20</p>
            <div className="flex items-center gap-2">
              <h2 className="text-5xl">32°C</h2>
              <Sun className="w-12 h-12" />
            </div>
            <p className="mt-2">Sunny & Clear</p>
          </div>
        </div>

        <div className="grid grid-cols-3 gap-4 mt-6 pt-4 border-t border-white/20">
          <div className="text-center">
            <Droplets className="w-5 h-5 mx-auto mb-1 text-white/80" />
            <p className="text-sm text-white/70">Humidity</p>
            <p className="text-lg">65%</p>
          </div>
          <div className="text-center">
            <Wind className="w-5 h-5 mx-auto mb-1 text-white/80" />
            <p className="text-sm text-white/70">Wind</p>
            <p className="text-lg">12 km/h</p>
          </div>
          <div className="text-center">
            <CloudRain className="w-5 h-5 mx-auto mb-1 text-white/80" />
            <p className="text-sm text-white/70">Rain</p>
            <p className="text-lg">0%</p>
          </div>
        </div>
      </div>

      {/* 7-Day Forecast */}
      <div className="bg-white rounded-2xl p-5">
        <h3 className="text-gray-800 mb-4">7-Day Forecast</h3>
        <div className="space-y-3">
          {weeklyForecast.map((day, idx) => {
            const Icon = day.icon;
            const isHeatwave = day.condition === 'Heatwave';
            return (
              <div 
                key={idx} 
                className={`flex items-center justify-between p-3 rounded-xl ${
                  isHeatwave ? 'bg-orange-50 border-2 border-orange-300' : 'bg-gray-50'
                }`}
              >
                <div className="flex items-center gap-3">
                  <div className={`w-10 h-10 rounded-full flex items-center justify-center ${
                    isHeatwave ? 'bg-orange-200' : 'bg-blue-100'
                  }`}>
                    <Icon className={`w-5 h-5 ${isHeatwave ? 'text-orange-600' : 'text-blue-600'}`} />
                  </div>
                  <div>
                    <p className="text-gray-800">{day.day}</p>
                    <p className="text-sm text-gray-600">{day.condition}</p>
                  </div>
                </div>
                <div className="text-right">
                  <p className="text-gray-800 text-lg">{day.temp}°C</p>
                  {day.rain > 0 && (
                    <p className="text-sm text-blue-600">{day.rain}% rain</p>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Rain Forecast Timeline */}
      <div className="bg-white rounded-2xl p-5">
        <h3 className="text-gray-800 mb-4 flex items-center gap-2">
          <CloudRain className="w-5 h-5 text-blue-500" />
          Rain Expected Friday
        </h3>
        <div className="bg-blue-50 rounded-xl p-4">
          <p className="text-sm text-blue-800 mb-3">
            Heavy rainfall expected on Friday afternoon (80% probability). Plan harvest activities accordingly.
          </p>
          <div className="flex items-center justify-between text-sm">
            <span className="text-blue-600">Expected: 20-30mm</span>
            <span className="text-blue-600">Duration: 3-4 hours</span>
          </div>
        </div>
      </div>

      {/* Agricultural Advisory */}
      <div className="bg-green-50 rounded-2xl p-5 border-2 border-green-200">
        <h3 className="text-green-800 mb-3">📋 Agricultural Advisory</h3>
        <ul className="space-y-2 text-sm text-gray-700">
          <li className="flex items-start gap-2">
            <span className="text-green-600">•</span>
            <span>Avoid harvesting on Wednesday due to high temperature</span>
          </li>
          <li className="flex items-start gap-2">
            <span className="text-green-600">•</span>
            <span>Ensure adequate irrigation before heatwave</span>
          </li>
          <li className="flex items-start gap-2">
            <span className="text-green-600">•</span>
            <span>Book cold storage to protect harvested crops from heat damage</span>
          </li>
          <li className="flex items-start gap-2">
            <span className="text-green-600">•</span>
            <span>Complete harvesting before Friday's rain</span>
          </li>
        </ul>
      </div>
    </div>
  );
}
