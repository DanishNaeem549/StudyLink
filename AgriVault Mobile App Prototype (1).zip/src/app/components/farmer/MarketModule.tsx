import { useState } from 'react';
import { TrendingUp, TrendingDown, MapPin, LineChart, ShoppingBag, ArrowRight } from 'lucide-react';
import { AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';
import MarketplaceDemo from '../marketplace/MarketplaceDemo';
import { Button } from '../ui/button';

export default function MarketModule() {
  const [selectedCrop, setSelectedCrop] = useState('tomato');
  const [showMarketplace, setShowMarketplace] = useState(false);

  // If marketplace is open, show it full screen
  if (showMarketplace) {
    return <MarketplaceDemo onClose={() => setShowMarketplace(false)} />;
  }

  const marketPrices = [
    { crop: 'Tomato', price: 45, change: 12, trend: 'up', city: 'Lahore', status: 'excellent' },
    { crop: 'Onion', price: 35, change: 8, trend: 'up', city: 'Karachi', status: 'good' },
    { crop: 'Potato', price: 28, change: -5, trend: 'down', city: 'Faisalabad', status: 'fair' },
    { crop: 'Wheat', price: 72, change: 3, trend: 'up', city: 'Multan', status: 'good' },
    { crop: 'Rice', price: 95, change: -2, trend: 'down', city: 'Lahore', status: 'fair' },
    { crop: 'Mango', price: 120, change: 15, trend: 'up', city: 'Karachi', status: 'excellent' }
  ];

  const priceHistory = [
    { date: 'Dec 14', price: 38 },
    { date: 'Dec 15', price: 40 },
    { date: 'Dec 16', price: 39 },
    { date: 'Dec 17', price: 42 },
    { date: 'Dec 18', price: 43 },
    { date: 'Dec 19', price: 44 },
    { date: 'Dec 20', price: 45 }
  ];

  const cities = [
    { name: 'Lahore Mandi', price: 45, distance: '5 km' },
    { name: 'Karachi Market', price: 52, distance: '1200 km' },
    { name: 'Faisalabad Mandi', price: 42, distance: '120 km' },
    { name: 'Multan Market', price: 47, distance: '350 km' }
  ];

  return (
    <div className="p-4 space-y-4">
      {/* Header */}
      <div>
        <h2 className="text-gray-800 text-xl mb-1">Live Market Prices</h2>
        <p className="text-gray-600 text-sm">Updated 10 minutes ago</p>
      </div>

      {/* Featured Price - Best Time to Sell */}
      <div className="bg-gradient-to-r from-green-500 to-green-600 text-white rounded-2xl p-5">
        <div className="flex items-center gap-2 mb-2">
          <div className="bg-white text-green-600 px-3 py-1 rounded-full text-sm">Best Time to Sell</div>
        </div>
        <h3 className="text-2xl mb-2">Tomatoes</h3>
        <div className="flex items-end gap-2 mb-3">
          <span className="text-4xl">₨45</span>
          <span className="text-lg text-white/80 mb-1">/kg</span>
          <div className="flex items-center gap-1 bg-white/20 px-2 py-1 rounded-full text-sm mb-1">
            <TrendingUp className="w-4 h-4" />
            <span>↑12%</span>
          </div>
        </div>
        <p className="text-white/90 text-sm">Prices are 12% higher than last week. Excellent time to sell in Lahore Mandi!</p>
      </div>

      {/* Price List */}
      <div className="bg-white rounded-2xl p-5">
        <h3 className="text-gray-800 mb-4">Today's Prices</h3>
        <div className="space-y-3">
          {marketPrices.map((item, idx) => (
            <div key={idx} className="flex items-center justify-between p-3 bg-gray-50 rounded-xl">
              <div className="flex items-center gap-3">
                <div className={`w-12 h-12 rounded-full flex items-center justify-center ${
                  item.status === 'excellent' ? 'bg-green-100' :
                  item.status === 'good' ? 'bg-blue-100' : 'bg-gray-100'
                }`}>
                  <span className="text-2xl">
                    {item.crop === 'Tomato' ? '🍅' :
                     item.crop === 'Onion' ? '🧅' :
                     item.crop === 'Potato' ? '🥔' :
                     item.crop === 'Wheat' ? '🌾' :
                     item.crop === 'Rice' ? '🌾' : '🥭'}
                  </span>
                </div>
                <div>
                  <h4 className="text-gray-800">{item.crop}</h4>
                  <p className="text-sm text-gray-500 flex items-center gap-1">
                    <MapPin className="w-3 h-3" />
                    {item.city}
                  </p>
                </div>
              </div>
              <div className="text-right">
                <p className="text-gray-800 text-lg">₨{item.price}/kg</p>
                <div className={`flex items-center gap-1 text-sm ${
                  item.trend === 'up' ? 'text-green-600' : 'text-red-600'
                }`}>
                  {item.trend === 'up' ? <TrendingUp className="w-4 h-4" /> : <TrendingDown className="w-4 h-4" />}
                  <span>{item.change > 0 ? '+' : ''}{item.change}%</span>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Price Trends Chart */}
      <div className="bg-white rounded-2xl p-5">
        <div className="flex items-center justify-between mb-4">
          <h3 className="text-gray-800">Price Trends - Tomato</h3>
          <LineChart className="w-5 h-5 text-gray-400" />
        </div>
        <ResponsiveContainer width="100%" height={200}>
          <AreaChart data={priceHistory}>
            <defs>
              <linearGradient id="colorPrice" x1="0" y1="0" x2="0" y2="1">
                <stop offset="5%" stopColor="#1E7F43" stopOpacity={0.3}/>
                <stop offset="95%" stopColor="#1E7F43" stopOpacity={0}/>
              </linearGradient>
            </defs>
            <CartesianGrid strokeDasharray="3 3" stroke="#f0f0f0" />
            <XAxis dataKey="date" tick={{ fontSize: 12 }} stroke="#999" />
            <YAxis tick={{ fontSize: 12 }} stroke="#999" />
            <Tooltip 
              contentStyle={{ backgroundColor: '#fff', border: '1px solid #e0e0e0', borderRadius: '8px' }}
              formatter={(value) => [`₨${value}/kg`, 'Price']}
            />
            <Area type="monotone" dataKey="price" stroke="#1E7F43" strokeWidth={2} fillOpacity={1} fill="url(#colorPrice)" />
          </AreaChart>
        </ResponsiveContainer>
        <p className="text-sm text-gray-600 mt-3 text-center">7-day price trend showing 18% increase</p>
      </div>

      {/* City-wise Comparison */}
      <div className="bg-white rounded-2xl p-5">
        <h3 className="text-gray-800 mb-4">Compare Markets - Tomato</h3>
        <div className="space-y-3">
          {cities.map((city, idx) => (
            <div key={idx} className="flex items-center justify-between p-4 border-2 border-gray-200 rounded-xl">
              <div>
                <h4 className="text-gray-800">{city.name}</h4>
                <p className="text-sm text-gray-500">{city.distance} away</p>
              </div>
              <div className="text-right">
                <p className="text-gray-800 text-xl">₨{city.price}/kg</p>
                {idx === 1 && (
                  <span className="text-xs text-green-600">Best price</span>
                )}
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Market Advisory */}
      <div className="bg-blue-50 rounded-2xl p-5 border-2 border-blue-200">
        <h3 className="text-blue-800 mb-3">📊 Market Advisory</h3>
        <ul className="space-y-2 text-sm text-gray-700">
          <li className="flex items-start gap-2">
            <span className="text-blue-600">•</span>
            <span>Current tomato prices are at seasonal peak - excellent time to sell</span>
          </li>
          <li className="flex items-start gap-2">
            <span className="text-blue-600">•</span>
            <span>Karachi market offering 16% higher prices but factor in transport costs</span>
          </li>
          <li className="flex items-start gap-2">
            <span className="text-blue-600">•</span>
            <span>Prices expected to stabilize by next week due to increased supply</span>
          </li>
          <li className="flex items-start gap-2">
            <span className="text-blue-600">•</span>
            <span>Consider cold storage to wait for better prices if possible</span>
          </li>
        </ul>
      </div>

      {/* Marketplace CTA Card */}
      <div className="bg-gradient-to-br from-[#1E7F43] to-[#15593A] rounded-2xl p-6 text-white">
        <div className="flex items-center gap-3 mb-3">
          <div className="w-12 h-12 bg-white/20 rounded-full flex items-center justify-center">
            <ShoppingBag className="w-6 h-6" />
          </div>
          <div className="flex-1">
            <h3 className="text-xl font-semibold">List Your Produce</h3>
            <p className="text-white/80 text-sm">Get competitive bids from verified buyers</p>
          </div>
        </div>
        <Button
          onClick={() => setShowMarketplace(true)}
          className="w-full bg-white text-[#1E7F43] hover:bg-gray-100 font-semibold flex items-center justify-center gap-2"
        >
          Start Selling
          <ArrowRight className="w-4 h-4" />
        </Button>
      </div>
    </div>
  );
}