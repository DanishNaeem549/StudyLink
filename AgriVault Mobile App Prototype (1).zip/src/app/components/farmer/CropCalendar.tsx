import { Calendar as CalendarIcon, Leaf, Droplets, Sprout, Package, AlertCircle } from 'lucide-react';

export default function CropCalendar() {
  const crops = [
    {
      name: 'Tomatoes',
      icon: '🍅',
      acres: 5,
      sowingDate: 'Oct 15, 2024',
      harvestDate: 'Dec 23, 2024',
      status: 'ready',
      stages: [
        { name: 'Sowing', date: 'Oct 15', completed: true },
        { name: 'First Fertilizer', date: 'Oct 30', completed: true },
        { name: 'Irrigation', date: 'Nov 10', completed: true },
        { name: 'Second Fertilizer', date: 'Nov 25', completed: true },
        { name: 'Pest Control', date: 'Dec 5', completed: true },
        { name: 'Harvest', date: 'Dec 23', completed: false, upcoming: true }
      ]
    },
    {
      name: 'Wheat',
      icon: '🌾',
      acres: 10,
      sowingDate: 'Nov 5, 2024',
      harvestDate: 'Apr 10, 2025',
      status: 'growing',
      stages: [
        { name: 'Sowing', date: 'Nov 5', completed: true },
        { name: 'First Irrigation', date: 'Nov 20', completed: true },
        { name: 'First Fertilizer', date: 'Dec 15', completed: false, upcoming: true },
        { name: 'Second Irrigation', date: 'Jan 5', completed: false },
        { name: 'Second Fertilizer', date: 'Feb 1', completed: false },
        { name: 'Harvest', date: 'Apr 10', completed: false }
      ]
    }
  ];

  return (
    <div className="p-4 space-y-4">
      <div>
        <h2 className="text-gray-800 text-xl mb-1">Crop Calendar</h2>
        <p className="text-gray-600 text-sm">Track your crop lifecycle</p>
      </div>

      {/* Active Crops */}
      {crops.map((crop, idx) => (
        <div key={idx} className="bg-white rounded-2xl p-5 border-2 border-gray-200">
          <div className="flex items-center gap-3 mb-4">
            <span className="text-4xl">{crop.icon}</span>
            <div className="flex-1">
              <h3 className="text-gray-800 text-lg">{crop.name}</h3>
              <p className="text-sm text-gray-600">{crop.acres} acres</p>
            </div>
            <div className={`px-3 py-1 rounded-full text-sm ${
              crop.status === 'ready' ? 'bg-green-100 text-green-700' : 'bg-blue-100 text-blue-700'
            }`}>
              {crop.status === 'ready' ? 'Harvest Ready' : 'Growing'}
            </div>
          </div>

          {/* Timeline */}
          <div className="space-y-3">
            {crop.stages.map((stage, stageIdx) => (
              <div key={stageIdx} className="flex items-start gap-3">
                <div className={`w-8 h-8 rounded-full flex items-center justify-center flex-shrink-0 ${
                  stage.completed ? 'bg-green-500' : stage.upcoming ? 'bg-orange-500' : 'bg-gray-300'
                }`}>
                  {stage.completed ? (
                    <Leaf className="w-4 h-4 text-white" />
                  ) : stage.upcoming ? (
                    <AlertCircle className="w-4 h-4 text-white" />
                  ) : (
                    <div className="w-2 h-2 bg-white rounded-full"></div>
                  )}
                </div>
                <div className="flex-1 pt-1">
                  <div className="flex items-center justify-between mb-1">
                    <h4 className={`text-sm ${stage.completed ? 'text-gray-600' : 'text-gray-800'}`}>
                      {stage.name}
                    </h4>
                    <span className="text-xs text-gray-500">{stage.date}</span>
                  </div>
                  {stage.upcoming && (
                    <p className="text-xs text-orange-600">Due in 2 days</p>
                  )}
                </div>
              </div>
            ))}
          </div>

          {/* Dates */}
          <div className="mt-4 pt-4 border-t grid grid-cols-2 gap-4 text-sm">
            <div>
              <p className="text-gray-500 mb-1">Sowing Date</p>
              <p className="text-gray-800">{crop.sowingDate}</p>
            </div>
            <div>
              <p className="text-gray-500 mb-1">Harvest Date</p>
              <p className="text-gray-800">{crop.harvestDate}</p>
            </div>
          </div>
        </div>
      ))}

      {/* Add New Crop */}
      <button className="w-full bg-gradient-to-r from-[#1E7F43] to-[#15593A] text-white rounded-2xl p-5 flex items-center justify-center gap-2 hover:shadow-lg transition-shadow">
        <Sprout className="w-6 h-6" />
        <span>Add New Crop</span>
      </button>

      {/* Reminders */}
      <div className="bg-orange-50 rounded-2xl p-5 border-2 border-orange-200">
        <h3 className="text-orange-800 mb-3 flex items-center gap-2">
          <AlertCircle className="w-5 h-5" />
          Upcoming Tasks
        </h3>
        <div className="space-y-2">
          <div className="flex items-center justify-between p-3 bg-white rounded-xl">
            <div className="flex items-center gap-3">
              <Droplets className="w-5 h-5 text-blue-500" />
              <div>
                <p className="text-sm text-gray-800">Wheat - Second Fertilizer</p>
                <p className="text-xs text-gray-500">Due in 2 days</p>
              </div>
            </div>
          </div>
          <div className="flex items-center justify-between p-3 bg-white rounded-xl">
            <div className="flex items-center gap-3">
              <Package className="w-5 h-5 text-green-500" />
              <div>
                <p className="text-sm text-gray-800">Tomatoes - Harvest</p>
                <p className="text-xs text-gray-500">Ready in 3 days</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
