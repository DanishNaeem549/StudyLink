import { useState, useEffect } from 'react';
import { ArrowLeft, TrendingUp, Clock, Users, Gavel, AlertCircle, CheckCircle, Eye, DollarSign, Package, Truck, Shield, Sparkles } from 'lucide-react';
import { Button } from '../ui/button';
import { Input } from '../ui/input';
import { Badge } from '../ui/badge';
import { Progress } from '../ui/progress';

type View = 'home' | 'listProduce' | 'setPriceRules' | 'reviewPublish' | 'auctionDetail' | 'bidding' | 'transaction' | 'myListings';

interface Auction {
  id: string;
  cropName: string;
  quantity: number;
  grade: 'A' | 'B' | 'C';
  minPrice: number;
  currentBid: number;
  preferredPrice: number;
  endTime: number;
  watchers: number;
  bids: number;
  image: string;
  farmerName: string;
  location: string;
  verified: boolean;
  trustScore: number;
  storageHistory?: string;
}

interface Bid {
  bidder: string;
  amount: number;
  time: string;
}

const liveAuctions: Auction[] = [
  {
    id: 'AUC001',
    cropName: 'Premium Wheat',
    quantity: 500,
    grade: 'A',
    minPrice: 42,
    currentBid: 48,
    preferredPrice: 50,
    endTime: Date.now() + 3600000,
    watchers: 12,
    bids: 8,
    image: 'https://images.unsplash.com/photo-1574943320219-553eb213f72d?w=400',
    farmerName: 'Ahmed Malik',
    location: 'Faisalabad',
    verified: true,
    trustScore: 95,
    storageHistory: 'Stored at ThandaHub for 15 days - Perfect condition'
  },
  {
    id: 'AUC002',
    cropName: 'Fresh Tomatoes',
    quantity: 200,
    grade: 'A',
    minPrice: 45,
    currentBid: 52,
    preferredPrice: 55,
    endTime: Date.now() + 7200000,
    watchers: 8,
    bids: 5,
    image: 'https://images.unsplash.com/photo-1546094096-0df4bcaaa337?w=400',
    farmerName: 'Hassan Khan',
    location: 'Multan',
    verified: true,
    trustScore: 88
  },
  {
    id: 'AUC003',
    cropName: 'BT Cotton',
    quantity: 1000,
    grade: 'B',
    minPrice: 8500,
    currentBid: 9200,
    preferredPrice: 9800,
    endTime: Date.now() + 14400000,
    watchers: 15,
    bids: 12,
    image: 'https://images.unsplash.com/photo-1615485290382-441e4d049cb5?w=400',
    farmerName: 'Bilal Ahmed',
    location: 'Vehari',
    verified: true,
    trustScore: 92,
    storageHistory: 'Quality verified by AgriVault Expert'
  }
];

export default function TradingFloor() {
  const [view, setView] = useState<View>('home');
  const [selectedCrop, setSelectedCrop] = useState('');
  const [quantity, setQuantity] = useState('');
  const [grade, setGrade] = useState<'A' | 'B' | 'C'>('A');
  const [minPrice, setMinPrice] = useState('');
  const [preferredPrice, setPreferredPrice] = useState('');
  const [auctionDuration, setAuctionDuration] = useState('24');
  const [selectedAuction, setSelectedAuction] = useState<Auction | null>(null);
  const [bidAmount, setBidAmount] = useState('');
  const [showBidConfirmation, setShowBidConfirmation] = useState(false);

  const [myListings] = useState<Auction[]>([
    {
      id: 'MY001',
      cropName: 'Rice (Basmati)',
      quantity: 300,
      grade: 'A',
      minPrice: 60,
      currentBid: 65,
      preferredPrice: 68,
      endTime: Date.now() + 10800000,
      watchers: 10,
      bids: 6,
      image: 'https://images.unsplash.com/photo-1586201375761-83865001e31c?w=400',
      farmerName: 'You',
      location: 'Faisalabad',
      verified: true,
      trustScore: 90
    }
  ]);

  const marketPrice = selectedCrop === 'wheat' ? 45 : selectedCrop === 'tomato' ? 50 : 0;

  // Background style
  const bgStyle = {
    backgroundImage: 'linear-gradient(to bottom, rgba(30, 127, 67, 0.08), rgba(255, 255, 255, 1) 40%), url(https://images.unsplash.com/photo-1625246333195-78d9c38ad449?w=800)',
    backgroundSize: 'cover',
    backgroundPosition: 'center top',
    backgroundRepeat: 'no-repeat'
  };

  // Home View
  if (view === 'home') {
    return (
      <div className="min-h-screen" style={bgStyle}>
        {/* Header */}
        <div className="bg-gradient-to-r from-[#1E7F43] to-[#15593A] text-white p-6 pb-8 rounded-b-3xl shadow-lg">
          <h1 className="mb-2 flex items-center gap-3">
            <Gavel className="w-8 h-8" />
            Digital Trading Floor
          </h1>
          <p className="text-white/90 text-sm">Transparent crop trading, without middlemen</p>
        </div>

        <div className="p-4 space-y-4">
          {/* CTA - List Produce */}
          <button
            onClick={() => setView('listProduce')}
            className="w-full bg-gradient-to-r from-orange-500 to-red-500 text-white rounded-2xl p-5 shadow-lg hover:shadow-xl transition-all"
          >
            <div className="flex items-center gap-4">
              <div className="bg-white/20 rounded-full p-3">
                <TrendingUp className="w-6 h-6" />
              </div>
              <div className="flex-1 text-left">
                <h3 className="text-white mb-1">List Your Produce</h3>
                <p className="text-sm text-white/90">Get best price through live bidding</p>
              </div>
              <ArrowLeft className="w-5 h-5 rotate-180" />
            </div>
          </button>

          {/* Quick Stats */}
          <div className="grid grid-cols-3 gap-3">
            <div className="bg-white rounded-xl p-3 shadow-md text-center">
              <TrendingUp className="w-5 h-5 text-green-600 mx-auto mb-1" />
              <p className="text-xl text-green-600 mb-1">PKR 450M</p>
              <p className="text-xs text-gray-500">Traded</p>
            </div>
            <div className="bg-white rounded-xl p-3 shadow-md text-center">
              <Users className="w-5 h-5 text-blue-600 mx-auto mb-1" />
              <p className="text-xl text-blue-600 mb-1">2,450</p>
              <p className="text-xs text-gray-500">Farmers</p>
            </div>
            <div className="bg-white rounded-xl p-3 shadow-md text-center">
              <Gavel className="w-5 h-5 text-orange-600 mx-auto mb-1" />
              <p className="text-xl text-orange-600 mb-1">34</p>
              <p className="text-xs text-gray-500">Live Now</p>
            </div>
          </div>

          {/* Live Auctions */}
          <div>
            <div className="flex items-center justify-between mb-3">
              <h3 className="text-gray-800">🔴 Live Auctions</h3>
              <Badge className="bg-red-500 animate-pulse">Live</Badge>
            </div>
            <div className="space-y-3">
              {liveAuctions.map((auction) => (
                <AuctionCard
                  key={auction.id}
                  auction={auction}
                  onClick={() => {
                    setSelectedAuction(auction);
                    setView('auctionDetail');
                  }}
                />
              ))}
            </div>
          </div>

          {/* My Active Listings */}
          {myListings.length > 0 && (
            <div>
              <div className="flex items-center justify-between mb-3">
                <h3 className="text-gray-800">🟢 Your Active Listings</h3>
              </div>
              <div className="space-y-3">
                {myListings.map((auction) => (
                  <AuctionCard
                    key={auction.id}
                    auction={auction}
                    isOwner
                    onClick={() => {
                      setSelectedAuction(auction);
                      setView('auctionDetail');
                    }}
                  />
                ))}
              </div>
            </div>
          )}

          {/* Market Alerts - AI Powered */}
          <div className="bg-gradient-to-r from-blue-50 to-purple-50 rounded-2xl p-4 border border-blue-200">
            <div className="flex items-start gap-3">
              <Sparkles className="w-5 h-5 text-blue-600 flex-shrink-0 mt-0.5" />
              <div>
                <h4 className="text-blue-900 mb-2">🔔 AI Market Alert</h4>
                <p className="text-sm text-blue-800 mb-2">
                  Wheat demand is 18% higher than usual today. Good time to list your produce!
                </p>
                <p className="text-xs text-blue-600">Suggestion based on market trends</p>
              </div>
            </div>
          </div>

          {/* Trust & Safety */}
          <div className="bg-white rounded-2xl p-4 shadow-md">
            <div className="flex items-center gap-2 mb-3">
              <Shield className="w-5 h-5 text-green-600" />
              <h4 className="text-gray-800">Safe & Transparent Trading</h4>
            </div>
            <ul className="space-y-1 text-sm text-gray-600">
              <li>✓ All farmers & buyers verified</li>
              <li>✓ Escrow payment protection</li>
              <li>✓ Quality guarantee system</li>
              <li>✓ Transparent price discovery</li>
            </ul>
          </div>
        </div>
      </div>
    );
  }

  // List Produce - Step 1
  if (view === 'listProduce') {
    return (
      <div className="min-h-screen bg-gray-50 pb-24">
        {/* Header */}
        <div className="bg-white border-b sticky top-0 z-10">
          <button
            onClick={() => setView('home')}
            className="flex items-center gap-2 text-[#1E7F43] p-4 hover:bg-green-50 transition-colors"
          >
            <div className="bg-green-50 rounded-full p-1">
              <ArrowLeft className="w-5 h-5" />
            </div>
            <span>Back</span>
          </button>
          <div className="px-4 pb-4">
            <h2>List Your Produce</h2>
            <p className="text-sm text-gray-500">Step 1 of 3: Select produce details</p>
          </div>
        </div>

        <div className="p-4 space-y-4">
          {/* Progress */}
          <div className="bg-white rounded-2xl p-4 shadow-md">
            <div className="flex items-center justify-between mb-2 text-sm">
              <span className="text-gray-600">Progress</span>
              <span className="text-[#1E7F43]">33%</span>
            </div>
            <Progress value={33} className="h-2" />
          </div>

          <div className="bg-white rounded-2xl p-4 shadow-md space-y-4">
            {/* Crop Selection */}
            <div>
              <label className="block mb-2 text-sm">Select Crop</label>
              <select
                value={selectedCrop}
                onChange={(e) => setSelectedCrop(e.target.value)}
                className="w-full p-3 border rounded-xl bg-gray-50"
              >
                <option value="">Choose crop type</option>
                <option value="wheat">Wheat</option>
                <option value="rice">Rice (Basmati)</option>
                <option value="cotton">Cotton</option>
                <option value="tomato">Tomato</option>
                <option value="potato">Potato</option>
                <option value="onion">Onion</option>
              </select>
            </div>

            {/* Quantity */}
            <div>
              <label className="block mb-2 text-sm">Quantity (in kg)</label>
              <Input
                type="number"
                value={quantity}
                onChange={(e) => setQuantity(e.target.value)}
                placeholder="e.g., 500"
                className="rounded-xl"
              />
            </div>

            {/* Grade */}
            <div>
              <label className="block mb-2 text-sm">Grade Quality</label>
              <div className="grid grid-cols-3 gap-2">
                {(['A', 'B', 'C'] as const).map((g) => (
                  <button
                    key={g}
                    onClick={() => setGrade(g)}
                    className={`p-3 rounded-xl border-2 transition-all ${
                      grade === g
                        ? 'border-[#1E7F43] bg-green-50'
                        : 'border-gray-200 hover:border-gray-300'
                    }`}
                  >
                    <p className="mb-1">Grade {g}</p>
                    <p className="text-xs text-gray-500">
                      {g === 'A' ? 'Premium' : g === 'B' ? 'Standard' : 'Basic'}
                    </p>
                  </button>
                ))}
              </div>
            </div>
          </div>

          {/* Helper Info */}
          <div className="bg-blue-50 rounded-2xl p-4 border border-blue-200">
            <p className="text-sm text-blue-800">
              💡 Grade A: Best quality, uniform size, no defects<br />
              Grade B: Good quality, minor variations acceptable<br />
              Grade C: Acceptable quality, suitable for processing
            </p>
          </div>
        </div>

        {/* Bottom Action */}
        <div className="fixed bottom-0 left-0 right-0 bg-white border-t p-4 shadow-lg">
          <Button
            size="lg"
            onClick={() => setView('setPriceRules')}
            disabled={!selectedCrop || !quantity || !grade}
            className="w-full max-w-md mx-auto rounded-xl bg-[#1E7F43] hover:bg-[#15593A] disabled:opacity-50"
          >
            Continue to Pricing
          </Button>
        </div>
      </div>
    );
  }

  // Set Price Rules - Step 2
  if (view === 'setPriceRules') {
    return (
      <div className="min-h-screen bg-gray-50 pb-24">
        {/* Header */}
        <div className="bg-white border-b sticky top-0 z-10">
          <button
            onClick={() => setView('listProduce')}
            className="flex items-center gap-2 text-[#1E7F43] p-4 hover:bg-green-50 transition-colors"
          >
            <div className="bg-green-50 rounded-full p-1">
              <ArrowLeft className="w-5 h-5" />
            </div>
            <span>Back</span>
          </button>
          <div className="px-4 pb-4">
            <h2>Set Price Rules</h2>
            <p className="text-sm text-gray-500">Step 2 of 3: Define your pricing</p>
          </div>
        </div>

        <div className="p-4 space-y-4">
          {/* Progress */}
          <div className="bg-white rounded-2xl p-4 shadow-md">
            <div className="flex items-center justify-between mb-2 text-sm">
              <span className="text-gray-600">Progress</span>
              <span className="text-[#1E7F43]">66%</span>
            </div>
            <Progress value={66} className="h-2" />
          </div>

          {/* Market Reference */}
          {marketPrice > 0 && (
            <div className="bg-gradient-to-r from-blue-50 to-blue-100 rounded-2xl p-4 border border-blue-200">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-blue-800 mb-1">Current Market Price</p>
                  <p className="text-2xl text-blue-900">PKR {marketPrice}/kg</p>
                </div>
                <TrendingUp className="w-8 h-8 text-blue-600" />
              </div>
            </div>
          )}

          <div className="bg-white rounded-2xl p-4 shadow-md space-y-4">
            {/* Minimum Price */}
            <div>
              <label className="block mb-2 text-sm">
                Minimum Acceptable Price (PKR/kg)
                <span className="text-red-500">*</span>
              </label>
              <Input
                type="number"
                value={minPrice}
                onChange={(e) => setMinPrice(e.target.value)}
                placeholder="Below this, you won't sell"
                className="rounded-xl"
              />
              <p className="text-xs text-gray-500 mt-1">
                You will never be forced to sell below this price
              </p>
            </div>

            {/* Preferred Price */}
            <div>
              <label className="block mb-2 text-sm">Preferred Selling Price (PKR/kg)</label>
              <Input
                type="number"
                value={preferredPrice}
                onChange={(e) => setPreferredPrice(e.target.value)}
                placeholder="Your ideal price"
                className="rounded-xl"
              />
            </div>

            {/* Auction Duration */}
            <div>
              <label className="block mb-2 text-sm">Auction Duration</label>
              <select
                value={auctionDuration}
                onChange={(e) => setAuctionDuration(e.target.value)}
                className="w-full p-3 border rounded-xl bg-gray-50"
              >
                <option value="1">1 Hour (Quick Sale)</option>
                <option value="6">6 Hours (Recommended)</option>
                <option value="24">24 Hours (Best Price)</option>
              </select>
            </div>
          </div>

          {/* AI Suggestion */}
          <div className="bg-purple-50 rounded-2xl p-4 border border-purple-200">
            <div className="flex items-start gap-3">
              <Sparkles className="w-5 h-5 text-purple-600 flex-shrink-0 mt-0.5" />
              <div>
                <h4 className="text-purple-900 mb-1">AI Suggestion</h4>
                <p className="text-sm text-purple-800">
                  Based on market trends, set minimum at PKR {marketPrice - 3}/kg and preferred at PKR {marketPrice + 5}/kg for best results.
                </p>
              </div>
            </div>
          </div>

          {/* Protection Notice */}
          <div className="bg-green-50 rounded-2xl p-4 border border-green-200">
            <div className="flex items-center gap-2 mb-2">
              <Shield className="w-5 h-5 text-green-600" />
              <h4 className="text-green-900">Price Protection</h4>
            </div>
            <p className="text-sm text-green-800">
              Your minimum price is locked. Auction will auto-close if not met. You're always in control.
            </p>
          </div>
        </div>

        {/* Bottom Action */}
        <div className="fixed bottom-0 left-0 right-0 bg-white border-t p-4 shadow-lg">
          <Button
            size="lg"
            onClick={() => setView('reviewPublish')}
            disabled={!minPrice}
            className="w-full max-w-md mx-auto rounded-xl bg-[#1E7F43] hover:bg-[#15593A] disabled:opacity-50"
          >
            Review Listing
          </Button>
        </div>
      </div>
    );
  }

  // Review & Publish - Step 3
  if (view === 'reviewPublish') {
    const totalValue = parseInt(quantity || '0') * parseInt(preferredPrice || minPrice || '0');
    
    return (
      <div className="min-h-screen bg-gray-50 pb-24">
        {/* Header */}
        <div className="bg-white border-b sticky top-0 z-10">
          <button
            onClick={() => setView('setPriceRules')}
            className="flex items-center gap-2 text-[#1E7F43] p-4 hover:bg-green-50 transition-colors"
          >
            <div className="bg-green-50 rounded-full p-1">
              <ArrowLeft className="w-5 h-5" />
            </div>
            <span>Back</span>
          </button>
          <div className="px-4 pb-4">
            <h2>Review & Publish</h2>
            <p className="text-sm text-gray-500">Step 3 of 3: Confirm your listing</p>
          </div>
        </div>

        <div className="p-4 space-y-4">
          {/* Progress */}
          <div className="bg-white rounded-2xl p-4 shadow-md">
            <div className="flex items-center justify-between mb-2 text-sm">
              <span className="text-gray-600">Progress</span>
              <span className="text-[#1E7F43]">100%</span>
            </div>
            <Progress value={100} className="h-2" />
          </div>

          {/* Preview Card */}
          <div className="bg-white rounded-2xl p-4 shadow-lg border-2 border-[#1E7F43]">
            <Badge className="bg-green-500 mb-3">Preview</Badge>
            
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <span className="text-gray-600">Crop</span>
                <span className="capitalize">{selectedCrop}</span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-gray-600">Quantity</span>
                <span>{quantity} kg</span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-gray-600">Grade</span>
                <Badge variant="outline">Grade {grade}</Badge>
              </div>
              <div className="border-t pt-3 space-y-2">
                <div className="flex items-center justify-between">
                  <span className="text-gray-600">Minimum Price</span>
                  <span className="text-red-600">PKR {minPrice}/kg</span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-gray-600">Preferred Price</span>
                  <span className="text-green-600">PKR {preferredPrice || minPrice}/kg</span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-gray-600">Auction Duration</span>
                  <span>{auctionDuration} hours</span>
                </div>
              </div>
              <div className="border-t pt-3 bg-green-50 -mx-4 -mb-4 px-4 py-3 rounded-b-xl">
                <div className="flex items-center justify-between">
                  <span>Potential Value</span>
                  <span className="text-xl text-green-600">PKR {totalValue.toLocaleString()}</span>
                </div>
              </div>
            </div>
          </div>

          {/* Auction End Time */}
          <div className="bg-blue-50 rounded-2xl p-4 border border-blue-200">
            <div className="flex items-center gap-2 mb-2">
              <Clock className="w-5 h-5 text-blue-600" />
              <h4 className="text-blue-900">Auction Timeline</h4>
            </div>
            <p className="text-sm text-blue-800">
              Starts: Immediately after publishing<br />
              Ends: {new Date(Date.now() + parseInt(auctionDuration) * 3600000).toLocaleString()}
            </p>
          </div>

          {/* Terms */}
          <div className="bg-white rounded-2xl p-4 shadow-md">
            <h4 className="mb-3">Important Terms</h4>
            <ul className="text-sm text-gray-600 space-y-2">
              <li className="flex items-start gap-2">
                <CheckCircle className="w-4 h-4 text-green-600 flex-shrink-0 mt-0.5" />
                <span>You can withdraw listing before first bid</span>
              </li>
              <li className="flex items-start gap-2">
                <CheckCircle className="w-4 h-4 text-green-600 flex-shrink-0 mt-0.5" />
                <span>You can accept or reject winning bid</span>
              </li>
              <li className="flex items-start gap-2">
                <CheckCircle className="w-4 h-4 text-green-600 flex-shrink-0 mt-0.5" />
                <span>Payment held in escrow until delivery</span>
              </li>
              <li className="flex items-start gap-2">
                <CheckCircle className="w-4 h-4 text-green-600 flex-shrink-0 mt-0.5" />
                <span>AgriVault charges 2% commission only on successful sales</span>
              </li>
            </ul>
          </div>
        </div>

        {/* Bottom Action */}
        <div className="fixed bottom-0 left-0 right-0 bg-white border-t p-4 shadow-lg">
          <Button
            size="lg"
            onClick={() => setView('home')}
            className="w-full max-w-md mx-auto rounded-xl bg-[#1E7F43] hover:bg-[#15593A]"
          >
            Publish to Trading Floor
          </Button>
        </div>
      </div>
    );
  }

  // Auction Detail View (for buyers)
  if (view === 'auctionDetail' && selectedAuction) {
    const timeRemaining = selectedAuction.endTime - Date.now();
    const hours = Math.floor(timeRemaining / 3600000);
    const minutes = Math.floor((timeRemaining % 3600000) / 60000);

    return (
      <div className="min-h-screen bg-gray-50 pb-32">
        {/* Header */}
        <div className="bg-white sticky top-0 z-10 border-b">
          <button
            onClick={() => setView('home')}
            className="flex items-center gap-2 text-[#1E7F43] p-4 hover:bg-green-50 transition-colors"
          >
            <div className="bg-green-50 rounded-full p-1">
              <ArrowLeft className="w-5 h-5" />
            </div>
            <span>Back</span>
          </button>
        </div>

        {/* Image */}
        <div className="bg-white">
          <div className="aspect-video bg-gray-100 relative">
            <img src={selectedAuction.image} alt={selectedAuction.cropName} className="w-full h-full object-cover" />
            <div className="absolute top-4 right-4">
              <Badge className="bg-red-500 animate-pulse">🔴 Live Auction</Badge>
            </div>
            <div className="absolute bottom-4 left-4 right-4">
              <div className="bg-black/60 backdrop-blur-sm rounded-xl p-3 text-white">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-xs opacity-90">Time Remaining</p>
                    <p className="text-xl">{hours}h {minutes}m</p>
                  </div>
                  <Clock className="w-6 h-6" />
                </div>
              </div>
            </div>
          </div>
        </div>

        <div className="p-4 space-y-4">
          {/* Main Info */}
          <div className="bg-white rounded-2xl p-4 shadow-lg">
            <div className="flex items-start justify-between mb-3">
              <div>
                <h2 className="mb-1">{selectedAuction.cropName}</h2>
                <p className="text-sm text-gray-500">{selectedAuction.quantity} kg • Grade {selectedAuction.grade}</p>
              </div>
              <Badge variant="outline" className="bg-green-50 text-green-700 border-green-200">
                Grade {selectedAuction.grade}
              </Badge>
            </div>

            {/* Current Bid */}
            <div className="bg-gradient-to-r from-green-50 to-green-100 rounded-xl p-4 mb-3">
              <p className="text-sm text-gray-600 mb-1">Current Highest Bid</p>
              <p className="text-3xl text-green-600 mb-1">PKR {selectedAuction.currentBid}/kg</p>
              <p className="text-xs text-gray-500">
                Total: PKR {(selectedAuction.currentBid * selectedAuction.quantity).toLocaleString()}
              </p>
            </div>

            <div className="grid grid-cols-2 gap-3 text-sm">
              <div>
                <p className="text-gray-500 mb-1">Minimum Price</p>
                <p className="text-red-600">PKR {selectedAuction.minPrice}/kg</p>
              </div>
              <div>
                <p className="text-gray-500 mb-1">Preferred Price</p>
                <p className="text-gray-800">PKR {selectedAuction.preferredPrice}/kg</p>
              </div>
            </div>
          </div>

          {/* Activity */}
          <div className="bg-white rounded-2xl p-4 shadow-md">
            <div className="flex items-center gap-4 text-sm">
              <div className="flex items-center gap-1">
                <Eye className="w-4 h-4 text-blue-600" />
                <span>{selectedAuction.watchers} watching</span>
              </div>
              <div className="flex items-center gap-1">
                <Gavel className="w-4 h-4 text-green-600" />
                <span>{selectedAuction.bids} bids placed</span>
              </div>
            </div>
          </div>

          {/* Farmer Info */}
          <div className="bg-white rounded-2xl p-4 shadow-md">
            <h4 className="mb-3">Seller Information</h4>
            <div className="flex items-center gap-3 mb-3">
              <div className="w-12 h-12 bg-gradient-to-br from-[#1E7F43] to-[#15593A] rounded-full flex items-center justify-center text-white">
                {selectedAuction.farmerName.charAt(0)}
              </div>
              <div className="flex-1">
                <div className="flex items-center gap-2">
                  <p>{selectedAuction.farmerName}</p>
                  {selectedAuction.verified && (
                    <Badge className="bg-blue-500 text-xs">✓ Verified</Badge>
                  )}
                </div>
                <p className="text-sm text-gray-500">{selectedAuction.location}</p>
              </div>
              <div className="text-right">
                <p className="text-sm text-gray-500">Trust Score</p>
                <p className="text-lg text-green-600">{selectedAuction.trustScore}%</p>
              </div>
            </div>

            {selectedAuction.storageHistory && (
              <div className="bg-blue-50 rounded-xl p-3 border border-blue-200">
                <p className="text-sm text-blue-800">
                  📦 {selectedAuction.storageHistory}
                </p>
              </div>
            )}
          </div>

          {/* AI Insight */}
          <div className="bg-purple-50 rounded-2xl p-4 border border-purple-200">
            <div className="flex items-start gap-3">
              <Sparkles className="w-5 h-5 text-purple-600 flex-shrink-0 mt-0.5" />
              <div>
                <h4 className="text-purple-900 mb-1">AI Market Insight</h4>
                <p className="text-sm text-purple-800">
                  Current bid is 7% higher than market average. Waiting may increase price by 3-5% more based on trends.
                </p>
                <p className="text-xs text-purple-600 mt-1">Advisory • Not guaranteed</p>
              </div>
            </div>
          </div>
        </div>

        {/* Bottom Bidding */}
        <div className="fixed bottom-0 left-0 right-0 bg-white border-t p-4 shadow-lg">
          <div className="max-w-md mx-auto space-y-2">
            <div className="flex gap-2">
              <Input
                type="number"
                value={bidAmount}
                onChange={(e) => setBidAmount(e.target.value)}
                placeholder={`Min bid: ${selectedAuction.currentBid + 1}`}
                className="flex-1 rounded-xl"
              />
              <Button
                size="lg"
                onClick={() => setShowBidConfirmation(true)}
                disabled={!bidAmount || parseInt(bidAmount) <= selectedAuction.currentBid}
                className="rounded-xl bg-[#1E7F43] hover:bg-[#15593A] disabled:opacity-50"
              >
                Place Bid
              </Button>
            </div>
            <p className="text-xs text-gray-500 text-center">
              Your bid must be higher than PKR {selectedAuction.currentBid}/kg
            </p>
          </div>
        </div>

        {/* Bid Confirmation Modal */}
        {showBidConfirmation && (
          <div className="fixed inset-0 bg-black/50 flex items-center justify-center p-4 z-50">
            <div className="bg-white rounded-3xl p-6 max-w-sm w-full">
              <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <Gavel className="w-8 h-8 text-green-600" />
              </div>
              <h3 className="text-center mb-2">Confirm Your Bid</h3>
              <div className="bg-gray-50 rounded-xl p-4 mb-4">
                <p className="text-sm text-gray-600 mb-2">You are bidding:</p>
                <p className="text-2xl text-green-600 mb-1">PKR {bidAmount}/kg</p>
                <p className="text-sm text-gray-500">
                  Total: PKR {(parseInt(bidAmount || '0') * selectedAuction.quantity).toLocaleString()}
                </p>
              </div>
              <div className="flex gap-2">
                <Button
                  variant="outline"
                  onClick={() => setShowBidConfirmation(false)}
                  className="flex-1 rounded-xl"
                >
                  Cancel
                </Button>
                <Button
                  onClick={() => {
                    setShowBidConfirmation(false);
                    // In real app, submit bid
                  }}
                  className="flex-1 rounded-xl bg-[#1E7F43] hover:bg-[#15593A]"
                >
                  Confirm Bid
                </Button>
              </div>
            </div>
          </div>
        )}
      </div>
    );
  }

  return null;
}

// Auction Card Component
function AuctionCard({ auction, onClick, isOwner = false }: { auction: Auction; onClick: () => void; isOwner?: boolean }) {
  const timeRemaining = auction.endTime - Date.now();
  const hours = Math.floor(timeRemaining / 3600000);
  const minutes = Math.floor((timeRemaining % 3600000) / 60000);

  return (
    <button
      onClick={onClick}
      className="w-full bg-white rounded-2xl overflow-hidden shadow-md hover:shadow-lg transition-all text-left"
    >
      <div className="flex gap-3 p-3">
        <div className="w-24 h-24 bg-gray-100 rounded-xl overflow-hidden flex-shrink-0 relative">
          <img src={auction.image} alt={auction.cropName} className="w-full h-full object-cover" />
          <Badge className="absolute top-1 right-1 text-xs bg-green-500">
            {auction.grade}
          </Badge>
        </div>

        <div className="flex-1 min-w-0">
          <div className="flex items-start justify-between mb-1">
            <h4 className="text-sm truncate">{auction.cropName}</h4>
            {isOwner && (
              <Badge className="bg-blue-500 text-xs">Your Listing</Badge>
            )}
          </div>
          <p className="text-xs text-gray-500 mb-2">{auction.quantity} kg • {auction.location}</p>

          <div className="flex items-center justify-between mb-2">
            <div>
              <p className="text-xs text-gray-500">Current Bid</p>
              <p className="text-green-600">PKR {auction.currentBid}/kg</p>
            </div>
            <div className="text-right">
              <p className="text-xs text-gray-500">Time Left</p>
              <p className="text-sm">{hours}h {minutes}m</p>
            </div>
          </div>

          <div className="flex items-center gap-3 text-xs text-gray-500">
            <span className="flex items-center gap-1">
              <Eye className="w-3 h-3" />
              {auction.watchers}
            </span>
            <span className="flex items-center gap-1">
              <Gavel className="w-3 h-3" />
              {auction.bids} bids
            </span>
            {auction.verified && (
              <Badge className="bg-blue-500 text-xs">✓</Badge>
            )}
          </div>
        </div>
      </div>
    </button>
  );
}
