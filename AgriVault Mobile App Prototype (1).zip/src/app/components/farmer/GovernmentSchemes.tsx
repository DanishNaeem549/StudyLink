import { useState } from 'react';
import { ArrowLeft, DollarSign, Shield, Tractor, Package, CheckCircle, XCircle, AlertCircle, Calendar, FileText, HelpCircle, Bell, Users } from 'lucide-react';
import { Button } from '../ui/button';
import { Input } from '../ui/input';
import { Badge } from '../ui/badge';

type View = 'home' | 'category' | 'schemeDetail' | 'eligibilityChecker' | 'eligibilityResult' | 'application';

interface Scheme {
  id: string;
  name: string;
  category: string;
  authority: string;
  benefit: string;
  maxAmount: string;
  deadline: string;
  eligibility: 'eligible' | 'possibly' | 'not';
  description: string;
  benefits: string[];
  criteria: string[];
  documents: string[];
  steps: string[];
}

const categories = [
  { id: 'loans', name: 'Loans', icon: DollarSign, color: 'from-green-500 to-green-600', emoji: '💰' },
  { id: 'subsidies', name: 'Input Subsidies', icon: Package, color: 'from-blue-500 to-blue-600', emoji: '🌾' },
  { id: 'insurance', name: 'Crop Insurance', icon: Shield, color: 'from-purple-500 to-purple-600', emoji: '🛡' },
  { id: 'equipment', name: 'Equipment Support', icon: Tractor, color: 'from-orange-500 to-orange-600', emoji: '🚜' }
];

const schemes: Scheme[] = [
  {
    id: '1',
    name: 'Kisan Card - Subsidized Credit',
    category: 'loans',
    authority: 'State Bank of Pakistan',
    benefit: 'Get farm loans at 6% interest (instead of 14%)',
    maxAmount: 'Up to PKR 1,500,000',
    deadline: '2025-03-31',
    eligibility: 'eligible',
    description: 'The Kisan Card provides subsidized agricultural credit to small farmers. Government covers the interest difference, making loans affordable.',
    benefits: [
      'Interest rate only 6% (Government subsidizes rest)',
      'No collateral needed for loans up to PKR 500,000',
      'Flexible repayment after harvest',
      '12-month loan tenure with grace period'
    ],
    criteria: [
      'Must own or lease at least 5 acres of land',
      'Previous farming experience (2+ years)',
      'CNIC and land ownership documents',
      'No previous loan defaults'
    ],
    documents: [
      'CNIC copy',
      'Land ownership proof (Fard/Lease agreement)',
      'Bank account statement',
      'Recent photograph',
      'Electricity/gas bill for address proof'
    ],
    steps: [
      'Visit nearest Agricultural Bank branch',
      'Fill Kisan Card application form',
      'Submit required documents',
      'Bank will verify land ownership',
      'Approval within 10-15 working days',
      'Card issued with approved credit limit'
    ]
  },
  {
    id: '2',
    name: 'Prime Minister Agriculture Emergency Program',
    category: 'loans',
    authority: 'Ministry of Food Security',
    benefit: 'Emergency loans for disaster-affected farmers',
    maxAmount: 'Up to PKR 500,000',
    deadline: '2025-06-30',
    eligibility: 'not',
    description: 'Special support program for farmers affected by natural disasters like floods, droughts, or locust attacks.',
    benefits: [
      'Zero interest for first year',
      'No processing fees',
      '2-year repayment period',
      'Insurance coverage included'
    ],
    criteria: [
      'Farm must be in declared calamity area',
      'Proof of disaster damage (inspection report)',
      'Small-scale farmer (under 25 acres)',
      'Primary occupation must be farming'
    ],
    documents: [
      'CNIC',
      'Disaster damage certificate from district administration',
      'Land records',
      'Crop loss assessment report'
    ],
    steps: [
      'Get damage certificate from local revenue office',
      'Apply through Agriculture Department district office',
      'Field inspection by department team',
      'Approval by District Committee',
      'Disbursement through bank account'
    ]
  },
  {
    id: '3',
    name: 'Fertilizer Subsidy - Wheat Season',
    category: 'subsidies',
    authority: 'Provincial Agriculture Department',
    benefit: 'Get 33% off on DAP and Urea fertilizers',
    maxAmount: 'Subsidy on up to 10 bags',
    deadline: '2025-01-15',
    eligibility: 'eligible',
    description: 'Direct subsidy on fertilizer purchase for wheat crop. Registered farmers get subsidy instantly at authorized dealers.',
    benefits: [
      '33% discount on DAP fertilizer',
      '25% discount on Urea',
      'No paperwork at dealer - instant discount',
      'Valid at 500+ authorized dealers nationwide'
    ],
    criteria: [
      'Must be registered on AgriPortal (online registration available)',
      'Land holding: 2-50 acres',
      'Fertilizer for wheat crop only',
      'One-time subsidy per season'
    ],
    documents: [
      'CNIC',
      'AgriPortal registration number',
      'Land ownership proof (for first-time users)'
    ],
    steps: [
      'Register on AgriPortal website or mobile app',
      'Get your subsidy ID',
      'Visit any authorized fertilizer dealer',
      'Show CNIC and subsidy ID',
      'Get instant discount on purchase'
    ]
  },
  {
    id: '4',
    name: 'Certified Seed Subsidy Program',
    category: 'subsidies',
    authority: 'Punjab Seed Corporation',
    benefit: 'Buy certified seeds at 40% discount',
    maxAmount: 'Subsidy on seeds for up to 20 acres',
    deadline: '2025-02-28',
    eligibility: 'eligible',
    description: 'Subsidy on certified seeds to encourage farmers to use quality seeds and increase productivity.',
    benefits: [
      '40% discount on certified wheat, rice, and cotton seeds',
      'Guaranteed germination rate',
      'Free seed treatment',
      'Technical guidance included'
    ],
    criteria: [
      'Farming land between 5-50 acres',
      'Must purchase from authorized seed outlets',
      'Valid CNIC',
      'Punjab domicile'
    ],
    documents: [
      'CNIC copy',
      'Land ownership documents',
      'Previous seed purchase receipts (if available)'
    ],
    steps: [
      'Find nearest authorized seed outlet (list on Punjab Seed Corporation website)',
      'Take your CNIC and land documents',
      'Fill simple form at outlet',
      'Purchase certified seeds at subsidized rate',
      'Get receipt for record'
    ]
  },
  {
    id: '5',
    name: 'Crop Insurance Scheme - Cotton & Wheat',
    category: 'insurance',
    authority: 'State Life Insurance & NDRMF',
    benefit: 'Get insurance coverage for your entire crop',
    maxAmount: 'Coverage up to PKR 100,000/acre',
    deadline: '2025-01-31',
    eligibility: 'possibly',
    description: 'Comprehensive crop insurance covering losses due to natural disasters, pests, and diseases.',
    benefits: [
      '70% premium paid by government (you pay only 30%)',
      'Coverage for flood, drought, pest attacks, hailstorm',
      'Quick claim settlement (30 days)',
      'No inspection needed for claims under PKR 50,000'
    ],
    criteria: [
      'Minimum 3 acres of insured crop',
      'Must apply before sowing season ends',
      'Land should not be in high-risk flood zone',
      'Previous claim history will be verified'
    ],
    documents: [
      'CNIC',
      'Land records (Fard)',
      'Crop sowing certificate from Agriculture Officer',
      'Bank account for premium payment'
    ],
    steps: [
      'Apply online at NDRMF website or visit district office',
      'Submit documents and pay 30% premium',
      'Get policy certificate',
      'In case of loss, immediately inform Agriculture Department',
      'Claim assessment by insurance team',
      'Payment directly to bank account'
    ]
  },
  {
    id: '6',
    name: 'Livestock Insurance',
    category: 'insurance',
    authority: 'Livestock Department',
    benefit: 'Insure your cattle and buffaloes',
    maxAmount: 'Up to PKR 200,000 per animal',
    deadline: 'Open year-round',
    eligibility: 'eligible',
    description: 'Insurance coverage for cattle and buffalo against death due to disease or accident.',
    benefits: [
      '50% premium subsidy from government',
      'Coverage for disease, accident, natural calamity',
      'Free vaccination included',
      'Veterinary helpline access'
    ],
    criteria: [
      'Animal must be healthy at time of insurance',
      'Veterinary health certificate required',
      'Minimum 2 animals, maximum 10 animals',
      'Animals should be 2-8 years old'
    ],
    documents: [
      'CNIC',
      'Animal health certificate from registered vet',
      'Photos of animals with ear tags',
      'Bank account details'
    ],
    steps: [
      'Get animals checked by veterinary doctor',
      'Obtain health certificate',
      'Apply at Livestock Department office or online',
      'Pay subsidized premium',
      'Receive insurance certificate and ear tags',
      'For claims, contact helpline immediately'
    ]
  },
  {
    id: '7',
    name: 'Tractor Subsidy Scheme',
    category: 'equipment',
    authority: 'Ministry of Agriculture',
    benefit: 'Get PKR 300,000 subsidy on new tractor',
    maxAmount: 'PKR 300,000 subsidy',
    deadline: '2025-04-30',
    eligibility: 'possibly',
    description: 'One-time subsidy for small farmers to purchase new tractors and increase mechanization.',
    benefits: [
      'Direct subsidy of PKR 300,000',
      'Easy financing available for remaining amount',
      'Free registration for 1 year',
      '5-year warranty on subsidized tractors'
    ],
    criteria: [
      'Must own at least 12.5 acres of land',
      'No previous tractor subsidy availed',
      'Annual income below PKR 1,200,000',
      'Must purchase from authorized dealers only'
    ],
    documents: [
      'CNIC and family registration certificate',
      'Land ownership documents (min 12.5 acres)',
      'Income certificate from local government',
      'No-objection certificate from bank (if taking loan)',
      'Two guarantors with CNICs'
    ],
    steps: [
      'Apply online on Ministry of Agriculture portal',
      'Upload all required documents',
      'Wait for eligibility verification (15-30 days)',
      'Get approval letter',
      'Visit authorized tractor dealer',
      'Purchase tractor - subsidy amount will be adjusted',
      'Register tractor with Agriculture Department'
    ]
  },
  {
    id: '8',
    name: 'Solar Water Pump Subsidy',
    category: 'equipment',
    authority: 'Alternative Energy Development Board',
    benefit: '60% subsidy on solar pumps',
    maxAmount: 'Subsidy up to PKR 500,000',
    deadline: '2025-05-31',
    eligibility: 'eligible',
    description: 'Promote renewable energy in agriculture with subsidized solar water pumps.',
    benefits: [
      '60% cost covered by government',
      'Zero electricity bills forever',
      'Environment friendly',
      '5-year free maintenance',
      'Increases land value'
    ],
    criteria: [
      'Farming land at least 5 acres',
      'Area with electricity shortage or no grid connection',
      'Groundwater availability confirmed',
      'Must use for agricultural purposes only'
    ],
    documents: [
      'CNIC',
      'Land ownership proof',
      'Electricity bill (or no-connection certificate)',
      'Groundwater survey report',
      'Bank account for subsidy transfer'
    ],
    steps: [
      'Apply on AEDB website',
      'Get technical survey done (free)',
      'Receive approval and subsidy confirmation',
      'Purchase solar pump from empaneled vendor',
      'Installation by certified technician',
      'Inspection by AEDB team',
      'Subsidy amount transferred to your account'
    ]
  }
];

export default function GovernmentSchemes() {
  const [view, setView] = useState<View>('home');
  const [selectedCategory, setSelectedCategory] = useState<string>('');
  const [selectedScheme, setSelectedScheme] = useState<Scheme | null>(null);
  const [searchQuery, setSearchQuery] = useState('');
  
  // Eligibility checker states
  const [landSize, setLandSize] = useState('');
  const [cropType, setCropType] = useState('');
  const [region, setRegion] = useState('');
  const [farmerType, setFarmerType] = useState('');
  const [eligibilityResults, setEligibilityResults] = useState<Scheme[]>([]);

  const filteredSchemes = schemes.filter(s => 
    s.category === selectedCategory &&
    (searchQuery === '' || s.name.toLowerCase().includes(searchQuery.toLowerCase()))
  );

  const upcomingDeadlines = schemes
    .filter(s => new Date(s.deadline) > new Date() && new Date(s.deadline) < new Date(Date.now() + 15 * 24 * 60 * 60 * 1000))
    .slice(0, 3);

  const checkEligibility = () => {
    const land = parseInt(landSize);
    const results = schemes.filter(scheme => {
      if (scheme.name.includes('Tractor') && land < 12.5) return false;
      if (scheme.name.includes('Solar') && land < 5) return false;
      if (scheme.name.includes('Wheat') && cropType !== 'wheat') return false;
      if (scheme.name.includes('Cotton') && cropType !== 'cotton') return false;
      return true;
    });
    setEligibilityResults(results);
    setView('eligibilityResult');
  };

  // Background style
  const bgStyle = {
    backgroundImage: 'linear-gradient(to bottom, rgba(30, 127, 67, 0.08), rgba(255, 255, 255, 1) 40%), url(https://images.unsplash.com/photo-1625246333195-78d9c38ad449?w=800)',
    backgroundSize: 'cover',
    backgroundPosition: 'center top',
    backgroundRepeat: 'no-repeat'
  };

  // Home View
  if (view === 'home') {
    return (
      <div className="min-h-screen" style={bgStyle}>
        {/* Header */}
        <div className="bg-gradient-to-r from-[#1E7F43] to-[#15593A] text-white p-6 pb-8 rounded-b-3xl shadow-lg">
          <h1 className="mb-2 flex items-center gap-3">
            <Shield className="w-8 h-8" />
            Government Schemes Hub
          </h1>
          <p className="text-white/90 text-sm">Discover support programs for farmers</p>
        </div>

        <div className="p-4 space-y-4">
          {/* Deadline Alerts */}
          {upcomingDeadlines.length > 0 && (
            <div className="bg-gradient-to-r from-orange-500 to-red-500 text-white rounded-2xl p-4 shadow-lg">
              <div className="flex items-start gap-3">
                <Bell className="w-6 h-6 flex-shrink-0 mt-0.5" />
                <div>
                  <h4 className="text-white mb-2">⏰ Urgent Deadlines</h4>
                  {upcomingDeadlines.map(scheme => (
                    <div key={scheme.id} className="text-sm text-white/90 mb-1">
                      • {scheme.name} - Last {Math.ceil((new Date(scheme.deadline).getTime() - Date.now()) / (1000 * 60 * 60 * 24))} days
                    </div>
                  ))}
                </div>
              </div>
            </div>
          )}

          {/* Eligibility Checker CTA */}
          <button
            onClick={() => setView('eligibilityChecker')}
            className="w-full bg-gradient-to-r from-blue-500 to-blue-600 text-white rounded-2xl p-5 shadow-lg hover:shadow-xl transition-all"
          >
            <div className="flex items-center gap-4">
              <div className="bg-white/20 rounded-full p-3">
                <HelpCircle className="w-6 h-6" />
              </div>
              <div className="flex-1 text-left">
                <h3 className="text-white mb-1">Check Your Eligibility</h3>
                <p className="text-sm text-white/90">Find schemes you qualify for in 2 minutes</p>
              </div>
              <ArrowLeft className="w-5 h-5 rotate-180" />
            </div>
          </button>

          {/* Categories */}
          <div>
            <h3 className="text-gray-800 mb-3">Browse by Category</h3>
            <div className="grid grid-cols-2 gap-3">
              {categories.map((cat) => {
                const Icon = cat.icon;
                return (
                  <button
                    key={cat.id}
                    onClick={() => {
                      setSelectedCategory(cat.id);
                      setView('category');
                    }}
                    className={`bg-gradient-to-br ${cat.color} text-white rounded-2xl p-5 shadow-lg hover:shadow-xl transition-all transform hover:scale-105`}
                  >
                    <div className="text-3xl mb-2">{cat.emoji}</div>
                    <h4 className="text-white text-sm">{cat.name}</h4>
                    <p className="text-xs text-white/80 mt-1">
                      {schemes.filter(s => s.category === cat.id).length} schemes
                    </p>
                  </button>
                );
              })}
            </div>
          </div>

          {/* Trust Section */}
          <div className="bg-white rounded-2xl p-4 shadow-md">
            <div className="flex items-center gap-2 mb-3">
              <CheckCircle className="w-5 h-5 text-green-600" />
              <h4 className="text-gray-800">Official Government Programs</h4>
            </div>
            <p className="text-sm text-gray-600 mb-3">
              All schemes listed are verified and published by government departments. AgriVault helps you discover and apply easily.
            </p>
            <div className="flex items-center gap-2 text-sm text-[#1E7F43]">
              <Users className="w-4 h-4" />
              <span>12,450 farmers already benefited this year</span>
            </div>
          </div>
        </div>
      </div>
    );
  }

  // Category Listing
  if (view === 'category') {
    const category = categories.find(c => c.id === selectedCategory);

    return (
      <div className="min-h-screen bg-gray-50">
        {/* Header */}
        <div className="bg-white border-b sticky top-0 z-10">
          <div className="p-4">
            <button
              onClick={() => setView('home')}
              className="flex items-center gap-2 text-[#1E7F43] mb-3 hover:bg-green-50 p-2 rounded-full transition-colors"
            >
              <div className="bg-green-50 rounded-full p-1">
                <ArrowLeft className="w-5 h-5" />
              </div>
              <span>Back</span>
            </button>
            <h2 className="mb-3">{category?.emoji} {category?.name}</h2>
          </div>
        </div>

        {/* Schemes List */}
        <div className="p-4 space-y-3">
          {filteredSchemes.map((scheme) => (
            <button
              key={scheme.id}
              onClick={() => {
                setSelectedScheme(scheme);
                setView('schemeDetail');
              }}
              className="w-full bg-white rounded-2xl p-4 shadow-md hover:shadow-lg transition-shadow text-left"
            >
              <div className="flex items-start justify-between mb-2">
                <div className="flex-1">
                  <h4 className="mb-1">{scheme.name}</h4>
                  <p className="text-xs text-gray-500">{scheme.authority}</p>
                </div>
                <Badge className={
                  scheme.eligibility === 'eligible' ? 'bg-green-500' :
                  scheme.eligibility === 'possibly' ? 'bg-orange-500' : 'bg-gray-400'
                }>
                  {scheme.eligibility === 'eligible' ? 'Eligible' :
                   scheme.eligibility === 'possibly' ? 'Check Eligibility' : 'Not Eligible'}
                </Badge>
              </div>

              <p className="text-sm text-gray-700 mb-3">{scheme.benefit}</p>

              <div className="flex items-center justify-between text-sm">
                <div className="flex items-center gap-1 text-green-600">
                  <DollarSign className="w-4 h-4" />
                  <span>{scheme.maxAmount}</span>
                </div>
                <div className="flex items-center gap-1 text-orange-600">
                  <Calendar className="w-4 h-4" />
                  <span>Until {new Date(scheme.deadline).toLocaleDateString()}</span>
                </div>
              </div>
            </button>
          ))}
        </div>
      </div>
    );
  }

  // Scheme Detail
  if (view === 'schemeDetail' && selectedScheme) {
    return (
      <div className="min-h-screen bg-gray-50 pb-24">
        {/* Header */}
        <div className="bg-white sticky top-0 z-10 border-b">
          <button
            onClick={() => setView('category')}
            className="flex items-center gap-2 text-[#1E7F43] p-4 hover:bg-green-50 transition-colors"
          >
            <div className="bg-green-50 rounded-full p-1">
              <ArrowLeft className="w-5 h-5" />
            </div>
            <span>Back</span>
          </button>
        </div>

        <div className="p-4 space-y-4">
          {/* Title Card */}
          <div className="bg-gradient-to-r from-[#1E7F43] to-[#15593A] text-white rounded-2xl p-5 shadow-lg">
            <Badge className={`mb-3 ${
              selectedScheme.eligibility === 'eligible' ? 'bg-white text-green-600' :
              selectedScheme.eligibility === 'possibly' ? 'bg-orange-500' : 'bg-gray-500'
            }`}>
              {selectedScheme.eligibility === 'eligible' ? '✓ You are Eligible' :
               selectedScheme.eligibility === 'possibly' ? 'Check Eligibility' : 'Not Eligible'}
            </Badge>
            <h2 className="text-white mb-2">{selectedScheme.name}</h2>
            <p className="text-white/90 text-sm mb-3">{selectedScheme.authority}</p>
            <div className="flex items-center gap-4 text-sm">
              <div className="flex items-center gap-1">
                <DollarSign className="w-4 h-4" />
                <span>{selectedScheme.maxAmount}</span>
              </div>
              <div className="flex items-center gap-1">
                <Calendar className="w-4 h-4" />
                <span>Deadline: {new Date(selectedScheme.deadline).toLocaleDateString()}</span>
              </div>
            </div>
          </div>

          {/* Description */}
          <div className="bg-white rounded-2xl p-4 shadow-md">
            <h4 className="mb-2">About This Scheme</h4>
            <p className="text-sm text-gray-600">{selectedScheme.description}</p>
          </div>

          {/* Benefits */}
          <div className="bg-white rounded-2xl p-4 shadow-md">
            <h4 className="mb-3 flex items-center gap-2">
              <CheckCircle className="w-5 h-5 text-green-600" />
              Key Benefits
            </h4>
            <ul className="space-y-2">
              {selectedScheme.benefits.map((benefit, idx) => (
                <li key={idx} className="text-sm text-gray-700 flex items-start gap-2">
                  <span className="text-green-600 mt-0.5">✓</span>
                  <span>{benefit}</span>
                </li>
              ))}
            </ul>
          </div>

          {/* Eligibility Criteria */}
          <div className="bg-white rounded-2xl p-4 shadow-md">
            <h4 className="mb-3 flex items-center gap-2">
              <AlertCircle className="w-5 h-5 text-orange-600" />
              Eligibility Criteria
            </h4>
            <ul className="space-y-2">
              {selectedScheme.criteria.map((criterion, idx) => (
                <li key={idx} className="text-sm text-gray-700 flex items-start gap-2">
                  <span className="text-orange-600 mt-0.5">•</span>
                  <span>{criterion}</span>
                </li>
              ))}
            </ul>
          </div>

          {/* Required Documents */}
          <div className="bg-white rounded-2xl p-4 shadow-md">
            <h4 className="mb-3 flex items-center gap-2">
              <FileText className="w-5 h-5 text-blue-600" />
              Required Documents
            </h4>
            <ul className="space-y-2">
              {selectedScheme.documents.map((doc, idx) => (
                <li key={idx} className="text-sm text-gray-700 flex items-start gap-2">
                  <span className="text-blue-600 mt-0.5">📄</span>
                  <span>{doc}</span>
                </li>
              ))}
            </ul>
          </div>

          {/* Application Steps */}
          <div className="bg-white rounded-2xl p-4 shadow-md">
            <h4 className="mb-3 flex items-center gap-2">
              📋 How to Apply
            </h4>
            <div className="space-y-3">
              {selectedScheme.steps.map((step, idx) => (
                <div key={idx} className="flex items-start gap-3">
                  <div className="w-6 h-6 bg-[#1E7F43] text-white rounded-full flex items-center justify-center text-xs flex-shrink-0">
                    {idx + 1}
                  </div>
                  <p className="text-sm text-gray-700 flex-1">{step}</p>
                </div>
              ))}
            </div>
          </div>

          {/* Help Section */}
          <div className="bg-blue-50 rounded-2xl p-4 border border-blue-200">
            <h4 className="mb-2 text-blue-900">Need Help with Application?</h4>
            <p className="text-sm text-blue-800 mb-3">
              Our agriculture experts can guide you through the application process
            </p>
            <Button
              variant="outline"
              className="w-full border-blue-600 text-blue-600 hover:bg-blue-50"
            >
              <HelpCircle className="w-4 h-4 mr-2" />
              Talk to Expert
            </Button>
          </div>
        </div>

        {/* Bottom Actions */}
        <div className="fixed bottom-0 left-0 right-0 bg-white border-t p-4 shadow-lg">
          <div className="flex gap-3 max-w-md mx-auto">
            {selectedScheme.eligibility === 'possibly' && (
              <Button
                variant="outline"
                size="lg"
                onClick={() => setView('eligibilityChecker')}
                className="flex-1 rounded-xl"
              >
                Check Eligibility
              </Button>
            )}
            <Button
              size="lg"
              onClick={() => setView('application')}
              className={`flex-1 rounded-xl bg-[#1E7F43] hover:bg-[#15593A] ${
                selectedScheme.eligibility === 'not' ? 'opacity-50 cursor-not-allowed' : ''
              }`}
              disabled={selectedScheme.eligibility === 'not'}
            >
              {selectedScheme.eligibility === 'eligible' ? 'Apply Now' : 'Get Started'}
            </Button>
          </div>
        </div>
      </div>
    );
  }

  // Eligibility Checker
  if (view === 'eligibilityChecker') {
    return (
      <div className="min-h-screen bg-gray-50 pb-24">
        {/* Header */}
        <div className="bg-white border-b sticky top-0 z-10">
          <button
            onClick={() => setView('home')}
            className="flex items-center gap-2 text-[#1E7F43] p-4 hover:bg-green-50 transition-colors"
          >
            <div className="bg-green-50 rounded-full p-1">
              <ArrowLeft className="w-5 h-5" />
            </div>
            <span>Back</span>
          </button>
          <div className="px-4 pb-4">
            <h2>Eligibility Checker</h2>
            <p className="text-sm text-gray-500">Answer a few questions to find suitable schemes</p>
          </div>
        </div>

        <div className="p-4 space-y-4">
          <div className="bg-white rounded-2xl p-4 shadow-md space-y-4">
            {/* Farmer Type */}
            <div>
              <label className="block mb-2 text-sm">I am a...</label>
              <select
                value={farmerType}
                onChange={(e) => setFarmerType(e.target.value)}
                className="w-full p-3 border rounded-xl bg-gray-50"
              >
                <option value="">Select farmer type</option>
                <option value="landowner">Landowner Farmer</option>
                <option value="tenant">Tenant Farmer (Lease)</option>
                <option value="sharecropper">Sharecropper</option>
              </select>
            </div>

            {/* Land Size */}
            <div>
              <label className="block mb-2 text-sm">Total Land Size (in acres)</label>
              <Input
                type="number"
                value={landSize}
                onChange={(e) => setLandSize(e.target.value)}
                placeholder="e.g., 10"
                className="rounded-xl"
              />
            </div>

            {/* Crop Type */}
            <div>
              <label className="block mb-2 text-sm">Main Crop You Grow</label>
              <select
                value={cropType}
                onChange={(e) => setCropType(e.target.value)}
                className="w-full p-3 border rounded-xl bg-gray-50"
              >
                <option value="">Select crop</option>
                <option value="wheat">Wheat</option>
                <option value="rice">Rice</option>
                <option value="cotton">Cotton</option>
                <option value="sugarcane">Sugarcane</option>
                <option value="vegetables">Vegetables</option>
                <option value="fruits">Fruits</option>
              </select>
            </div>

            {/* Region */}
            <div>
              <label className="block mb-2 text-sm">Your Region</label>
              <select
                value={region}
                onChange={(e) => setRegion(e.target.value)}
                className="w-full p-3 border rounded-xl bg-gray-50"
              >
                <option value="">Select region</option>
                <option value="punjab">Punjab</option>
                <option value="sindh">Sindh</option>
                <option value="kpk">Khyber Pakhtunkhwa</option>
                <option value="balochistan">Balochistan</option>
              </select>
            </div>
          </div>

          <div className="bg-blue-50 rounded-2xl p-4 border border-blue-200">
            <p className="text-sm text-blue-800">
              💡 Your information is used only for eligibility checking and is not stored or shared.
            </p>
          </div>
        </div>

        {/* Bottom Action */}
        <div className="fixed bottom-0 left-0 right-0 bg-white border-t p-4 shadow-lg">
          <Button
            size="lg"
            onClick={checkEligibility}
            disabled={!landSize || !cropType || !region || !farmerType}
            className="w-full max-w-md mx-auto rounded-xl bg-[#1E7F43] hover:bg-[#15593A] disabled:opacity-50"
          >
            Check My Eligibility
          </Button>
        </div>
      </div>
    );
  }

  // Eligibility Result
  if (view === 'eligibilityResult') {
    const eligibleSchemes = eligibilityResults.filter(s => s.eligibility === 'eligible' || s.eligibility === 'possibly');
    
    return (
      <div className="min-h-screen bg-gray-50">
        {/* Header */}
        <div className="bg-white border-b sticky top-0 z-10">
          <button
            onClick={() => setView('eligibilityChecker')}
            className="flex items-center gap-2 text-[#1E7F43] p-4 hover:bg-green-50 transition-colors"
          >
            <div className="bg-green-50 rounded-full p-1">
              <ArrowLeft className="w-5 h-5" />
            </div>
            <span>Back</span>
          </button>
        </div>

        <div className="p-4 space-y-4">
          {/* Result Summary */}
          <div className="bg-gradient-to-r from-[#1E7F43] to-[#15593A] text-white rounded-2xl p-5 shadow-lg text-center">
            <div className="w-16 h-16 bg-white/20 rounded-full flex items-center justify-center mx-auto mb-3">
              <CheckCircle className="w-8 h-8" />
            </div>
            <h2 className="text-white mb-2">Great News!</h2>
            <p className="text-white/90">
              You are eligible for <span className="text-2xl font-bold">{eligibleSchemes.length}</span> government schemes
            </p>
          </div>

          {/* Reasoning */}
          <div className="bg-white rounded-2xl p-4 shadow-md">
            <h4 className="mb-2">Based on Your Profile:</h4>
            <ul className="text-sm text-gray-600 space-y-1">
              <li>• Land size: {landSize} acres</li>
              <li>• Crop: {cropType}</li>
              <li>• Region: {region}</li>
              <li>• Farmer type: {farmerType}</li>
            </ul>
          </div>

          {/* Eligible Schemes */}
          <div>
            <h3 className="text-gray-800 mb-3">Schemes You Can Apply For</h3>
            <div className="space-y-3">
              {eligibleSchemes.map((scheme) => (
                <button
                  key={scheme.id}
                  onClick={() => {
                    setSelectedScheme(scheme);
                    setView('schemeDetail');
                  }}
                  className="w-full bg-white rounded-2xl p-4 shadow-md hover:shadow-lg transition-shadow text-left border-2 border-green-200"
                >
                  <Badge className="bg-green-500 mb-2">✓ Eligible</Badge>
                  <h4 className="mb-2">{scheme.name}</h4>
                  <p className="text-sm text-gray-600 mb-2">{scheme.benefit}</p>
                  <div className="flex items-center gap-2 text-sm text-green-600">
                    <DollarSign className="w-4 h-4" />
                    <span>{scheme.maxAmount}</span>
                  </div>
                </button>
              ))}
            </div>
          </div>

          {/* Next Steps */}
          <div className="bg-blue-50 rounded-2xl p-4 border border-blue-200">
            <h4 className="mb-2 text-blue-900">Next Steps</h4>
            <ol className="text-sm text-blue-800 space-y-1">
              <li>1. Review each scheme details</li>
              <li>2. Prepare required documents</li>
              <li>3. Apply online or visit nearest office</li>
              <li>4. Get expert help if needed</li>
            </ol>
          </div>
        </div>
      </div>
    );
  }

  // Application View (Assisted)
  if (view === 'application') {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center p-4">
        <div className="bg-white rounded-3xl p-8 shadow-xl max-w-md w-full text-center">
          <div className="w-20 h-20 bg-blue-100 rounded-full flex items-center justify-center mx-auto mb-4">
            <HelpCircle className="w-10 h-10 text-blue-600" />
          </div>
          <h2 className="mb-2">Application Assistance</h2>
          <p className="text-gray-600 mb-6">
            Our experts can guide you step-by-step through the application process and help with documentation.
          </p>

          <div className="bg-green-50 rounded-2xl p-4 mb-6 text-left">
            <h4 className="mb-2 text-green-900">What You'll Get:</h4>
            <ul className="text-sm text-green-800 space-y-1">
              <li>✓ Personalized guidance</li>
              <li>✓ Document checklist</li>
              <li>✓ Form filling help</li>
              <li>✓ Application tracking</li>
            </ul>
          </div>

          <div className="space-y-2">
            <Button
              size="lg"
              className="w-full rounded-xl bg-[#1E7F43] hover:bg-[#15593A]"
            >
              <HelpCircle className="w-4 h-4 mr-2" />
              Connect with Expert
            </Button>
            <Button
              size="lg"
              variant="outline"
              onClick={() => setView('schemeDetail')}
              className="w-full rounded-xl"
            >
              Back to Scheme Details
            </Button>
          </div>
        </div>
      </div>
    );
  }

  return null;
}
