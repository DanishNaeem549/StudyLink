import { useState } from 'react';
import { Send, User, Leaf, Bug, Droplets } from 'lucide-react';
import { Input } from '../ui/input';
import { Button } from '../ui/button';

interface Expert {
  id: number;
  name: string;
  specialty: string;
  rating: number;
  responseTime: string;
  consultations: number;
  available: boolean;
}

export default function ExpertChat() {
  const [selectedExpert, setSelectedExpert] = useState<Expert | null>(null);
  const [message, setMessage] = useState('');
  const [messages, setMessages] = useState<Array<{id: string; type: 'user' | 'expert'; content: string}>>([]);

  const experts: Expert[] = [
    {
      id: 1,
      name: 'Dr. Muhammad Hassan',
      specialty: 'Crop Diseases',
      rating: 4.9,
      responseTime: '< 10 min',
      consultations: 1200,
      available: true
    },
    {
      id: 2,
      name: 'Dr. Ayesha Khan',
      specialty: 'Pest Management',
      rating: 4.8,
      responseTime: '< 15 min',
      consultations: 980,
      available: true
    },
    {
      id: 3,
      name: 'Eng. Ali Raza',
      specialty: 'Irrigation & Soil',
      rating: 4.7,
      responseTime: '< 20 min',
      consultations: 750,
      available: false
    }
  ];

  const handleSendMessage = () => {
    if (!message.trim()) return;

    const userMsg = {
      id: Date.now().toString(),
      type: 'user' as const,
      content: message
    };

    setMessages(prev => [...prev, userMsg]);
    setMessage('');

    // Simulate expert response
    setTimeout(() => {
      const expertMsg = {
        id: (Date.now() + 1).toString(),
        type: 'expert' as const,
        content: 'Thank you for your question. Based on the symptoms you described, I recommend applying neem oil spray. Can you share a photo of the affected plants?'
      };
      setMessages(prev => [...prev, expertMsg]);
    }, 2000);
  };

  if (selectedExpert) {
    return (
      <div className="h-screen flex flex-col bg-gray-50">
        {/* Chat Header */}
        <div className="bg-gradient-to-r from-[#1E7F43] to-[#15593A] text-white p-4">
          <button onClick={() => setSelectedExpert(null)} className="mb-3 flex items-center gap-2">
            ← Back to Experts
          </button>
          <div className="flex items-center gap-3">
            <div className="bg-white rounded-full w-12 h-12 flex items-center justify-center">
              <User className="w-6 h-6 text-[#1E7F43]" />
            </div>
            <div className="flex-1">
              <h3 className="text-lg">{selectedExpert.name}</h3>
              <p className="text-white/80 text-sm">{selectedExpert.specialty}</p>
            </div>
            <div className="bg-white/20 px-3 py-1 rounded-full text-xs">
              {selectedExpert.available ? 'Online' : 'Offline'}
            </div>
          </div>
        </div>

        {/* Messages */}
        <div className="flex-1 overflow-y-auto p-4 space-y-4">
          {messages.length === 0 ? (
            <div className="text-center text-gray-500 mt-8">
              <p className="mb-2">Start a conversation with the expert</p>
              <p className="text-sm">Ask about crops, pests, diseases, or farming techniques</p>
            </div>
          ) : (
            messages.map((msg) => (
              <div key={msg.id} className={`flex ${msg.type === 'user' ? 'justify-end' : 'justify-start'}`}>
                <div className={`max-w-[80%] rounded-2xl p-3 ${
                  msg.type === 'user' ? 'bg-[#1E7F43] text-white' : 'bg-white text-gray-800'
                }`}>
                  <p className="text-sm">{msg.content}</p>
                </div>
              </div>
            ))
          )}
        </div>

        {/* Message Limit Notice */}
        <div className="px-4 py-2 bg-yellow-50 border-t border-yellow-200">
          <p className="text-xs text-yellow-800 text-center">
            5 free messages remaining today. <button className="underline">Upgrade for unlimited</button>
          </p>
        </div>

        {/* Input */}
        <div className="p-4 bg-white border-t">
          <div className="flex gap-2">
            <Input
              value={message}
              onChange={(e) => setMessage(e.target.value)}
              onKeyPress={(e) => e.key === 'Enter' && handleSendMessage()}
              placeholder="Type your question..."
              className="flex-1 rounded-xl h-12"
            />
            <Button
              onClick={handleSendMessage}
              className="bg-[#1E7F43] hover:bg-[#15593A] px-6 rounded-xl"
            >
              <Send className="w-5 h-5" />
            </Button>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="p-4 space-y-4">
      <div>
        <h2 className="text-gray-800 text-xl mb-1">Expert Advisory</h2>
        <p className="text-gray-600 text-sm">Get professional agricultural guidance</p>
      </div>

      {/* Message Limit */}
      <div className="bg-gradient-to-r from-[#1E7F43] to-[#15593A] text-white rounded-2xl p-5">
        <h3 className="text-lg mb-2">Free Daily Consultations</h3>
        <div className="flex items-end gap-2 mb-3">
          <span className="text-4xl">5</span>
          <span className="text-white/80 mb-1">messages remaining today</span>
        </div>
        <Button variant="secondary" size="sm" className="bg-white text-[#1E7F43] hover:bg-white/90">
          Upgrade to Unlimited
        </Button>
      </div>

      {/* Available Experts */}
      <div>
        <h3 className="text-gray-800 mb-3">Available Experts</h3>
        <div className="space-y-3">
          {experts.map((expert) => (
            <div 
              key={expert.id}
              onClick={() => expert.available && setSelectedExpert(expert)}
              className={`bg-white rounded-2xl p-4 border-2 ${
                expert.available 
                  ? 'border-gray-200 hover:border-[#1E7F43] cursor-pointer' 
                  : 'border-gray-200 opacity-60'
              } transition-all`}
            >
              <div className="flex items-start gap-3">
                <div className="bg-[#1E7F43] rounded-full w-12 h-12 flex items-center justify-center flex-shrink-0">
                  <User className="w-6 h-6 text-white" />
                </div>
                <div className="flex-1">
                  <div className="flex items-start justify-between mb-2">
                    <div>
                      <h4 className="text-gray-800">{expert.name}</h4>
                      <p className="text-sm text-gray-600">{expert.specialty}</p>
                    </div>
                    <div className={`px-3 py-1 rounded-full text-xs ${
                      expert.available ? 'bg-green-100 text-green-700' : 'bg-gray-100 text-gray-600'
                    }`}>
                      {expert.available ? 'Available' : 'Offline'}
                    </div>
                  </div>
                  <div className="flex items-center gap-4 text-sm text-gray-600">
                    <span>⭐ {expert.rating}</span>
                    <span>⏱ {expert.responseTime}</span>
                    <span>👥 {expert.consultations}+</span>
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* FAQ Knowledge Base */}
      <div className="bg-white rounded-2xl p-5">
        <h3 className="text-gray-800 mb-4">Quick Help Topics</h3>
        <div className="grid grid-cols-2 gap-3">
          <button className="bg-green-50 border-2 border-green-200 rounded-xl p-4 text-left hover:bg-green-100 transition-colors">
            <Leaf className="w-6 h-6 text-green-600 mb-2" />
            <p className="text-sm text-gray-800">Crop Diseases</p>
          </button>
          <button className="bg-red-50 border-2 border-red-200 rounded-xl p-4 text-left hover:bg-red-100 transition-colors">
            <Bug className="w-6 h-6 text-red-600 mb-2" />
            <p className="text-sm text-gray-800">Pest Control</p>
          </button>
          <button className="bg-blue-50 border-2 border-blue-200 rounded-xl p-4 text-left hover:bg-blue-100 transition-colors">
            <Droplets className="w-6 h-6 text-blue-600 mb-2" />
            <p className="text-sm text-gray-800">Irrigation</p>
          </button>
          <button className="bg-yellow-50 border-2 border-yellow-200 rounded-xl p-4 text-left hover:bg-yellow-100 transition-colors">
            <Leaf className="w-6 h-6 text-yellow-600 mb-2" />
            <p className="text-sm text-gray-800">Fertilizers</p>
          </button>
        </div>
      </div>

      {/* Recent Consultations */}
      <div className="bg-white rounded-2xl p-5">
        <h3 className="text-gray-800 mb-4">Recent Consultations</h3>
        <div className="space-y-3">
          <div className="p-3 bg-gray-50 rounded-xl">
            <div className="flex items-center justify-between mb-1">
              <span className="text-sm text-gray-800">Tomato Leaf Curl Issue</span>
              <span className="text-xs text-gray-500">Dec 18</span>
            </div>
            <p className="text-xs text-gray-600">Dr. Muhammad Hassan</p>
          </div>
          <div className="p-3 bg-gray-50 rounded-xl">
            <div className="flex items-center justify-between mb-1">
              <span className="text-sm text-gray-800">Aphid Infestation</span>
              <span className="text-xs text-gray-500">Dec 15</span>
            </div>
            <p className="text-xs text-gray-600">Dr. Ayesha Khan</p>
          </div>
        </div>
      </div>
    </div>
  );
}
