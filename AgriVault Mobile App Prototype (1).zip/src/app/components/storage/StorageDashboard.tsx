import { Warehouse, Users, DollarSign, Package, TrendingUp, Calendar } from 'lucide-react';
import { Button } from '../ui/button';

interface StorageDashboardProps {
  onLogout: () => void;
}

export default function StorageDashboard({ onLogout }: StorageDashboardProps) {
  const bookings = [
    { id: 1, farmer: 'Ahmed Ali', crop: 'Tomatoes', quantity: '500 kg', days: 12, status: 'active', amount: 4800 },
    { id: 2, farmer: 'Hassan Raza', crop: 'Potatoes', quantity: '1000 kg', days: 20, status: 'active', amount: 8000 },
    { id: 3, farmer: 'Ali Khan', crop: 'Onions', quantity: '750 kg', days: 8, status: 'active', amount: 4200 }
  ];

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <div className="bg-gradient-to-r from-purple-500 to-purple-600 text-white p-6">
        <h2 className="text-2xl mb-1">Storage Dashboard</h2>
        <p className="text-white/80 text-sm">Green Valley Cold Storage</p>
      </div>

      <div className="p-4 space-y-4">
        {/* Stats */}
        <div className="grid grid-cols-2 gap-3">
          <div className="bg-white rounded-2xl p-4">
            <Warehouse className="w-6 h-6 text-purple-500 mb-2" />
            <p className="text-2xl text-gray-800 mb-1">200 tons</p>
            <p className="text-sm text-gray-600">Available</p>
          </div>

          <div className="bg-white rounded-2xl p-4">
            <Package className="w-6 h-6 text-blue-500 mb-2" />
            <p className="text-2xl text-gray-800 mb-1">300 tons</p>
            <p className="text-sm text-gray-600">Occupied</p>
          </div>

          <div className="bg-white rounded-2xl p-4">
            <Users className="w-6 h-6 text-green-500 mb-2" />
            <p className="text-2xl text-gray-800 mb-1">24</p>
            <p className="text-sm text-gray-600">Active Farmers</p>
          </div>

          <div className="bg-white rounded-2xl p-4">
            <DollarSign className="w-6 h-6 text-orange-500 mb-2" />
            <p className="text-2xl text-gray-800 mb-1">₨65K</p>
            <p className="text-sm text-gray-600">This Month</p>
          </div>
        </div>

        {/* Capacity Bar */}
        <div className="bg-white rounded-2xl p-5">
          <h3 className="text-gray-800 mb-3">Capacity Status</h3>
          <div className="mb-2">
            <div className="flex items-center justify-between text-sm mb-2">
              <span className="text-gray-600">60% Occupied</span>
              <span className="text-gray-800">300/500 tons</span>
            </div>
            <div className="bg-gray-200 rounded-full h-3">
              <div className="bg-purple-500 rounded-full h-3" style={{ width: '60%' }}></div>
            </div>
          </div>
        </div>

        {/* Active Bookings */}
        <div className="bg-white rounded-2xl p-5">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-gray-800">Active Bookings</h3>
            <button className="text-purple-600 text-sm">View All</button>
          </div>
          <div className="space-y-3">
            {bookings.map((booking) => (
              <div key={booking.id} className="p-4 bg-gray-50 rounded-xl">
                <div className="flex items-center justify-between mb-2">
                  <div>
                    <h4 className="text-gray-800">{booking.farmer}</h4>
                    <p className="text-sm text-gray-600">{booking.crop} • {booking.quantity}</p>
                  </div>
                  <span className="bg-green-100 text-green-700 px-2 py-1 rounded-full text-xs">
                    {booking.status}
                  </span>
                </div>
                <div className="flex items-center justify-between text-sm">
                  <span className="text-gray-500">{booking.days} days remaining</span>
                  <span className="text-purple-600">₨{booking.amount}</span>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Quick Actions */}
        <div className="grid grid-cols-2 gap-3">
          <button className="bg-purple-500 text-white rounded-2xl p-5 text-left hover:shadow-lg transition-shadow">
            <Calendar className="w-6 h-6 mb-2" />
            <p className="text-sm">View Calendar</p>
          </button>
          <button className="bg-blue-500 text-white rounded-2xl p-5 text-left hover:shadow-lg transition-shadow">
            <TrendingUp className="w-6 h-6 mb-2" />
            <p className="text-sm">Analytics</p>
          </button>
        </div>

        <Button onClick={onLogout} variant="destructive" className="w-full">
          Logout
        </Button>
      </div>
    </div>
  );
}
