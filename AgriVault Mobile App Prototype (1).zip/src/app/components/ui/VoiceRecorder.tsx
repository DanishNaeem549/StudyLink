import { useState, useRef, useEffect } from 'react';
import { Mic, X, Send, Wifi, WifiOff } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { useLanguage } from '../../contexts/LanguageContext';

interface VoiceRecorderProps {
  onRecordComplete: (audioBlob: Blob, transcription?: string) => void;
  isOnline?: boolean;
  language?: 'en' | 'ur';
}

export default function VoiceRecorder({ 
  onRecordComplete, 
  isOnline = true,
  language = 'ur' 
}: VoiceRecorderProps) {
  const [isRecording, setIsRecording] = useState(false);
  const [duration, setDuration] = useState(0);
  const [audioLevel, setAudioLevel] = useState(0);
  const [showCancelPrompt, setShowCancelPrompt] = useState(false);
  const timerRef = useRef<NodeJS.Timeout>();
  const { t } = useLanguage();

  useEffect(() => {
    if (isRecording) {
      timerRef.current = setInterval(() => {
        setDuration(prev => prev + 1);
        // Simulate audio level for visual feedback
        setAudioLevel(Math.random() * 100);
      }, 1000);
    } else {
      if (timerRef.current) clearInterval(timerRef.current);
      setDuration(0);
      setAudioLevel(0);
    }
    return () => {
      if (timerRef.current) clearInterval(timerRef.current);
    };
  }, [isRecording]);

  const handleStart = () => {
    setIsRecording(true);
    setShowCancelPrompt(false);
    // In production, start actual audio recording here
  };

  const handleStop = () => {
    setIsRecording(false);
    // In production, stop recording and get audio blob
    const dummyBlob = new Blob([''], { type: 'audio/webm' });
    onRecordComplete(dummyBlob, 'Sample transcription');
  };

  const handleCancel = () => {
    setIsRecording(false);
    setShowCancelPrompt(false);
  };

  const formatDuration = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins}:${secs.toString().padStart(2, '0')}`;
  };

  return (
    <>
      {/* Recording Interface */}
      <AnimatePresence>
        {isRecording && (
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: 20 }}
            className="fixed inset-0 bg-black/50 backdrop-blur-sm z-50 flex items-center justify-center p-4"
          >
            <div className="bg-white rounded-3xl p-6 w-full max-w-sm">
              {/* Offline Indicator */}
              {!isOnline && (
                <div className="mb-4 bg-orange-50 border border-orange-200 rounded-xl p-3 flex items-center gap-2">
                  <WifiOff className="w-4 h-4 text-orange-600" />
                  <p className="text-xs text-orange-800">{t('voice.recordingOffline')}</p>
                </div>
              )}

              {/* Waveform Visualization */}
              <div className="mb-6">
                <div className="flex items-center justify-center gap-1 h-32 mb-4">
                  {[...Array(20)].map((_, i) => (
                    <motion.div
                      key={i}
                      className="w-1 bg-[#1E7F43] rounded-full"
                      animate={{
                        height: isRecording 
                          ? `${20 + Math.random() * 80}%` 
                          : '20%'
                      }}
                      transition={{
                        duration: 0.3,
                        repeat: Infinity,
                        repeatType: 'reverse',
                        delay: i * 0.05
                      }}
                    />
                  ))}
                </div>

                {/* Recording Status */}
                <div className="text-center">
                  <div className="flex items-center justify-center gap-2 mb-2">
                    <div className="w-3 h-3 bg-red-500 rounded-full animate-pulse" />
                    <p className="text-sm text-gray-700">{t('ai.listening')}</p>
                  </div>
                  <p className="text-2xl font-mono text-gray-800">{formatDuration(duration)}</p>
                </div>
              </div>

              {/* Language Indicator */}
              <div className="mb-4 text-center">
                <span className="inline-flex items-center gap-2 bg-green-50 text-green-700 px-3 py-1 rounded-full text-xs">
                  <Mic className="w-3 h-3" />
                  <span>{language === 'ur' ? 'اردو' : 'English'}</span>
                </span>
              </div>

              {/* Instructions */}
              <div className="mb-4 text-center">
                <p className="text-xs text-gray-500">
                  {language === 'ur' 
                    ? 'بولتے رہیں، ہم سن رہے ہیں...' 
                    : 'Keep speaking, we\'re listening...'}
                </p>
              </div>

              {/* Actions */}
              <div className="flex gap-3">
                <button
                  onClick={handleCancel}
                  className="flex-1 bg-gray-100 hover:bg-gray-200 text-gray-700 py-3 rounded-xl transition-colors flex items-center justify-center gap-2"
                >
                  <X className="w-5 h-5" />
                  <span>{t('common.cancel')}</span>
                </button>
                <button
                  onClick={handleStop}
                  className="flex-1 bg-[#1E7F43] hover:bg-[#15593A] text-white py-3 rounded-xl transition-colors flex items-center justify-center gap-2"
                >
                  <Send className="w-5 h-5" />
                  <span>{t('common.submit')}</span>
                </button>
              </div>

              {/* Offline Save Notice */}
              {!isOnline && (
                <div className="mt-3 text-center">
                  <p className="text-xs text-gray-500">{t('voice.savedLocally')}</p>
                </div>
              )}
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Trigger Button */}
      <button
        onMouseDown={handleStart}
        onMouseUp={handleStop}
        onTouchStart={handleStart}
        onTouchEnd={handleStop}
        className={`relative p-3 rounded-xl transition-all ${
          isRecording 
            ? 'bg-red-500 text-white animate-pulse' 
            : 'bg-[#1E7F43] hover:bg-[#15593A] text-white'
        }`}
      >
        <Mic className="w-5 h-5" />
        
        {/* Offline Badge */}
        {!isOnline && (
          <div className="absolute -top-1 -right-1 w-3 h-3 bg-orange-500 rounded-full border-2 border-white" />
        )}
      </button>
    </>
  );
}

// Voice Message Player Component
interface VoiceMessageProps {
  duration: number;
  audioUrl?: string;
  isPlaying?: boolean;
  onPlay?: () => void;
  isOffline?: boolean;
  isPending?: boolean;
}

export function VoiceMessage({ 
  duration, 
  audioUrl, 
  isPlaying = false, 
  onPlay,
  isOffline = false,
  isPending = false
}: VoiceMessageProps) {
  const [progress, setProgress] = useState(0);
  const { t, language } = useLanguage();

  const formatDuration = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins}:${secs.toString().padStart(2, '0')}`;
  };

  return (
    <div className={`bg-green-50 rounded-2xl p-3 flex items-center gap-3 ${language === 'ur' ? 'flex-row-reverse' : ''}`}>
      {/* Play Button */}
      <button
        onClick={onPlay}
        disabled={isPending}
        className={`w-10 h-10 rounded-full flex items-center justify-center transition-colors flex-shrink-0 ${
          isPending 
            ? 'bg-gray-300 cursor-not-allowed' 
            : 'bg-[#1E7F43] hover:bg-[#15593A]'
        } text-white`}
      >
        {isPlaying ? (
          <motion.div
            animate={{ scale: [1, 0.8, 1] }}
            transition={{ repeat: Infinity, duration: 1 }}
          >
            <div className="w-1 h-4 bg-white" />
          </motion.div>
        ) : (
          <div className="w-0 h-0 border-l-[8px] border-l-white border-y-[6px] border-y-transparent ml-1" />
        )}
      </button>

      {/* Waveform */}
      <div className="flex-1 flex items-center gap-0.5 h-8">
        {[...Array(30)].map((_, i) => {
          const height = 20 + Math.random() * 60;
          const isActive = progress > (i / 30) * 100;
          return (
            <div
              key={i}
              className={`w-1 rounded-full transition-colors ${
                isActive ? 'bg-[#1E7F43]' : 'bg-gray-300'
              }`}
              style={{ height: `${height}%` }}
            />
          );
        })}
      </div>

      {/* Duration & Status */}
      <div className="flex flex-col items-end gap-1">
        <span className="text-xs text-gray-600 font-mono">
          {formatDuration(duration)}
        </span>
        {isPending && (
          <span className="text-xs text-orange-600 flex items-center gap-1">
            <WifiOff className="w-3 h-3" />
            <span>{t('status.syncing')}</span>
          </span>
        )}
      </div>
    </div>
  );
}

// Text-to-Speech Player for AI Responses
interface TTSPlayerProps {
  text: string;
  language?: 'en' | 'ur';
}

export function TTSPlayer({ text, language = 'ur' }: TTSPlayerProps) {
  const [isPlaying, setIsPlaying] = useState(false);
  const { t } = useLanguage();

  const handlePlay = () => {
    setIsPlaying(true);
    // In production, use Web Speech API or audio stream
    setTimeout(() => {
      setIsPlaying(false);
    }, 3000);
  };

  return (
    <button
      onClick={handlePlay}
      disabled={isPlaying}
      className={`mt-2 flex items-center gap-2 px-3 py-1.5 rounded-lg transition-colors text-xs ${
        isPlaying 
          ? 'bg-green-100 text-green-700' 
          : 'bg-gray-100 hover:bg-gray-200 text-gray-700'
      }`}
    >
      {isPlaying ? (
        <>
          <motion.div
            animate={{ scale: [1, 1.2, 1] }}
            transition={{ repeat: Infinity, duration: 1 }}
            className="w-4 h-4 text-green-600"
          >
            🔊
          </motion.div>
          <span>{t('ai.speaking')}</span>
        </>
      ) : (
        <>
          <span>🔊</span>
          <span>{t('ai.playAudio')}</span>
        </>
      )}
    </button>
  );
}