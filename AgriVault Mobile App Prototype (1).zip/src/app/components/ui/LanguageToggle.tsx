import { useLanguage } from '../../contexts/LanguageContext';
import { motion } from 'motion/react';
import { Languages } from 'lucide-react';

export default function LanguageToggle() {
  const { language, toggleLanguage } = useLanguage();

  return (
    <button
      onClick={toggleLanguage}
      className="relative flex items-center gap-2 bg-white/90 hover:bg-white border border-gray-200 rounded-full px-3 py-1.5 shadow-sm hover:shadow-md transition-all"
      aria-label="Toggle language"
    >
      <Languages className="w-4 h-4 text-gray-600" />
      
      {/* Toggle Container */}
      <div className="relative flex items-center bg-gray-100 rounded-full p-0.5 w-20">
        {/* Sliding Background */}
        <motion.div
          className="absolute inset-y-0.5 w-9 bg-[#1E7F43] rounded-full"
          initial={false}
          animate={{
            x: language === 'en' ? 1 : 39
          }}
          transition={{ type: 'spring', stiffness: 500, damping: 30 }}
        />
        
        {/* EN Label */}
        <span
          className={`relative z-10 flex-1 text-center text-xs font-medium transition-colors ${
            language === 'en' ? 'text-white' : 'text-gray-600'
          }`}
        >
          EN
        </span>
        
        {/* UR Label */}
        <span
          className={`relative z-10 flex-1 text-center text-xs font-medium transition-colors ${
            language === 'ur' ? 'text-white' : 'text-gray-600'
          }`}
          style={{ fontFamily: 'Noto Nastaliq Urdu, serif' }}
        >
          اردو
        </span>
      </div>
    </button>
  );
}

// Compact version for mobile headers
export function LanguageToggleCompact() {
  const { language, toggleLanguage } = useLanguage();

  return (
    <button
      onClick={toggleLanguage}
      className="relative bg-white/20 hover:bg-white/30 backdrop-blur-sm rounded-full px-3 py-1.5 transition-all border border-white/30"
      aria-label="Toggle language"
    >
      <div className="flex items-center gap-2">
        <Languages className="w-3.5 h-3.5 text-white" />
        <motion.div
          key={language}
          initial={{ scale: 0.8, opacity: 0 }}
          animate={{ scale: 1, opacity: 1 }}
          className="text-xs font-semibold text-white min-w-[32px] text-center"
        >
          {language === 'en' ? 'EN' : 'اُردو'}
        </motion.div>
      </div>
    </button>
  );
}