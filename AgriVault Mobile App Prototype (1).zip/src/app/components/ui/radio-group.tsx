import * as React from 'react';

interface RadioGroupContextValue {
  value: string;
  onValueChange: (value: string) => void;
}

const RadioGroupContext = React.createContext<RadioGroupContextValue | undefined>(
  undefined
);

interface RadioGroupProps {
  value: string;
  onValueChange: (value: string) => void;
  children: React.ReactNode;
  className?: string;
}

const RadioGroup: React.FC<RadioGroupProps> = ({
  value,
  onValueChange,
  children,
  className = '',
}) => {
  return (
    <RadioGroupContext.Provider value={{ value, onValueChange }}>
      <div className={className}>{children}</div>
    </RadioGroupContext.Provider>
  );
};

interface RadioGroupItemProps {
  value: string;
  id: string;
  className?: string;
}

const RadioGroupItem: React.FC<RadioGroupItemProps> = ({
  value,
  id,
  className = '',
}) => {
  const context = React.useContext(RadioGroupContext);
  if (!context) {
    throw new Error('RadioGroupItem must be used within RadioGroup');
  }

  const isChecked = context.value === value;

  return (
    <button
      type="button"
      role="radio"
      aria-checked={isChecked}
      id={id}
      onClick={() => context.onValueChange(value)}
      className={`w-5 h-5 rounded-full border-2 flex items-center justify-center transition ${
        isChecked
          ? 'border-[#1E7F43] bg-[#1E7F43]'
          : 'border-gray-300 bg-white hover:border-gray-400'
      } ${className}`}
    >
      {isChecked && <div className="w-2 h-2 rounded-full bg-white" />}
    </button>
  );
};

export { RadioGroup, RadioGroupItem };
