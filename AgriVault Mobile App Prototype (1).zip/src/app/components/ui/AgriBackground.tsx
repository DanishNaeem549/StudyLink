import { ReactNode } from 'react';
import { LanguageToggleCompact } from './LanguageToggle';

type BackgroundVariant = 'wheat' | 'crops' | 'irrigation' | 'soil' | 'sunrise' | 'vegetable' | 'rice';

interface AgriBackgroundProps {
  children: ReactNode;
  variant?: BackgroundVariant;
  className?: string;
  showLanguageToggle?: boolean;
}

const backgroundImages: Record<BackgroundVariant, string> = {
  wheat: 'https://images.unsplash.com/photo-1574943320219-553eb213f72d?w=1200',
  crops: 'https://images.unsplash.com/photo-1560493676-04071c5f467b?w=1200',
  irrigation: 'https://images.unsplash.com/photo-1625246333195-78d9c38ad449?w=1200',
  soil: 'https://images.unsplash.com/photo-1592982537447-7440770cbfc9?w=1200',
  sunrise: 'https://images.unsplash.com/photo-1500382017468-9049fed747ef?w=1200',
  vegetable: 'https://images.unsplash.com/photo-1566385101042-1a0aa0c1268c?w=1200',
  rice: 'https://images.unsplash.com/photo-1536882240095-0379873feb4e?w=1200'
};

export default function AgriBackground({ 
  children, 
  variant = 'wheat', 
  className = '',
  showLanguageToggle = false
}: AgriBackgroundProps) {
  return (
    <div 
      className={`min-h-screen relative ${className}`}
      style={{
        backgroundImage: `linear-gradient(to bottom, rgba(30, 127, 67, 0.03), rgba(255, 255, 255, 0.95) 30%), url(${backgroundImages[variant]})`,
        backgroundSize: 'cover',
        backgroundPosition: 'center top',
        backgroundRepeat: 'no-repeat',
        backgroundAttachment: 'fixed'
      }}
    >
      {showLanguageToggle && (
        <div className="absolute top-4 right-4 z-50">
          <LanguageToggleCompact />
        </div>
      )}
      {children}
    </div>
  );
}

interface AgriHeroProps {
  title: string;
  subtitle?: string;
  variant?: BackgroundVariant;
  className?: string;
  children?: ReactNode;
  showLanguageToggle?: boolean;
}

export function AgriHero({ 
  title, 
  subtitle, 
  variant = 'sunrise', 
  className = '',
  children,
  showLanguageToggle = false
}: AgriHeroProps) {
  return (
    <div 
      className={`relative bg-gradient-to-br from-[#1E7F43] to-[#15593A] text-white rounded-3xl p-6 overflow-hidden ${className}`}
      style={{
        backgroundImage: `linear-gradient(to bottom right, rgba(30, 127, 67, 0.95), rgba(21, 89, 58, 0.95)), url(${backgroundImages[variant]})`,
        backgroundSize: 'cover',
        backgroundPosition: 'center',
      }}
    >
      {showLanguageToggle && (
        <div className="absolute top-4 right-4">
          <LanguageToggleCompact />
        </div>
      )}
      <div className={showLanguageToggle ? 'pr-20' : ''}>
        <h1 className="text-2xl mb-2">{title}</h1>
        {subtitle && <p className="text-white/80 text-sm">{subtitle}</p>}
      </div>
      {children}
    </div>
  );
}

interface AgriSectionProps {
  children: ReactNode;
  variant?: BackgroundVariant;
  className?: string;
  overlay?: boolean;
}

export function AgriSection({ 
  children, 
  variant = 'crops', 
  className = '',
  overlay = true
}: AgriSectionProps) {
  return (
    <div 
      className={`relative rounded-2xl p-6 overflow-hidden ${className}`}
      style={{
        backgroundImage: overlay 
          ? `linear-gradient(to bottom, rgba(255, 255, 255, 0.95), rgba(255, 255, 255, 0.98)), url(${backgroundImages[variant]})`
          : `url(${backgroundImages[variant]})`,
        backgroundSize: 'cover',
        backgroundPosition: 'center',
      }}
    >
      {children}
    </div>
  );
}
