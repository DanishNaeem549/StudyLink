import { useState } from 'react';
import { Home, Search, ShoppingCart, Package, User, Star, MapPin, Filter, ArrowLeft, Check, Truck, Phone } from 'lucide-react';
import { Button } from '../ui/button';
import { Input } from '../ui/input';
import { Badge } from '../ui/badge';
import AgriBackground, { AgriHero } from '../ui/AgriBackground';

interface BuyerDashboardProps {
  onLogout: () => void;
}

type View = 'home' | 'browse' | 'productDetail' | 'cart' | 'checkout' | 'orders' | 'orderDetail' | 'profile';

interface Product {
  id: string;
  name: string;
  category: string;
  price: number;
  unit: string;
  available: number;
  image: string;
  supplier: {
    name: string;
    location: string;
    rating: number;
    verified: boolean;
  };
  rating: number;
  description: string;
}

interface CartItem extends Product {
  quantity: number;
}

interface Order {
  id: string;
  date: string;
  items: CartItem[];
  total: number;
  status: 'ordered' | 'confirmed' | 'shipped' | 'delivered';
  supplier: string;
}

export default function BuyerDashboard({ onLogout }: BuyerDashboardProps) {
  const [activeTab, setActiveTab] = useState<'home' | 'browse' | 'cart' | 'orders' | 'profile'>('home');
  const [view, setView] = useState<View>('home');
  const [selectedProduct, setSelectedProduct] = useState<Product | null>(null);
  const [selectedOrder, setSelectedOrder] = useState<Order | null>(null);
  const [cart, setCart] = useState<CartItem[]>([]);
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<string>('all');

  const categories = [
    { id: 'all', name: 'All', icon: '🌾' },
    { id: 'crops', name: 'Crops', icon: '🌾' },
    { id: 'seeds', name: 'Seeds', icon: '🌱' },
    { id: 'fertilizers', name: 'Fertilizers', icon: '🧪' },
    { id: 'pesticides', name: 'Pesticides', icon: '🧴' },
    { id: 'tools', name: 'Tools', icon: '🔧' }
  ];

  const [products] = useState<Product[]>([
    {
      id: 'P001',
      name: 'Premium Wheat',
      category: 'crops',
      price: 45,
      unit: 'per kg',
      available: 5000,
      image: 'https://images.unsplash.com/photo-1574943320219-553eb213f72d?w=400',
      supplier: {
        name: 'Ahmed Farms',
        location: 'Faisalabad - 12 km',
        rating: 4.8,
        verified: true
      },
      rating: 4.7,
      description: 'Grade A premium wheat, freshly harvested. Perfect for flour mills and exporters.'
    },
    {
      id: 'P002',
      name: 'Basmati Rice',
      category: 'crops',
      price: 68,
      unit: 'per kg',
      available: 3000,
      image: 'https://images.unsplash.com/photo-1586201375761-83865001e31c?w=400',
      supplier: {
        name: 'Hassan Rice Mill',
        location: 'Gujranwala - 25 km',
        rating: 4.9,
        verified: true
      },
      rating: 4.9,
      description: 'Super kernel basmati rice. Export quality, aged 2 years.'
    },
    {
      id: 'P003',
      name: 'Fresh Tomatoes',
      category: 'crops',
      price: 52,
      unit: 'per kg',
      available: 800,
      image: 'https://images.unsplash.com/photo-1546094096-0df4bcaaa337?w=400',
      supplier: {
        name: 'Vegetable Hub',
        location: 'Multan - 8 km',
        rating: 4.6,
        verified: true
      },
      rating: 4.5,
      description: 'Farm fresh tomatoes. Grade A quality, ideal for wholesale and processing.'
    },
    {
      id: 'P004',
      name: 'BT Cotton Seeds',
      category: 'seeds',
      price: 3200,
      unit: 'per 5kg',
      available: 500,
      image: 'https://images.unsplash.com/photo-1615485290382-441e4d049cb5?w=400',
      supplier: {
        name: 'AgriSupply Store',
        location: 'Faisalabad - 5 km',
        rating: 4.7,
        verified: true
      },
      rating: 4.8,
      description: 'Certified BT cotton seeds. High yield variety, disease resistant.'
    },
    {
      id: 'P005',
      name: 'NPK Fertilizer',
      category: 'fertilizers',
      price: 4500,
      unit: 'per 50kg',
      available: 200,
      image: 'https://images.unsplash.com/photo-1625246333195-78d9c38ad449?w=400',
      supplier: {
        name: 'AgriSupply Store',
        location: 'Faisalabad - 5 km',
        rating: 4.7,
        verified: true
      },
      rating: 4.6,
      description: 'Balanced NPK fertilizer (20-20-20). Suitable for all crops.'
    }
  ]);

  const [orders] = useState<Order[]>([
    {
      id: 'BUY001',
      date: '2024-12-20',
      items: [
        { ...products[0], quantity: 100 }
      ],
      total: 4500,
      status: 'shipped',
      supplier: 'Ahmed Farms'
    },
    {
      id: 'BUY002',
      date: '2024-12-18',
      items: [
        { ...products[1], quantity: 50 }
      ],
      total: 3400,
      status: 'delivered',
      supplier: 'Hassan Rice Mill'
    }
  ]);

  const stats = {
    activePurchases: orders.filter(o => o.status !== 'delivered').length,
    totalSpent: 42500,
    ordersThisMonth: 8,
    savedSuppliers: 5
  };

  const filteredProducts = products.filter(p => 
    (selectedCategory === 'all' || p.category === selectedCategory) &&
    (searchQuery === '' || p.name.toLowerCase().includes(searchQuery.toLowerCase()))
  );

  const addToCart = (product: Product, quantity: number = 1) => {
    const existing = cart.find(item => item.id === product.id);
    if (existing) {
      setCart(cart.map(item => 
        item.id === product.id ? { ...item, quantity: item.quantity + quantity } : item
      ));
    } else {
      setCart([...cart, { ...product, quantity }]);
    }
  };

  const cartTotal = cart.reduce((sum, item) => sum + item.price * item.quantity, 0);

  const tabs = [
    { id: 'home', icon: Home, label: 'Home' },
    { id: 'browse', icon: Search, label: 'Browse' },
    { id: 'cart', icon: ShoppingCart, label: 'Cart' },
    { id: 'orders', icon: Package, label: 'Orders' },
    { id: 'profile', icon: User, label: 'Profile' }
  ];

  // Home View
  const renderHome = () => (
    <AgriBackground variant="wheat" opacity={8}>
      <AgriHero 
        title="Buyer Dashboard"
        subtitle="Welcome back! Find quality products"
        icon={<ShoppingCart className="w-8 h-8" />}
        variant="crops"
      />

      <div className="p-4 space-y-4">
        {/* Quick Stats */}
        <div className="grid grid-cols-2 gap-3">
          <div className="bg-white rounded-2xl p-4 shadow-md">
            <Package className="w-8 h-8 text-blue-600 mb-2" />
            <p className="text-2xl text-gray-800 mb-1">{stats.activePurchases}</p>
            <p className="text-sm text-gray-500">Active Orders</p>
          </div>
          <div className="bg-white rounded-2xl p-4 shadow-md">
            <ShoppingCart className="w-8 h-8 text-green-600 mb-2" />
            <p className="text-2xl text-gray-800 mb-1">{stats.ordersThisMonth}</p>
            <p className="text-sm text-gray-500">This Month</p>
          </div>
          <div className="bg-white rounded-2xl p-4 shadow-md">
            <Star className="w-8 h-8 text-orange-600 mb-2" />
            <p className="text-2xl text-gray-800 mb-1">PKR {(stats.totalSpent / 1000).toFixed(0)}K</p>
            <p className="text-sm text-gray-500">Total Spent</p>
          </div>
          <div className="bg-white rounded-2xl p-4 shadow-md">
            <User className="w-8 h-8 text-purple-600 mb-2" />
            <p className="text-2xl text-gray-800 mb-1">{stats.savedSuppliers}</p>
            <p className="text-sm text-gray-500">Saved Suppliers</p>
          </div>
        </div>

        {/* Quick Actions */}
        <div className="bg-white rounded-2xl p-4 shadow-md">
          <h3 className="text-gray-800 mb-3">Quick Actions</h3>
          <div className="grid grid-cols-2 gap-3">
            <Button
              onClick={() => setActiveTab('browse')}
              className="bg-[#1E7F43] hover:bg-[#15593A] rounded-xl h-auto py-4 flex flex-col gap-2"
            >
              <Search className="w-6 h-6" />
              <span>Browse Products</span>
            </Button>
            <Button
              variant="outline"
              onClick={() => setActiveTab('orders')}
              className="rounded-xl h-auto py-4 flex flex-col gap-2 border-[#1E7F43] text-[#1E7F43]"
            >
              <Package className="w-6 h-6" />
              <span>My Orders</span>
            </Button>
          </div>
        </div>

        {/* Featured Products */}
        <div>
          <div className="flex items-center justify-between mb-3">
            <h3 className="text-gray-800">Featured Products</h3>
            <Button variant="ghost" size="sm" onClick={() => setActiveTab('browse')}>
              View All
            </Button>
          </div>
          <div className="grid grid-cols-2 gap-3">
            {products.slice(0, 4).map((product) => (
              <button
                key={product.id}
                onClick={() => {
                  setSelectedProduct(product);
                  setView('productDetail');
                }}
                className="bg-white rounded-2xl overflow-hidden shadow-md hover:shadow-lg transition-shadow text-left"
              >
                <div className="aspect-square bg-gray-100 relative">
                  <img src={product.image} alt={product.name} className="w-full h-full object-cover" />
                  {product.supplier.verified && (
                    <Badge className="absolute top-2 right-2 bg-blue-500 text-xs">✓</Badge>
                  )}
                </div>
                <div className="p-3">
                  <h4 className="text-sm mb-1 line-clamp-1">{product.name}</h4>
                  <p className="text-xs text-gray-500 mb-2">{product.supplier.name}</p>
                  <div className="flex items-center justify-between">
                    <p className="text-green-600">PKR {product.price}</p>
                    <div className="flex items-center gap-1 text-xs">
                      <Star className="w-3 h-3 fill-yellow-400 text-yellow-400" />
                      <span>{product.rating}</span>
                    </div>
                  </div>
                </div>
              </button>
            ))}
          </div>
        </div>

        {/* Recent Orders */}
        {orders.length > 0 && (
          <div>
            <div className="flex items-center justify-between mb-3">
              <h3 className="text-gray-800">Recent Orders</h3>
              <Button variant="ghost" size="sm" onClick={() => setActiveTab('orders')}>
                View All
              </Button>
            </div>
            <div className="space-y-3">
              {orders.slice(0, 2).map((order) => (
                <button
                  key={order.id}
                  onClick={() => {
                    setSelectedOrder(order);
                    setView('orderDetail');
                  }}
                  className="w-full bg-white rounded-2xl p-4 shadow-md hover:shadow-lg transition-shadow text-left"
                >
                  <div className="flex items-center justify-between mb-2">
                    <p className="text-sm">Order {order.id}</p>
                    <Badge className={
                      order.status === 'delivered' ? 'bg-green-500' :
                      order.status === 'shipped' ? 'bg-blue-500' : 'bg-orange-500'
                    }>
                      {order.status}
                    </Badge>
                  </div>
                  <p className="text-xs text-gray-500 mb-2">{order.supplier}</p>
                  <div className="flex items-center justify-between">
                    <span className="text-sm text-gray-600">{order.date}</span>
                    <span className="text-green-600">PKR {order.total.toLocaleString()}</span>
                  </div>
                </button>
              ))}
            </div>
          </div>
        )}
      </div>
    </AgriBackground>
  );

  // Browse Products View
  const renderBrowse = () => (
    <AgriBackground variant="vegetable" opacity={8}>
      <div className="bg-white sticky top-0 z-10 border-b">
        <div className="p-4">
          <h2 className="mb-3">Browse Marketplace</h2>
          {/* Search */}
          <div className="relative mb-3">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
            <Input
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search crops, seeds, fertilizers..."
              className="pl-10 rounded-xl"
            />
          </div>

          {/* Categories */}
          <div className="flex gap-2 overflow-x-auto pb-2 -mx-4 px-4">
            {categories.map((cat) => (
              <button
                key={cat.id}
                onClick={() => setSelectedCategory(cat.id)}
                className={`flex items-center gap-2 px-4 py-2 rounded-full whitespace-nowrap transition-colors ${
                  selectedCategory === cat.id
                    ? 'bg-[#1E7F43] text-white'
                    : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
                }`}
              >
                <span>{cat.icon}</span>
                <span className="text-sm">{cat.name}</span>
              </button>
            ))}
          </div>
        </div>
      </div>

      <div className="p-4 grid grid-cols-2 gap-3 pb-20">
        {filteredProducts.map((product) => (
          <button
            key={product.id}
            onClick={() => {
              setSelectedProduct(product);
              setView('productDetail');
            }}
            className="bg-white rounded-2xl overflow-hidden shadow-md hover:shadow-lg transition-shadow text-left"
          >
            <div className="aspect-square bg-gray-100 relative">
              <img src={product.image} alt={product.name} className="w-full h-full object-cover" />
              {product.supplier.verified && (
                <Badge className="absolute top-2 right-2 bg-blue-500 text-xs">✓</Badge>
              )}
            </div>
            <div className="p-3">
              <h4 className="text-sm mb-1 line-clamp-1">{product.name}</h4>
              <p className="text-xs text-gray-500 mb-1">{product.supplier.name}</p>
              <div className="flex items-center gap-1 text-xs text-gray-500 mb-2">
                <MapPin className="w-3 h-3" />
                <span className="truncate">{product.supplier.location}</span>
              </div>
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-green-600">PKR {product.price}</p>
                  <p className="text-xs text-gray-500">{product.unit}</p>
                </div>
                <div className="flex items-center gap-1 text-xs">
                  <Star className="w-3 h-3 fill-yellow-400 text-yellow-400" />
                  <span>{product.rating}</span>
                </div>
              </div>
            </div>
          </button>
        ))}
      </div>

      {/* Cart FAB */}
      {cart.length > 0 && (
        <button
          onClick={() => setActiveTab('cart')}
          className="fixed bottom-24 right-6 bg-[#1E7F43] text-white rounded-full p-4 shadow-2xl hover:bg-[#15593A] z-50 flex items-center gap-2"
        >
          <ShoppingCart className="w-6 h-6" />
          <Badge className="bg-white text-[#1E7F43]">{cart.length}</Badge>
        </button>
      )}
    </AgriBackground>
  );

  // Product Detail View
  const renderProductDetail = () => {
    if (!selectedProduct) return null;

    return (
      <AgriBackground variant="soil" opacity={5}>
        <div className="bg-white sticky top-0 z-10 border-b">
          <button
            onClick={() => setView('browse')}
            className="flex items-center gap-2 text-[#1E7F43] p-4 hover:bg-green-50 transition-colors"
          >
            <div className="bg-green-50 rounded-full p-1">
              <ArrowLeft className="w-5 h-5" />
            </div>
            <span>Back</span>
          </button>
        </div>

        <div className="bg-white">
          <div className="aspect-square bg-gray-100">
            <img src={selectedProduct.image} alt={selectedProduct.name} className="w-full h-full object-cover" />
          </div>
        </div>

        <div className="p-4 space-y-4 pb-32">
          {/* Product Info */}
          <div className="bg-white rounded-2xl p-4 shadow-md">
            <h2 className="mb-2">{selectedProduct.name}</h2>
            <p className="text-sm text-gray-600 mb-3">{selectedProduct.description}</p>

            <div className="bg-gradient-to-r from-green-50 to-green-100 rounded-xl p-4 mb-3">
              <p className="text-2xl text-green-600 mb-1">PKR {selectedProduct.price.toLocaleString()}</p>
              <p className="text-sm text-gray-600">{selectedProduct.unit}</p>
            </div>

            <div className="flex items-center justify-between text-sm mb-3">
              <span className="text-gray-600">Available</span>
              <span className="text-gray-800">{selectedProduct.available} {selectedProduct.unit.split(' ')[1]}</span>
            </div>

            <div className="flex items-center gap-1">
              <Star className="w-5 h-5 fill-yellow-400 text-yellow-400" />
              <span className="text-lg">{selectedProduct.rating}</span>
              <span className="text-sm text-gray-500 ml-1">(48 reviews)</span>
            </div>
          </div>

          {/* Supplier Info */}
          <div className="bg-white rounded-2xl p-4 shadow-md">
            <h4 className="mb-3">Supplier Information</h4>
            <div className="flex items-center gap-3 mb-3">
              <div className="w-12 h-12 bg-gradient-to-br from-[#1E7F43] to-[#15593A] rounded-full flex items-center justify-center text-white text-xl">
                {selectedProduct.supplier.name.charAt(0)}
              </div>
              <div className="flex-1">
                <div className="flex items-center gap-2 mb-1">
                  <p>{selectedProduct.supplier.name}</p>
                  {selectedProduct.supplier.verified && (
                    <Badge className="bg-blue-500 text-xs">✓ Verified</Badge>
                  )}
                </div>
                <div className="flex items-center gap-1 text-sm text-gray-500">
                  <MapPin className="w-3 h-3" />
                  <span>{selectedProduct.supplier.location}</span>
                </div>
              </div>
              <div className="text-right">
                <div className="flex items-center gap-1">
                  <Star className="w-4 h-4 fill-yellow-400 text-yellow-400" />
                  <span className="text-sm">{selectedProduct.supplier.rating}</span>
                </div>
              </div>
            </div>

            <Button variant="outline" className="w-full rounded-xl border-[#1E7F43] text-[#1E7F43]">
              <Phone className="w-4 h-4 mr-2" />
              Contact Supplier
            </Button>
          </div>
        </div>

        {/* Fixed Bottom Actions */}
        <div className="fixed bottom-0 left-0 right-0 bg-white border-t p-4 shadow-lg">
          <div className="flex gap-3 max-w-md mx-auto">
            <Button
              variant="outline"
              onClick={() => {
                addToCart(selectedProduct);
                // Show notification
              }}
              className="flex-1 rounded-xl border-[#1E7F43] text-[#1E7F43]"
            >
              Add to Cart
            </Button>
            <Button
              onClick={() => {
                addToCart(selectedProduct);
                setActiveTab('cart');
              }}
              className="flex-1 rounded-xl bg-[#1E7F43] hover:bg-[#15593A]"
            >
              Buy Now
            </Button>
          </div>
        </div>
      </AgriBackground>
    );
  };

  // Cart View
  const renderCart = () => (
    <AgriBackground variant="crops" opacity={8}>
      <AgriHero 
        title="Shopping Cart"
        subtitle={`${cart.length} items`}
        icon={<ShoppingCart className="w-8 h-8" />}
        variant="wheat"
      />

      <div className="p-4 space-y-3 pb-32">
        {cart.length === 0 ? (
          <div className="bg-white rounded-2xl p-8 shadow-md text-center">
            <ShoppingCart className="w-16 h-16 text-gray-300 mx-auto mb-4" />
            <p className="text-gray-500 mb-4">Your cart is empty</p>
            <Button onClick={() => setActiveTab('browse')} className="bg-[#1E7F43]">
              Start Shopping
            </Button>
          </div>
        ) : (
          <>
            {cart.map((item) => (
              <div key={item.id} className="bg-white rounded-2xl p-4 shadow-md">
                <div className="flex gap-3">
                  <img src={item.image} alt={item.name} className="w-20 h-20 object-cover rounded-xl" />
                  <div className="flex-1">
                    <h4 className="text-sm mb-1">{item.name}</h4>
                    <p className="text-xs text-gray-500 mb-2">{item.supplier.name}</p>
                    <p className="text-green-600 mb-2">PKR {item.price.toLocaleString()} <span className="text-xs text-gray-500">{item.unit}</span></p>
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-2 bg-gray-100 rounded-lg px-2 py-1">
                        <button className="text-gray-600 hover:text-gray-800">-</button>
                        <span className="px-2 text-sm">{item.quantity}</span>
                        <button className="text-gray-600 hover:text-gray-800">+</button>
                      </div>
                      <p className="text-sm">
                        Total: <span className="text-green-600">PKR {(item.price * item.quantity).toLocaleString()}</span>
                      </p>
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </>
        )}
      </div>

      {/* Fixed Bottom Summary */}
      {cart.length > 0 && (
        <div className="fixed bottom-0 left-0 right-0 bg-white border-t p-4 shadow-lg">
          <div className="max-w-md mx-auto space-y-3">
            <div className="flex items-center justify-between">
              <span className="text-gray-600">Subtotal</span>
              <span className="text-xl text-green-600">PKR {cartTotal.toLocaleString()}</span>
            </div>
            <Button
              onClick={() => setView('checkout')}
              className="w-full rounded-xl bg-[#1E7F43] hover:bg-[#15593A]"
            >
              Proceed to Checkout
            </Button>
          </div>
        </div>
      )}
    </AgriBackground>
  );

  // Checkout View
  const renderCheckout = () => (
    <AgriBackground variant="soil" opacity={5}>
      <div className="bg-white border-b sticky top-0 z-10">
        <button
          onClick={() => setActiveTab('cart')}
          className="flex items-center gap-2 text-[#1E7F43] p-4 hover:bg-green-50 transition-colors"
        >
          <div className="bg-green-50 rounded-full p-1">
            <ArrowLeft className="w-5 h-5" />
          </div>
          <span>Back</span>
        </button>
        <div className="px-4 pb-4">
          <h2>Checkout</h2>
        </div>
      </div>

      <div className="p-4 space-y-4 pb-32">
        {/* Delivery Address */}
        <div className="bg-white rounded-2xl p-4 shadow-md">
          <h4 className="mb-3">Delivery Address</h4>
          <div className="p-3 bg-green-50 rounded-xl border border-green-200">
            <p className="text-sm mb-2">Warehouse 5, Industrial Area, Faisalabad</p>
            <button className="text-[#1E7F43] text-sm hover:underline">Change Address</button>
          </div>
        </div>

        {/* Order Summary */}
        <div className="bg-white rounded-2xl p-4 shadow-md">
          <h4 className="mb-3">Order Summary</h4>
          <div className="space-y-2 mb-3">
            {cart.map((item) => (
              <div key={item.id} className="flex items-center justify-between text-sm">
                <span className="text-gray-600">{item.name} x{item.quantity}</span>
                <span>PKR {(item.price * item.quantity).toLocaleString()}</span>
              </div>
            ))}
          </div>
          <div className="border-t pt-2 flex items-center justify-between">
            <span>Total</span>
            <span className="text-xl text-green-600">PKR {cartTotal.toLocaleString()}</span>
          </div>
        </div>

        {/* Payment Method */}
        <div className="bg-white rounded-2xl p-4 shadow-md">
          <h4 className="mb-3">Payment Method</h4>
          <div className="space-y-2">
            <div className="flex items-center gap-3 p-3 bg-green-50 rounded-xl border-2 border-green-500">
              <input type="radio" name="payment" defaultChecked className="accent-green-600" />
              <div className="flex-1">
                <p className="text-sm mb-0.5">Cash on Delivery</p>
                <p className="text-xs text-gray-600">Pay when you receive</p>
              </div>
              <Badge className="bg-green-600">Available</Badge>
            </div>
            <div className="flex items-center gap-3 p-3 bg-gray-50 rounded-xl border-2 border-gray-200 opacity-60">
              <input type="radio" name="payment" disabled className="accent-green-600" />
              <div className="flex-1">
                <p className="text-sm mb-0.5">Bank Transfer</p>
                <p className="text-xs text-gray-600">Direct payment</p>
              </div>
              <Badge variant="outline">Coming Soon</Badge>
            </div>
          </div>
        </div>
      </div>

      {/* Fixed Bottom Action */}
      <div className="fixed bottom-0 left-0 right-0 bg-white border-t p-4 shadow-lg">
        <Button
          onClick={() => {
            setCart([]);
            setActiveTab('orders');
          }}
          className="w-full max-w-md mx-auto rounded-xl bg-[#1E7F43] hover:bg-[#15593A]"
        >
          Place Order • PKR {cartTotal.toLocaleString()}
        </Button>
      </div>
    </AgriBackground>
  );

  // Orders View
  const renderOrders = () => (
    <AgriBackground variant="irrigation" opacity={8}>
      <AgriHero 
        title="My Orders"
        subtitle={`${orders.length} total orders`}
        icon={<Package className="w-8 h-8" />}
        variant="crops"
      />

      <div className="p-4 space-y-3">
        {orders.map((order) => (
          <button
            key={order.id}
            onClick={() => {
              setSelectedOrder(order);
              setView('orderDetail');
            }}
            className="w-full bg-white rounded-2xl p-4 shadow-md hover:shadow-lg transition-shadow text-left"
          >
            <div className="flex items-center justify-between mb-3">
              <div>
                <p className="text-sm">Order {order.id}</p>
                <p className="text-xs text-gray-500">{order.date}</p>
              </div>
              <Badge className={
                order.status === 'delivered' ? 'bg-green-500' :
                order.status === 'shipped' ? 'bg-blue-500' : 'bg-orange-500'
              }>
                {order.status}
              </Badge>
            </div>

            <p className="text-sm text-gray-600 mb-2">{order.supplier}</p>

            <div className="space-y-1 mb-3">
              {order.items.map((item, idx) => (
                <p key={idx} className="text-sm text-gray-600">
                  {item.name} x{item.quantity}
                </p>
              ))}
            </div>

            <div className="flex items-center justify-between pt-3 border-t">
              <span className="text-sm text-gray-600">Total</span>
              <span className="text-green-600">PKR {order.total.toLocaleString()}</span>
            </div>
          </button>
        ))}
      </div>
    </AgriBackground>
  );

  // Order Detail View
  const renderOrderDetail = () => {
    if (!selectedOrder) return null;

    return (
      <AgriBackground variant="soil" opacity={5}>
        <div className="bg-white border-b sticky top-0 z-10">
          <button
            onClick={() => setView('orders')}
            className="flex items-center gap-2 text-[#1E7F43] p-4 hover:bg-green-50 transition-colors"
          >
            <div className="bg-green-50 rounded-full p-1">
              <ArrowLeft className="w-5 h-5" />
            </div>
            <span>Back</span>
          </button>
          <div className="px-4 pb-4">
            <h2>Order {selectedOrder.id}</h2>
            <p className="text-sm text-gray-500">{selectedOrder.date}</p>
          </div>
        </div>

        <div className="p-4 space-y-4">
          {/* Status Timeline */}
          <div className="bg-white rounded-2xl p-4 shadow-md">
            <h4 className="mb-4">Order Status</h4>
            <div className="space-y-3">
              {['ordered', 'confirmed', 'shipped', 'delivered'].map((status, idx) => {
                const currentIdx = ['ordered', 'confirmed', 'shipped', 'delivered'].indexOf(selectedOrder.status);
                const isCompleted = idx <= currentIdx;
                
                return (
                  <div key={status} className="flex items-center gap-3">
                    <div className={`w-8 h-8 rounded-full flex items-center justify-center ${
                      isCompleted ? 'bg-green-500 text-white' : 'bg-gray-200 text-gray-400'
                    }`}>
                      {isCompleted ? <Check className="w-5 h-5" /> : <div className="w-2 h-2 bg-gray-400 rounded-full" />}
                    </div>
                    <div className="flex-1">
                      <p className="text-sm capitalize">{status}</p>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

          {/* Items */}
          <div className="bg-white rounded-2xl p-4 shadow-md">
            <h4 className="mb-3">Order Items</h4>
            <div className="space-y-3">
              {selectedOrder.items.map((item, idx) => (
                <div key={idx} className="flex gap-3">
                  <img src={item.image} alt={item.name} className="w-16 h-16 object-cover rounded-xl" />
                  <div className="flex-1">
                    <p className="text-sm mb-1">{item.name}</p>
                    <p className="text-xs text-gray-500">Qty: {item.quantity}</p>
                    <p className="text-green-600 text-sm">PKR {(item.price * item.quantity).toLocaleString()}</p>
                  </div>
                </div>
              ))}
            </div>

            <div className="border-t mt-3 pt-3 flex items-center justify-between">
              <span>Total Amount</span>
              <span className="text-xl text-green-600">PKR {selectedOrder.total.toLocaleString()}</span>
            </div>
          </div>

          {/* Supplier Contact */}
          <div className="bg-white rounded-2xl p-4 shadow-md">
            <h4 className="mb-3">Supplier</h4>
            <p className="text-sm mb-3">{selectedOrder.supplier}</p>
            <Button variant="outline" className="w-full rounded-xl border-[#1E7F43] text-[#1E7F43]">
              <Phone className="w-4 h-4 mr-2" />
              Contact Supplier
            </Button>
          </div>

          {/* Actions */}
          {selectedOrder.status === 'delivered' && (
            <Button className="w-full rounded-xl bg-[#1E7F43] hover:bg-[#15593A]">
              Reorder
            </Button>
          )}
        </div>
      </AgriBackground>
    );
  };

  // Profile View
  const renderProfile = () => (
    <AgriBackground variant="sunrise" opacity={8}>
      <AgriHero 
        title="Buyer Profile"
        subtitle="Manage your account"
        icon={<User className="w-8 h-8" />}
        variant="wheat"
      />

      <div className="p-4 space-y-4">
        {/* Profile Card */}
        <div className="bg-white rounded-2xl p-6 shadow-md text-center">
          <div className="w-24 h-24 bg-gradient-to-br from-[#1E7F43] to-[#15593A] rounded-full flex items-center justify-center text-white text-3xl mx-auto mb-4">
            BT
          </div>
          <h3 className="mb-1">Buyer Trading Co.</h3>
          <p className="text-sm text-gray-500">Wholesale Buyer</p>
        </div>

        {/* Account Info */}
        <div className="bg-white rounded-2xl p-4 shadow-md space-y-3">
          <h4 className="mb-3">Account Information</h4>
          <div>
            <label className="block text-sm text-gray-500 mb-1">Business Name</label>
            <Input defaultValue="Buyer Trading Co." className="rounded-xl" />
          </div>
          <div>
            <label className="block text-sm text-gray-500 mb-1">Location</label>
            <Input defaultValue="Faisalabad, Punjab" className="rounded-xl" />
          </div>
          <div>
            <label className="block text-sm text-gray-500 mb-1">Contact</label>
            <Input defaultValue="+92 301 9876543" className="rounded-xl" />
          </div>
        </div>

        {/* Saved Suppliers */}
        <div className="bg-white rounded-2xl p-4 shadow-md">
          <h4 className="mb-3">Saved Suppliers ({stats.savedSuppliers})</h4>
          <p className="text-sm text-gray-500">Quick access to your trusted suppliers</p>
        </div>

        {/* Actions */}
        <div className="space-y-2">
          <Button
            variant="outline"
            className="w-full rounded-xl border-red-500 text-red-500"
            onClick={onLogout}
          >
            Logout
          </Button>
        </div>
      </div>
    </AgriBackground>
  );

  // Render based on view
  const renderContent = () => {
    if (view === 'productDetail') return renderProductDetail();
    if (view === 'checkout') return renderCheckout();
    if (view === 'orderDetail') return renderOrderDetail();
    
    if (activeTab === 'home') return renderHome();
    if (activeTab === 'browse') return renderBrowse();
    if (activeTab === 'cart') return renderCart();
    if (activeTab === 'orders') return renderOrders();
    if (activeTab === 'profile') return renderProfile();
    
    return renderHome();
  };

  return (
    <div className="min-h-screen bg-gray-50 pb-20">
      {renderContent()}

      {/* Bottom Navigation */}
      <div className="fixed bottom-0 left-0 right-0 bg-white border-t border-gray-200 shadow-lg">
        <div className="flex justify-around items-center h-20 max-w-md mx-auto">
          {tabs.map((tab) => {
            const Icon = tab.icon;
            const isActive = activeTab === tab.id;
            return (
              <button
                key={tab.id}
                onClick={() => {
                  setActiveTab(tab.id as any);
                  setView('home');
                }}
                className={`flex flex-col items-center justify-center gap-1 px-4 py-2 transition-colors relative ${
                  isActive ? 'text-[#1E7F43]' : 'text-gray-500'
                }`}
              >
                <Icon className={`w-6 h-6 ${isActive ? 'fill-[#1E7F43]/10' : ''}`} />
                <span className="text-xs">{tab.label}</span>
                {tab.id === 'cart' && cart.length > 0 && (
                  <div className="absolute top-1 right-2 w-4 h-4 bg-red-500 rounded-full flex items-center justify-center text-white text-xs">
                    {cart.length}
                  </div>
                )}
              </button>
            );
          })}
        </div>
      </div>
    </div>
  );
}
