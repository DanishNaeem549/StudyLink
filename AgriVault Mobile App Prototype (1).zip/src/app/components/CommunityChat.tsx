import { useState, useRef } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Send, 
  Mic, 
  Image as ImageIcon, 
  Camera,
  MoreVertical,
  Check,
  CheckCheck,
  Flag,
  Copy,
  Trash2,
  Reply,
  Users,
  AlertCircle,
  Shield,
  UserX
} from 'lucide-react';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Badge } from './ui/badge';
import { useLanguage } from '../contexts/LanguageContext';
import VoiceRecorder, { VoiceMessage, TTSPlayer } from './ui/VoiceRecorder';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from './ui/dropdown-menu';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from './ui/alert-dialog';

interface CommunityMessage {
  id: string;
  senderId: string;
  senderName: string;
  senderRole: 'Farmer' | 'Expert';
  senderAvatar: string;
  text: string;
  timestamp: Date;
  type: 'text' | 'voice' | 'image';
  voiceUrl?: string;
  imageUrl?: string;
  voiceDuration?: number;
  isRead: boolean;
  isDelivered: boolean;
  replyTo?: {
    id: string;
    senderName: string;
    text: string;
  };
}

interface CommunityGroup {
  id: string;
  name: string;
  type: 'location' | 'crop';
  memberCount: number;
  description: string;
}

const MOCK_GROUPS: CommunityGroup[] = [
  { id: '1', name: 'Punjab Wheat Farmers', type: 'crop', memberCount: 248, description: 'Share experiences about wheat cultivation' },
  { id: '2', name: 'Multan District Growers', type: 'location', memberCount: 156, description: 'Local farming community' },
  { id: '3', name: 'Cotton Experts Network', type: 'crop', memberCount: 312, description: 'Cotton farming tips and advice' },
];

const MOCK_MESSAGES: CommunityMessage[] = [
  {
    id: '1',
    senderId: '101',
    senderName: 'Ahmed Khan',
    senderRole: 'Farmer',
    senderAvatar: 'AK',
    text: 'السلام علیکم! Wheat prices going up this week. Good time to sell?',
    timestamp: new Date(Date.now() - 3600000),
    type: 'text',
    isRead: true,
    isDelivered: true,
  },
  {
    id: '2',
    senderId: '102',
    senderName: 'Dr. Fatima Ali',
    senderRole: 'Expert',
    senderAvatar: 'FA',
    text: 'Yes, market analysis shows 3-5% increase expected. But check moisture levels before selling.',
    timestamp: new Date(Date.now() - 3500000),
    type: 'text',
    isRead: true,
    isDelivered: true,
  },
  {
    id: '3',
    senderId: '103',
    senderName: 'Hassan Raza',
    senderRole: 'Farmer',
    senderAvatar: 'HR',
    text: 'I saw some rust on my wheat crop. Anyone else facing this?',
    timestamp: new Date(Date.now() - 1800000),
    type: 'text',
    isRead: true,
    isDelivered: true,
  },
  {
    id: '4',
    senderId: '104',
    senderName: 'Zahid Iqbal',
    senderRole: 'Farmer',
    senderAvatar: 'ZI',
    text: 'Same here brother. Used fungicide spray yesterday.',
    timestamp: new Date(Date.now() - 900000),
    type: 'voice',
    voiceUrl: '#',
    voiceDuration: 12,
    isRead: false,
    isDelivered: true,
  },
];

export default function CommunityChat() {
  const [messages, setMessages] = useState<CommunityMessage[]>(MOCK_MESSAGES);
  const [input, setInput] = useState('');
  const [selectedGroup, setSelectedGroup] = useState<CommunityGroup>(MOCK_GROUPS[0]);
  const [showGroupList, setShowGroupList] = useState(false);
  const [replyingTo, setReplyingTo] = useState<CommunityMessage | null>(null);
  const [showRules, setShowRules] = useState(false);
  const [reportingMessage, setReportingMessage] = useState<CommunityMessage | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const { language, t } = useLanguage();

  const currentUserId = '999'; // Mock current user

  const sendMessage = (text: string, type: 'text' | 'voice' | 'image' = 'text', mediaUrl?: string) => {
    if (!text.trim() && type === 'text') return;

    const newMessage: CommunityMessage = {
      id: Date.now().toString(),
      senderId: currentUserId,
      senderName: 'You',
      senderRole: 'Farmer',
      senderAvatar: 'ME',
      text: text || t('voiceMessage', 'Voice message'),
      timestamp: new Date(),
      type,
      voiceUrl: type === 'voice' ? mediaUrl : undefined,
      imageUrl: type === 'image' ? mediaUrl : undefined,
      voiceDuration: type === 'voice' ? 8 : undefined,
      isRead: false,
      isDelivered: true,
      replyTo: replyingTo ? {
        id: replyingTo.id,
        senderName: replyingTo.senderName,
        text: replyingTo.text,
      } : undefined,
    };

    setMessages(prev => [...prev, newMessage]);
    setInput('');
    setReplyingTo(null);

    // Simulate message read after 2 seconds
    setTimeout(() => {
      setMessages(prev => prev.map(msg => 
        msg.id === newMessage.id ? { ...msg, isRead: true } : msg
      ));
    }, 2000);
  };

  const handleVoiceRecording = (voiceMessage: VoiceMessage) => {
    sendMessage(voiceMessage.transcription || t('voiceMessage', 'Voice message'), 'voice', voiceMessage.audioUrl);
  };

  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const imageUrl = URL.createObjectURL(file);
      sendMessage(t('imageMessage', 'Photo'), 'image', imageUrl);
    }
  };

  const copyMessage = (text: string) => {
    navigator.clipboard.writeText(text);
    // Could add toast notification here
  };

  const deleteMessage = (messageId: string) => {
    setMessages(prev => prev.filter(msg => msg.id !== messageId));
  };

  const handleReport = (message: CommunityMessage) => {
    setReportingMessage(message);
  };

  const confirmReport = () => {
    // Handle report submission
    setReportingMessage(null);
    // Could show success toast
  };

  const formatTime = (date: Date) => {
    const now = new Date();
    const diff = now.getTime() - date.getTime();
    const minutes = Math.floor(diff / 60000);
    const hours = Math.floor(diff / 3600000);
    const days = Math.floor(diff / 86400000);

    if (minutes < 1) return t('justNow', 'Just now');
    if (minutes < 60) return `${minutes}${language === 'ur' ? ' منٹ' : 'm'}`;
    if (hours < 24) return `${hours}${language === 'ur' ? ' گھنٹے' : 'h'}`;
    if (days < 7) return `${days}${language === 'ur' ? ' دن' : 'd'}`;
    return date.toLocaleDateString();
  };

  return (
    <div className="flex flex-col h-full">
      {/* Community Rules Dialog */}
      <AlertDialog open={showRules} onOpenChange={setShowRules}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle className="flex items-center gap-2">
              <Shield className="w-5 h-5 text-[#1E7F43]" />
              {t('communityRules', 'Community Rules')}
            </AlertDialogTitle>
            <AlertDialogDescription className="space-y-2 text-left">
              <p>✓ {t('rule1', 'Be respectful and supportive to fellow farmers')}</p>
              <p>✓ {t('rule2', 'Share accurate agricultural information')}</p>
              <p>✓ {t('rule3', 'No spam or promotional content')}</p>
              <p>✓ {t('rule4', 'Protect your personal information')}</p>
              <p>✓ {t('rule5', 'Report inappropriate content')}</p>
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogAction onClick={() => setShowRules(false)}>
              {t('understood', 'Understood')}
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      {/* Report Message Dialog */}
      <AlertDialog open={!!reportingMessage} onOpenChange={() => setReportingMessage(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle className="flex items-center gap-2">
              <Flag className="w-5 h-5 text-red-500" />
              {t('reportMessage', 'Report Message')}
            </AlertDialogTitle>
            <AlertDialogDescription>
              {t('reportConfirm', 'Are you sure you want to report this message? Our team will review it.')}
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>{t('cancel', 'Cancel')}</AlertDialogCancel>
            <AlertDialogAction 
              onClick={confirmReport}
              className="bg-red-500 hover:bg-red-600"
            >
              {t('report', 'Report')}
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      {/* Group Header */}
      <div className="bg-white border-b border-gray-200 p-3">
        <button 
          onClick={() => setShowGroupList(!showGroupList)}
          className="w-full flex items-center justify-between hover:bg-gray-50 rounded-lg p-2 transition"
        >
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-gradient-to-br from-[#1E7F43] to-[#15593A] rounded-full flex items-center justify-center">
              <Users className="w-5 h-5 text-white" />
            </div>
            <div className="text-left">
              <h3 className="font-semibold text-sm">{selectedGroup.name}</h3>
              <p className="text-xs text-gray-500">
                {selectedGroup.memberCount} {t('members', 'members')}
              </p>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <Button
              variant="ghost"
              size="sm"
              onClick={(e) => {
                e.stopPropagation();
                setShowRules(true);
              }}
              className="text-xs"
            >
              <AlertCircle className="w-4 h-4 mr-1" />
              {t('rules', 'Rules')}
            </Button>
          </div>
        </button>

        {/* Group List Dropdown */}
        {showGroupList && (
          <motion.div
            initial={{ opacity: 0, y: -10 }}
            animate={{ opacity: 1, y: 0 }}
            className="mt-2 bg-gray-50 rounded-lg p-2 space-y-1"
          >
            {MOCK_GROUPS.map(group => (
              <button
                key={group.id}
                onClick={() => {
                  setSelectedGroup(group);
                  setShowGroupList(false);
                }}
                className={`w-full text-left p-2 rounded hover:bg-white transition ${
                  selectedGroup.id === group.id ? 'bg-white shadow-sm' : ''
                }`}
              >
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm font-medium">{group.name}</p>
                    <p className="text-xs text-gray-500">{group.description}</p>
                  </div>
                  <Badge variant="outline" className="text-xs">
                    {group.memberCount}
                  </Badge>
                </div>
              </button>
            ))}
          </motion.div>
        )}
      </div>

      {/* Messages Area */}
      <div className="flex-1 overflow-y-auto p-4 space-y-3">
        {messages.map((message) => {
          const isCurrentUser = message.senderId === currentUserId;
          
          return (
            <div
              key={message.id}
              className={`flex ${isCurrentUser ? 'justify-end' : 'justify-start'} group`}
            >
              {/* Avatar for other users */}
              {!isCurrentUser && (
                <div className="w-8 h-8 rounded-full bg-gradient-to-br from-[#1E7F43] to-[#15593A] flex items-center justify-center text-white text-xs font-semibold mr-2 mt-auto mb-1">
                  {message.senderAvatar}
                </div>
              )}

              {/* Message Bubble */}
              <div className={`max-w-[75%] ${isCurrentUser ? 'items-end' : 'items-start'} flex flex-col gap-1`}>
                {/* Sender Info for other users */}
                {!isCurrentUser && (
                  <div className="flex items-center gap-2 px-2">
                    <span className="text-xs font-semibold text-gray-700">
                      {message.senderName}
                    </span>
                    <Badge 
                      variant={message.senderRole === 'Expert' ? 'default' : 'outline'}
                      className="text-xs h-4 px-1"
                    >
                      {message.senderRole === 'Expert' ? '🌾 Expert' : '👨‍🌾 Farmer'}
                    </Badge>
                  </div>
                )}

                {/* Reply Preview */}
                {message.replyTo && (
                  <div className="bg-gray-100 border-l-4 border-[#1E7F43] rounded px-2 py-1 mb-1">
                    <p className="text-xs font-medium text-gray-600">{message.replyTo.senderName}</p>
                    <p className="text-xs text-gray-500 truncate">{message.replyTo.text}</p>
                  </div>
                )}

                {/* Message Content */}
                <div 
                  className={`relative rounded-lg px-3 py-2 shadow-sm ${
                    isCurrentUser 
                      ? 'bg-[#DCF8C6] text-gray-800' 
                      : 'bg-white text-gray-800 border border-gray-200'
                  }`}
                >
                  {/* Message Actions (appears on hover) */}
                  <div className={`absolute ${isCurrentUser ? '-left-8' : '-right-8'} top-1 opacity-0 group-hover:opacity-100 transition`}>
                    <DropdownMenu>
                      <DropdownMenuTrigger asChild>
                        <Button variant="ghost" size="icon" className="h-6 w-6">
                          <MoreVertical className="w-4 h-4" />
                        </Button>
                      </DropdownMenuTrigger>
                      <DropdownMenuContent align={isCurrentUser ? 'end' : 'start'}>
                        <DropdownMenuItem onClick={() => setReplyingTo(message)}>
                          <Reply className="w-4 h-4 mr-2" />
                          {t('reply', 'Reply')}
                        </DropdownMenuItem>
                        <DropdownMenuItem onClick={() => copyMessage(message.text)}>
                          <Copy className="w-4 h-4 mr-2" />
                          {t('copy', 'Copy')}
                        </DropdownMenuItem>
                        {isCurrentUser ? (
                          <DropdownMenuItem 
                            onClick={() => deleteMessage(message.id)}
                            className="text-red-600"
                          >
                            <Trash2 className="w-4 h-4 mr-2" />
                            {t('delete', 'Delete')}
                          </DropdownMenuItem>
                        ) : (
                          <>
                            <DropdownMenuItem 
                              onClick={() => handleReport(message)}
                              className="text-red-600"
                            >
                              <Flag className="w-4 h-4 mr-2" />
                              {t('report', 'Report')}
                            </DropdownMenuItem>
                            <DropdownMenuItem className="text-red-600">
                              <UserX className="w-4 h-4 mr-2" />
                              {t('block', 'Block User')}
                            </DropdownMenuItem>
                          </>
                        )}
                      </DropdownMenuContent>
                    </DropdownMenu>
                  </div>

                  {/* Text Message */}
                  {message.type === 'text' && (
                    <p className="text-sm break-words whitespace-pre-wrap">
                      {message.text}
                    </p>
                  )}

                  {/* Voice Message */}
                  {message.type === 'voice' && (
                    <div className="flex items-center gap-2 min-w-[180px]">
                      <Mic className="w-4 h-4 text-[#1E7F43]" />
                      <div className="flex-1 h-1 bg-gray-300 rounded-full overflow-hidden">
                        <div className="h-full bg-[#1E7F43] w-1/3" />
                      </div>
                      <span className="text-xs text-gray-500">0:{message.voiceDuration}s</span>
                      <TTSPlayer text={message.text} language={language} compact />
                    </div>
                  )}

                  {/* Image Message */}
                  {message.type === 'image' && message.imageUrl && (
                    <div className="space-y-1">
                      <img 
                        src={message.imageUrl} 
                        alt="Shared" 
                        className="rounded-lg max-w-full h-auto"
                      />
                      {message.text !== 'Photo' && (
                        <p className="text-sm">{message.text}</p>
                      )}
                    </div>
                  )}

                  {/* Timestamp and Status */}
                  <div className={`flex items-center gap-1 mt-1 ${isCurrentUser ? 'justify-end' : 'justify-start'}`}>
                    <span className="text-xs text-gray-500">
                      {formatTime(message.timestamp)}
                    </span>
                    {isCurrentUser && (
                      <span>
                        {message.isRead ? (
                          <CheckCheck className="w-3 h-3 text-blue-500" />
                        ) : message.isDelivered ? (
                          <CheckCheck className="w-3 h-3 text-gray-400" />
                        ) : (
                          <Check className="w-3 h-3 text-gray-400" />
                        )}
                      </span>
                    )}
                  </div>
                </div>
              </div>
            </div>
          );
        })}
      </div>

      {/* Reply Preview Bar */}
      {replyingTo && (
        <div className="bg-gray-100 border-t border-gray-200 p-2 flex items-center justify-between">
          <div className="flex-1">
            <div className="flex items-center gap-2">
              <Reply className="w-4 h-4 text-[#1E7F43]" />
              <div>
                <p className="text-xs font-medium text-gray-700">
                  {t('replyingTo', 'Replying to')} {replyingTo.senderName}
                </p>
                <p className="text-xs text-gray-500 truncate">{replyingTo.text}</p>
              </div>
            </div>
          </div>
          <Button 
            variant="ghost" 
            size="icon" 
            onClick={() => setReplyingTo(null)}
            className="h-6 w-6"
          >
            <X className="w-4 h-4" />
          </Button>
        </div>
      )}

      {/* Input Area */}
      <div className="bg-white border-t border-gray-200 p-3">
        <div className="flex items-center gap-2">
          {/* Media Buttons */}
          <div className="flex gap-1">
            <input
              type="file"
              ref={fileInputRef}
              onChange={handleImageUpload}
              accept="image/*"
              className="hidden"
            />
            <Button
              variant="ghost"
              size="icon"
              onClick={() => fileInputRef.current?.click()}
              className="h-9 w-9 text-gray-600 hover:text-[#1E7F43]"
            >
              <ImageIcon className="w-5 h-5" />
            </Button>
            <Button
              variant="ghost"
              size="icon"
              onClick={() => fileInputRef.current?.click()}
              className="h-9 w-9 text-gray-600 hover:text-[#1E7F43]"
            >
              <Camera className="w-5 h-5" />
            </Button>
          </div>

          {/* Text Input */}
          <Input
            value={input}
            onChange={(e) => setInput(e.target.value)}
            onKeyPress={(e) => e.key === 'Enter' && sendMessage(input)}
            placeholder={t('typeMessage', 'Type a message...')}
            className="flex-1 rounded-full"
            dir={language === 'ur' ? 'rtl' : 'ltr'}
          />

          {/* Voice Recorder */}
          <VoiceRecorder
            onRecordingComplete={handleVoiceRecording}
            language={language}
          />

          {/* Send Button */}
          <Button
            onClick={() => sendMessage(input)}
            disabled={!input.trim()}
            className="bg-[#1E7F43] hover:bg-[#15593A] rounded-full h-9 w-9 p-0"
            size="icon"
          >
            <Send className="w-4 h-4" />
          </Button>
        </div>
        
        {/* Online Status */}
        <div className="mt-2 flex items-center justify-center gap-2">
          <div className="flex items-center gap-1">
            <div className="w-2 h-2 bg-green-500 rounded-full animate-pulse" />
            <span className="text-xs text-gray-500">
              {t('activeMembers', '45 members active')}
            </span>
          </div>
        </div>
      </div>
    </div>
  );
}
