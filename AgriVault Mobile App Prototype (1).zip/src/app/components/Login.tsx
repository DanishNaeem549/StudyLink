import { useState } from 'react';
import { UserRole } from '../App';
import { ArrowLeft, Phone, Lock } from 'lucide-react';
import { Button } from './ui/button';
import { Input } from './ui/input';

interface LoginProps {
  role: UserRole;
  onLogin: () => void;
}

export default function Login({ role, onLogin }: LoginProps) {
  const [isSignup, setIsSignup] = useState(false);
  const [phone, setPhone] = useState('');
  const [password, setPassword] = useState('');

  const roleNames = {
    farmer: 'Farmer',
    transporter: 'Transport Provider',
    storage: 'Cold Storage Owner',
    expert: 'Agriculture Expert',
    admin: 'Admin'
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onLogin();
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-50 to-gray-100 p-6 flex flex-col">
      <div className="mb-8 mt-4">
        <Button variant="ghost" size="sm" className="text-gray-600" onClick={() => window.location.reload()}>
          <ArrowLeft className="w-4 h-4 mr-2" />
          Back
        </Button>
      </div>

      <div className="flex-1 flex flex-col justify-center max-w-md mx-auto w-full">
        <div className="bg-white rounded-3xl shadow-xl p-8">
          <div className="text-center mb-8">
            <div className="inline-block bg-[#1E7F43] text-white px-4 py-2 rounded-full text-sm mb-4">
              {roleNames[role as keyof typeof roleNames]}
            </div>
            <h2 className="text-2xl mb-2">{isSignup ? 'Create Account' : 'Welcome Back'}</h2>
            <p className="text-gray-600 text-sm">
              {isSignup ? 'Sign up to get started' : 'Login to continue'}
            </p>
          </div>

          <form onSubmit={handleSubmit} className="space-y-4">
            <div>
              <label className="block text-gray-700 mb-2 text-sm">Phone Number</label>
              <div className="relative">
                <Phone className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
                <Input
                  type="tel"
                  placeholder="03XX XXXXXXX"
                  value={phone}
                  onChange={(e) => setPhone(e.target.value)}
                  className="pl-10 h-12 rounded-xl"
                />
              </div>
            </div>

            <div>
              <label className="block text-gray-700 mb-2 text-sm">Password</label>
              <div className="relative">
                <Lock className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
                <Input
                  type="password"
                  placeholder="Enter password"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  className="pl-10 h-12 rounded-xl"
                />
              </div>
            </div>

            {!isSignup && (
              <div className="text-right">
                <button type="button" className="text-[#1E7F43] text-sm hover:underline">
                  Forgot Password?
                </button>
              </div>
            )}

            <Button
              type="submit"
              className="w-full h-12 bg-[#1E7F43] hover:bg-[#15593A] text-white rounded-xl"
            >
              {isSignup ? 'Sign Up' : 'Login'}
            </Button>
          </form>

          <div className="mt-6 text-center">
            <button
              type="button"
              onClick={() => setIsSignup(!isSignup)}
              className="text-gray-600 text-sm"
            >
              {isSignup ? 'Already have an account? ' : "Don't have an account? "}
              <span className="text-[#1E7F43]">{isSignup ? 'Login' : 'Sign Up'}</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
