import { Leaf } from 'lucide-react';
import { motion } from 'motion/react';

export default function SplashScreen() {
  return (
    <motion.div 
      className="fixed inset-0 flex flex-col items-center justify-center"
      style={{
        backgroundImage: 'linear-gradient(to bottom, rgba(30, 127, 67, 0.92), rgba(21, 89, 58, 0.95)), url(https://images.unsplash.com/photo-1560493676-04071c5f467b?w=1200)',
        backgroundSize: 'cover',
        backgroundPosition: 'center'
      }}
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
    >
      <motion.div
        initial={{ scale: 0.5, opacity: 0 }}
        animate={{ scale: 1, opacity: 1 }}
        transition={{ duration: 0.5 }}
        className="flex flex-col items-center"
      >
        <div className="bg-white rounded-full p-6 mb-6 shadow-2xl">
          <Leaf className="w-16 h-16 text-[#1E7F43]" />
        </div>
        <h1 className="text-white text-4xl mb-2">AgriVault</h1>
        <p className="text-white/90 text-lg">Post-Harvest Intelligence Platform</p>
        <motion.div 
          className="mt-8 flex gap-2"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.5 }}
        >
          <div className="w-2 h-2 bg-white rounded-full animate-bounce" style={{ animationDelay: '0ms' }}></div>
          <div className="w-2 h-2 bg-white rounded-full animate-bounce" style={{ animationDelay: '150ms' }}></div>
          <div className="w-2 h-2 bg-white rounded-full animate-bounce" style={{ animationDelay: '300ms' }}></div>
        </motion.div>
      </motion.div>
      <motion.p 
        className="absolute bottom-8 text-white/70 text-sm text-center px-4"
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 1 }}
      >
        Reducing post-harvest losses • Empowering farmers
      </motion.p>
    </motion.div>
  );
}