import { useState } from 'react';
import { UserRole } from '../App';
import { Bot, X, Send, Mic, Sparkles, Volume2, Users, MessageCircle, Image as ImageIcon, Smile, Flag, Reply, Wifi, WifiOff } from 'lucide-react';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { motion, AnimatePresence } from 'motion/react';
import { Badge } from './ui/badge';
import { useLanguage } from '../contexts/LanguageContext';
import { LanguageToggleCompact } from './ui/LanguageToggle';
import VoiceRecorder, { VoiceMessage, TTSPlayer } from './ui/VoiceRecorder';
import CommunityChat from './CommunityChat';

interface AIChatProps {
  userRole: UserRole;
}

interface Message {
  id: string;
  text: string;
  isBot: boolean;
  timestamp: Date;
  hasVoice?: boolean;
  voiceUrl?: string;
}

type ChatTab = 'ai' | 'community';

export default function AIChat({ userRole }: AIChatProps) {
  const [isOpen, setIsOpen] = useState(false);
  const [activeTab, setActiveTab] = useState<ChatTab>('ai');
  const [messages, setMessages] = useState<Message[]>([]);
  const [input, setInput] = useState('');
  const [isRecording, setIsRecording] = useState(false);
  const [isTyping, setIsTyping] = useState(false);
  const { language, t } = useLanguage();

  const getRoleSpecificGreeting = () => {
    const greetings = {
      farmer: t('aiChatGreetingFarmer', 'Hello! I\'m your AgriVault AI assistant. How can I help you today?'),
      storage: t('aiChatGreetingStorage', 'Welcome! I can help you with cold storage management and bookings.'),
      transporter: t('aiChatGreetingTransporter', 'Hi! Need help with transport logistics or route optimization?'),
      expert: t('aiChatGreetingExpert', 'Greetings! I can assist you with agricultural queries and consultations.'),
      supplier: t('aiChatGreetingSupplier', 'Welcome! I can help you manage your inventory and orders.'),
      buyer: t('aiChatGreetingBuyer', 'Hello! Looking for quality produce? I can help you find the best deals.'),
      admin: t('aiChatGreetingAdmin', 'Hi Admin! I can help you with platform analytics and management.')
    };
    return greetings[userRole] || greetings.farmer;
  };

  const sendMessage = async (text: string, voiceUrl?: string) => {
    if (!text.trim() && !voiceUrl) return;

    const userMessage: Message = {
      id: Date.now().toString(),
      text: text || t('voiceMessage', 'Voice message'),
      isBot: false,
      timestamp: new Date(),
      hasVoice: !!voiceUrl,
      voiceUrl
    };

    setMessages(prev => [...prev, userMessage]);
    setInput('');
    setIsTyping(true);

    // Simulate AI response
    setTimeout(() => {
      const botMessage: Message = {
        id: (Date.now() + 1).toString(),
        text: getAIResponse(text),
        isBot: true,
        timestamp: new Date(),
        hasVoice: true
      };
      setMessages(prev => [...prev, botMessage]);
      setIsTyping(false);
    }, 1500);
  };

  const getAIResponse = (query: string): string => {
    const responses = {
      weather: t('aiResponseWeather', 'Based on current weather data, I recommend light irrigation for the next 2 days. Rain expected on Friday.'),
      price: t('aiResponsePrice', 'Current market prices show wheat at ₨2,850/quintal (up 3.2% this week). Good time to sell!'),
      disease: t('aiResponseDisease', 'This appears to be leaf rust. Apply fungicide and ensure proper drainage. I can connect you with an expert.'),
      storage: t('aiResponseStorage', 'I found 3 cold storage facilities near you with availability. Would you like to see pricing?'),
      default: t('aiResponseDefault', 'I understand your question. Let me help you with that. Could you provide more details?')
    };

    const lowerQuery = query.toLowerCase();
    if (lowerQuery.includes('weather') || lowerQuery.includes('موسم')) return responses.weather;
    if (lowerQuery.includes('price') || lowerQuery.includes('قیمت')) return responses.price;
    if (lowerQuery.includes('disease') || lowerQuery.includes('بیماری')) return responses.disease;
    if (lowerQuery.includes('storage') || lowerQuery.includes('سٹوریج')) return responses.storage;
    return responses.default;
  };

  const handleVoiceRecording = (voiceMessage: VoiceMessage) => {
    sendMessage(voiceMessage.transcription || t('voiceMessage', 'Voice message'), voiceMessage.audioUrl);
  };

  return (
    <>
      {/* Floating AI Button */}
      <motion.button
        onClick={() => setIsOpen(true)}
        className="fixed bottom-6 right-6 z-50 bg-gradient-to-br from-[#1E7F43] to-[#15593A] text-white p-4 rounded-full shadow-2xl hover:shadow-3xl transition-all"
        whileHover={{ scale: 1.1 }}
        whileTap={{ scale: 0.95 }}
        style={{ display: isOpen ? 'none' : 'flex' }}
      >
        <div className="relative">
          <Bot className="w-6 h-6" />
          <motion.div
            className="absolute -top-1 -right-1 w-3 h-3 bg-yellow-400 rounded-full"
            animate={{ scale: [1, 1.2, 1] }}
            transition={{ repeat: Infinity, duration: 2 }}
          />
        </div>
      </motion.button>

      {/* Chat Window */}
      <AnimatePresence>
        {isOpen && (
          <motion.div
            initial={{ opacity: 0, y: 50, scale: 0.9 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: 50, scale: 0.9 }}
            className="fixed bottom-6 right-6 z-50 w-96 h-[600px] bg-white rounded-3xl shadow-2xl flex flex-col overflow-hidden border border-gray-200"
          >
            {/* Header */}
            <div className="bg-gradient-to-r from-[#1E7F43] to-[#15593A] text-white p-4 flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="relative">
                  <Bot className="w-8 h-8" />
                  <Sparkles className="w-4 h-4 absolute -top-1 -right-1 text-yellow-300" />
                </div>
                <div>
                  <h3 className="font-semibold">{t('aiAssistant', 'AI Assistant')}</h3>
                  <p className="text-xs text-white/80">{t('alwaysHereToHelp', 'Always here to help')}</p>
                </div>
              </div>
              <div className="flex items-center gap-2">
                <LanguageToggleCompact />
                <button 
                  onClick={() => setIsOpen(false)}
                  className="hover:bg-white/20 p-2 rounded-full transition"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>
            </div>

            {/* Tab Selector */}
            <div className="bg-gray-50 p-2 border-b border-gray-200">
              <div className="flex gap-2 max-w-sm mx-auto">
                <button
                  onClick={() => setActiveTab('ai')}
                  className={`flex-1 py-2 px-4 rounded-lg font-medium text-sm transition-all ${
                    activeTab === 'ai' 
                      ? 'bg-[#1E7F43] text-white shadow-sm' 
                      : 'bg-white text-gray-600 hover:bg-gray-100'
                  }`}
                >
                  <div className="flex items-center justify-center gap-2">
                    <Bot className="w-4 h-4" />
                    <span>{t('aiAdvisor', 'AI Advisor')}</span>
                  </div>
                </button>
                <button
                  onClick={() => setActiveTab('community')}
                  className={`flex-1 py-2 px-4 rounded-lg font-medium text-sm transition-all ${
                    activeTab === 'community' 
                      ? 'bg-[#1E7F43] text-white shadow-sm' 
                      : 'bg-white text-gray-600 hover:bg-gray-100'
                  }`}
                >
                  <div className="flex items-center justify-center gap-2">
                    <Users className="w-4 h-4" />
                    <span>{t('community', 'Community')}</span>
                  </div>
                </button>
              </div>
            </div>

            {/* Messages */}
            {activeTab === 'ai' ? (
              <div className="flex-1 overflow-y-auto p-4 space-y-4 bg-gray-50">
                {messages.length === 0 && (
                  <div className="text-center py-8">
                    <div className="bg-white rounded-2xl p-6 shadow-sm border border-gray-100">
                      <Bot className="w-12 h-12 text-[#1E7F43] mx-auto mb-3" />
                      <p className="text-gray-600 text-sm">{getRoleSpecificGreeting()}</p>
                      <div className="mt-4 flex flex-wrap gap-2 justify-center">
                        <Badge variant="outline" className="cursor-pointer hover:bg-[#1E7F43] hover:text-white transition">
                          {t('askWeather', 'Weather')}
                        </Badge>
                        <Badge variant="outline" className="cursor-pointer hover:bg-[#1E7F43] hover:text-white transition">
                          {t('askPrices', 'Prices')}
                        </Badge>
                        <Badge variant="outline" className="cursor-pointer hover:bg-[#1E7F43] hover:text-white transition">
                          {t('askTips', 'Tips')}
                        </Badge>
                      </div>
                    </div>
                  </div>
                )}

                {messages.map((message) => (
                  <div
                    key={message.id}
                    className={`flex ${message.isBot ? 'justify-start' : 'justify-end'}`}
                  >
                    <div className={`max-w-[80%] ${message.isBot ? 'bg-white border border-gray-200' : 'bg-[#1E7F43] text-white'} rounded-2xl p-3 shadow-sm`}>
                      {message.isBot && (
                        <div className="flex items-center gap-2 mb-1">
                          <Bot className="w-4 h-4 text-[#1E7F43]" />
                          <span className="text-xs font-medium text-gray-600">{t('aiAssistant', 'AI Assistant')}</span>
                        </div>
                      )}
                      <p className="text-sm">{message.text}</p>
                      {message.hasVoice && (
                        <div className="mt-2">
                          <TTSPlayer text={message.text} language={language} />
                        </div>
                      )}
                      <p className={`text-xs mt-1 ${message.isBot ? 'text-gray-400' : 'text-white/70'}`}>
                        {message.timestamp.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                      </p>
                    </div>
                  </div>
                ))}

                {isTyping && (
                  <div className="flex justify-start">
                    <div className="bg-white border border-gray-200 rounded-2xl p-3 shadow-sm">
                      <div className="flex gap-1">
                        <motion.div
                          className="w-2 h-2 bg-gray-400 rounded-full"
                          animate={{ y: [0, -8, 0] }}
                          transition={{ repeat: Infinity, duration: 0.6, delay: 0 }}
                        />
                        <motion.div
                          className="w-2 h-2 bg-gray-400 rounded-full"
                          animate={{ y: [0, -8, 0] }}
                          transition={{ repeat: Infinity, duration: 0.6, delay: 0.2 }}
                        />
                        <motion.div
                          className="w-2 h-2 bg-gray-400 rounded-full"
                          animate={{ y: [0, -8, 0] }}
                          transition={{ repeat: Infinity, duration: 0.6, delay: 0.4 }}
                        />
                      </div>
                    </div>
                  </div>
                )}
              </div>
            ) : (
              <CommunityChat />
            )}

            {/* Input - Only show for AI tab */}
            {activeTab === 'ai' && (
              <div className="p-4 bg-white border-t border-gray-200">
                <div className="flex gap-2">
                  <Input
                    value={input}
                    onChange={(e) => setInput(e.target.value)}
                    onKeyPress={(e) => e.key === 'Enter' && sendMessage(input)}
                    placeholder={t('typeMessage', 'Type your message...')}
                    className="flex-1"
                    dir={language === 'ur' ? 'rtl' : 'ltr'}
                  />
                  <VoiceRecorder
                    onRecordingComplete={handleVoiceRecording}
                    language={language}
                  />
                  <Button
                    onClick={() => sendMessage(input)}
                    className="bg-[#1E7F43] hover:bg-[#15593A]"
                    size="icon"
                  >
                    <Send className="w-4 h-4" />
                  </Button>
                </div>
                <p className="text-xs text-gray-400 mt-2 text-center">
                  {t('aiPowered', 'Powered by AgriVault AI')}
                </p>
              </div>
            )}
          </motion.div>
        )}
      </AnimatePresence>
    </>
  );
}