import { useState } from 'react';
import { Home, Package, ShoppingBag, BarChart3, User, Plus, Edit, Eye, TrendingUp, AlertCircle, DollarSign, Star, CheckCircle, Clock, Truck, Camera } from 'lucide-react';
import { Button } from '../ui/button';
import { Input } from '../ui/input';
import { Badge } from '../ui/badge';
import AgriBackground, { AgriHero, AgriSection } from '../ui/AgriBackground';
import { LanguageToggleCompact } from '../ui/LanguageToggle';
import { useLanguage } from '../../contexts/LanguageContext';

interface SupplierDashboardProps {
  onLogout: () => void;
}

type View = 'home' | 'products' | 'addProduct' | 'editProduct' | 'orders' | 'orderDetail' | 'analytics' | 'profile';

interface Product {
  id: string;
  name: string;
  category: string;
  price: number;
  unit: string;
  stock: number;
  image: string;
  cropTags: string[];
  status: 'active' | 'inactive';
  sales: number;
  rating: number;
}

interface Order {
  id: string;
  buyerName: string;
  product: string;
  quantity: number;
  total: number;
  status: 'new' | 'accepted' | 'packed' | 'shipped' | 'delivered';
  date: string;
  buyer: {
    name: string;
    location: string;
    phone: string;
  };
}

export default function SupplierDashboard({ onLogout }: SupplierDashboardProps) {
  const [activeTab, setActiveTab] = useState<'home' | 'products' | 'orders' | 'analytics' | 'profile'>('home');
  const [view, setView] = useState<View>('home');
  const [selectedProduct, setSelectedProduct] = useState<Product | null>(null);
  const [selectedOrder, setSelectedOrder] = useState<Order | null>(null);

  const [products] = useState<Product[]>([
    {
      id: 'P001',
      name: 'Premium Wheat Seeds',
      category: 'Seeds',
      price: 2500,
      unit: '10kg bag',
      stock: 150,
      image: 'https://images.unsplash.com/photo-1574943320219-553eb213f72d?w=400',
      cropTags: ['Wheat', 'Winter'],
      status: 'active',
      sales: 450,
      rating: 4.5
    },
    {
      id: 'P002',
      name: 'NPK Fertilizer',
      category: 'Fertilizers',
      price: 4500,
      unit: '50kg',
      stock: 80,
      image: 'https://images.unsplash.com/photo-1625246333195-78d9c38ad449?w=400',
      cropTags: ['All Crops'],
      status: 'active',
      sales: 320,
      rating: 4.7
    },
    {
      id: 'P003',
      name: 'Organic Pesticide',
      category: 'Pesticides',
      price: 850,
      unit: '500ml',
      stock: 5,
      image: 'https://images.unsplash.com/photo-1588681664899-f142ff2dc9b1?w=400',
      cropTags: ['Vegetables', 'Cotton'],
      status: 'active',
      sales: 180,
      rating: 4.3
    }
  ]);

  const [orders] = useState<Order[]>([
    {
      id: 'ORD001',
      buyerName: 'Ahmed Malik',
      product: 'Premium Wheat Seeds',
      quantity: 5,
      total: 12500,
      status: 'new',
      date: '2024-12-22',
      buyer: {
        name: 'Ahmed Malik',
        location: 'Faisalabad',
        phone: '+92 300 1234567'
      }
    },
    {
      id: 'ORD002',
      buyerName: 'Hassan Khan',
      product: 'NPK Fertilizer',
      quantity: 2,
      total: 9000,
      status: 'packed',
      date: '2024-12-21',
      buyer: {
        name: 'Hassan Khan',
        location: 'Multan',
        phone: '+92 301 7654321'
      }
    },
    {
      id: 'ORD003',
      buyerName: 'Bilal Ahmed',
      product: 'Organic Pesticide',
      quantity: 10,
      total: 8500,
      status: 'delivered',
      date: '2024-12-18',
      buyer: {
        name: 'Bilal Ahmed',
        location: 'Lahore',
        phone: '+92 302 9876543'
      }
    }
  ]);

  const stats = {
    totalProducts: products.length,
    activeOrders: orders.filter(o => o.status !== 'delivered').length,
    monthlySales: 145000,
    earnings: 18650
  };

  const tabs = [
    { id: 'home', icon: Home, label: 'Home' },
    { id: 'products', icon: Package, label: 'Products' },
    { id: 'orders', icon: ShoppingBag, label: 'Orders' },
    { id: 'analytics', icon: BarChart3, label: 'Analytics' },
    { id: 'profile', icon: User, label: 'Profile' }
  ];

  // Home View
  const renderHome = () => (
    <AgriBackground variant="wheat" opacity={8}>
      <AgriHero 
        title="Supplier Dashboard"
        subtitle="Welcome back! Manage your products and orders"
        icon={<Package className="w-8 h-8" />}
        variant="crops"
      />

      <div className="p-4 space-y-4">
        {/* Quick Stats */}
        <div className="grid grid-cols-2 gap-3">
          <div className="bg-white rounded-2xl p-4 shadow-md">
            <Package className="w-8 h-8 text-green-600 mb-2" />
            <p className="text-2xl text-gray-800 mb-1">{stats.totalProducts}</p>
            <p className="text-sm text-gray-500">Total Products</p>
          </div>
          <div className="bg-white rounded-2xl p-4 shadow-md">
            <ShoppingBag className="w-8 h-8 text-blue-600 mb-2" />
            <p className="text-2xl text-gray-800 mb-1">{stats.activeOrders}</p>
            <p className="text-sm text-gray-500">Active Orders</p>
          </div>
          <div className="bg-white rounded-2xl p-4 shadow-md">
            <TrendingUp className="w-8 h-8 text-purple-600 mb-2" />
            <p className="text-2xl text-gray-800 mb-1">PKR {(stats.monthlySales / 1000).toFixed(0)}K</p>
            <p className="text-sm text-gray-500">Monthly Sales</p>
          </div>
          <div className="bg-white rounded-2xl p-4 shadow-md">
            <DollarSign className="w-8 h-8 text-orange-600 mb-2" />
            <p className="text-2xl text-gray-800 mb-1">PKR {(stats.earnings / 1000).toFixed(1)}K</p>
            <p className="text-sm text-gray-500">This Month</p>
          </div>
        </div>

        {/* Quick Actions */}
        <div className="bg-white rounded-2xl p-4 shadow-md">
          <h3 className="text-gray-800 mb-3">Quick Actions</h3>
          <div className="grid grid-cols-2 gap-3">
            <Button
              onClick={() => setView('addProduct')}
              className="bg-[#1E7F43] hover:bg-[#15593A] rounded-xl h-auto py-4 flex flex-col gap-2"
            >
              <Plus className="w-6 h-6" />
              <span>Add Product</span>
            </Button>
            <Button
              variant="outline"
              onClick={() => setActiveTab('orders')}
              className="rounded-xl h-auto py-4 flex flex-col gap-2 border-[#1E7F43] text-[#1E7F43]"
            >
              <Eye className="w-6 h-6" />
              <span>View Orders</span>
            </Button>
          </div>
        </div>

        {/* Recent Orders */}
        <div className="bg-white rounded-2xl p-4 shadow-md">
          <div className="flex items-center justify-between mb-3">
            <h3 className="text-gray-800">Recent Orders</h3>
            <Button variant="ghost" size="sm" onClick={() => setActiveTab('orders')}>
              View All
            </Button>
          </div>
          <div className="space-y-3">
            {orders.slice(0, 3).map((order) => (
              <button
                key={order.id}
                onClick={() => {
                  setSelectedOrder(order);
                  setView('orderDetail');
                }}
                className="w-full bg-gray-50 rounded-xl p-3 hover:bg-gray-100 transition-colors text-left"
              >
                <div className="flex items-center justify-between mb-2">
                  <p className="text-sm">{order.buyerName}</p>
                  <Badge className={
                    order.status === 'new' ? 'bg-orange-500' :
                    order.status === 'delivered' ? 'bg-green-500' : 'bg-blue-500'
                  }>
                    {order.status}
                  </Badge>
                </div>
                <p className="text-xs text-gray-600">{order.product} × {order.quantity}</p>
                <p className="text-sm text-green-600 mt-1">PKR {order.total.toLocaleString()}</p>
              </button>
            ))}
          </div>
        </div>

        {/* Low Stock Alert */}
        {products.some(p => p.stock < 20) && (
          <div className="bg-gradient-to-r from-orange-500 to-red-500 text-white rounded-2xl p-4 shadow-lg">
            <div className="flex items-start gap-3">
              <AlertCircle className="w-6 h-6 flex-shrink-0" />
              <div>
                <h4 className="text-white mb-1">Low Stock Alert</h4>
                <p className="text-sm text-white/90">
                  {products.filter(p => p.stock < 20).length} products running low on stock
                </p>
              </div>
            </div>
          </div>
        )}
      </div>
    </AgriBackground>
  );

  // Products List View
  const renderProducts = () => (
    <AgriBackground variant="vegetable" opacity={8}>
      <AgriHero 
        title="My Products"
        subtitle={`${products.length} products listed`}
        icon={<Package className="w-8 h-8" />}
        variant="crops"
        actions={
          <Button
            onClick={() => setView('addProduct')}
            className="bg-white text-[#1E7F43] hover:bg-white/90 rounded-xl"
            size="sm"
          >
            <Plus className="w-4 h-4 mr-2" />
            Add New Product
          </Button>
        }
      />

      <div className="p-4 space-y-3">
        {products.map((product) => (
          <div key={product.id} className="bg-white rounded-2xl p-4 shadow-md">
            <div className="flex gap-3">
              <img 
                src={product.image} 
                alt={product.name} 
                className="w-20 h-20 object-cover rounded-xl"
              />
              <div className="flex-1">
                <div className="flex items-start justify-between mb-1">
                  <div>
                    <h4 className="text-sm mb-1">{product.name}</h4>
                    <p className="text-xs text-gray-500">{product.category}</p>
                  </div>
                  <Badge className={product.status === 'active' ? 'bg-green-500' : 'bg-gray-400'}>
                    {product.status}
                  </Badge>
                </div>

                <div className="flex items-center gap-2 mb-2">
                  {product.cropTags.slice(0, 2).map((tag, idx) => (
                    <span key={idx} className="text-xs bg-green-50 text-green-700 px-2 py-0.5 rounded-full">
                      {tag}
                    </span>
                  ))}
                </div>

                <div className="flex items-center justify-between text-sm">
                  <div>
                    <p className="text-green-600">PKR {product.price.toLocaleString()}</p>
                    <p className="text-xs text-gray-500">{product.unit}</p>
                  </div>
                  <div className="text-right">
                    <p className={`text-sm ${product.stock < 20 ? 'text-red-600' : 'text-gray-700'}`}>
                      Stock: {product.stock}
                    </p>
                    <div className="flex items-center gap-1 text-xs text-gray-500">
                      <Star className="w-3 h-3 fill-yellow-400 text-yellow-400" />
                      <span>{product.rating}</span>
                    </div>
                  </div>
                </div>

                <div className="flex gap-2 mt-3">
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => {
                      setSelectedProduct(product);
                      setView('editProduct');
                    }}
                    className="flex-1 rounded-lg"
                  >
                    <Edit className="w-3 h-3 mr-1" />
                    Edit
                  </Button>
                  <Button
                    variant="outline"
                    size="sm"
                    className="flex-1 rounded-lg"
                  >
                    <Eye className="w-3 h-3 mr-1" />
                    View
                  </Button>
                </div>
              </div>
            </div>
          </div>
        ))}
      </div>
    </AgriBackground>
  );

  // Add/Edit Product Form
  const renderProductForm = () => (
    <AgriBackground variant="soil" opacity={5}>
      <div className="bg-white border-b sticky top-0 z-10">
        <button
          onClick={() => setView('products')}
          className="flex items-center gap-2 text-[#1E7F43] p-4 hover:bg-green-50 transition-colors"
        >
          <div className="bg-green-50 rounded-full p-1">
            <Package className="w-5 h-5" />
          </div>
          <span>Back to Products</span>
        </button>
        <div className="px-4 pb-4">
          <h2>{view === 'addProduct' ? 'Add New Product' : 'Edit Product'}</h2>
        </div>
      </div>

      <div className="p-4 space-y-4 pb-24">
        {/* Image Upload */}
        <div className="bg-white rounded-2xl p-4 shadow-md">
          <label className="block mb-2 text-sm">Product Images</label>
          <div className="grid grid-cols-3 gap-2">
            <button className="aspect-square bg-gray-100 rounded-xl flex flex-col items-center justify-center border-2 border-dashed border-gray-300 hover:border-[#1E7F43] transition-colors">
              <Camera className="w-8 h-8 text-gray-400 mb-1" />
              <span className="text-xs text-gray-500">Add Photo</span>
            </button>
            <div className="aspect-square bg-gray-200 rounded-xl"></div>
            <div className="aspect-square bg-gray-200 rounded-xl"></div>
          </div>
        </div>

        {/* Product Details */}
        <div className="bg-white rounded-2xl p-4 shadow-md space-y-4">
          <div>
            <label className="block mb-2 text-sm">Product Name</label>
            <Input placeholder="e.g., Premium Wheat Seeds" className="rounded-xl" />
          </div>

          <div>
            <label className="block mb-2 text-sm">Category</label>
            <select className="w-full p-3 border rounded-xl bg-gray-50">
              <option>Seeds</option>
              <option>Fertilizers</option>
              <option>Pesticides</option>
              <option>Tools</option>
              <option>Packaging</option>
            </select>
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block mb-2 text-sm">Price (PKR)</label>
              <Input type="number" placeholder="2500" className="rounded-xl" />
            </div>
            <div>
              <label className="block mb-2 text-sm">Unit</label>
              <Input placeholder="per 10kg" className="rounded-xl" />
            </div>
          </div>

          <div>
            <label className="block mb-2 text-sm">Available Stock</label>
            <Input type="number" placeholder="100" className="rounded-xl" />
          </div>

          <div>
            <label className="block mb-2 text-sm">Crop Compatibility</label>
            <div className="flex flex-wrap gap-2">
              {['Wheat', 'Rice', 'Cotton', 'Vegetables', 'Fruits'].map((crop) => (
                <button
                  key={crop}
                  className="px-3 py-1 rounded-full text-sm border-2 border-gray-200 hover:border-[#1E7F43] hover:bg-green-50 transition-colors"
                >
                  {crop}
                </button>
              ))}
            </div>
          </div>

          <div>
            <label className="block mb-2 text-sm">Description</label>
            <textarea
              className="w-full p-3 border rounded-xl bg-gray-50 min-h-24"
              placeholder="Enter product description and benefits..."
            />
          </div>

          <div>
            <label className="block mb-2 text-sm">Usage Instructions</label>
            <textarea
              className="w-full p-3 border rounded-xl bg-gray-50 min-h-20"
              placeholder="How to use this product..."
            />
          </div>

          <div>
            <label className="block mb-2 text-sm">Delivery Options</label>
            <div className="space-y-2">
              <label className="flex items-center gap-2">
                <input type="checkbox" defaultChecked className="accent-green-600" />
                <span className="text-sm">Home Delivery</span>
              </label>
              <label className="flex items-center gap-2">
                <input type="checkbox" defaultChecked className="accent-green-600" />
                <span className="text-sm">Self Pickup</span>
              </label>
            </div>
          </div>
        </div>
      </div>

      {/* Fixed Bottom Actions */}
      <div className="fixed bottom-0 left-0 right-0 bg-white border-t p-4 shadow-lg">
        <div className="flex gap-3 max-w-md mx-auto">
          <Button
            variant="outline"
            onClick={() => setView('products')}
            className="flex-1 rounded-xl"
          >
            Cancel
          </Button>
          <Button
            onClick={() => setView('products')}
            className="flex-1 rounded-xl bg-[#1E7F43] hover:bg-[#15593A]"
          >
            {view === 'addProduct' ? 'Publish Product' : 'Save Changes'}
          </Button>
        </div>
      </div>
    </AgriBackground>
  );

  // Orders View
  const renderOrders = () => (
    <AgriBackground variant="irrigation" opacity={8}>
      <AgriHero 
        title="Order Management"
        subtitle={`${stats.activeOrders} active orders`}
        icon={<ShoppingBag className="w-8 h-8" />}
        variant="crops"
      />

      <div className="p-4 space-y-3">
        {orders.map((order) => (
          <button
            key={order.id}
            onClick={() => {
              setSelectedOrder(order);
              setView('orderDetail');
            }}
            className="w-full bg-white rounded-2xl p-4 shadow-md hover:shadow-lg transition-shadow text-left"
          >
            <div className="flex items-center justify-between mb-3">
              <div>
                <p className="text-sm mb-1">Order {order.id}</p>
                <p className="text-xs text-gray-500">{order.date}</p>
              </div>
              <Badge className={
                order.status === 'new' ? 'bg-orange-500' :
                order.status === 'accepted' ? 'bg-blue-500' :
                order.status === 'packed' ? 'bg-purple-500' :
                order.status === 'shipped' ? 'bg-indigo-500' : 'bg-green-500'
              }>
                {order.status}
              </Badge>
            </div>

            <div className="flex items-center gap-2 mb-2">
              <div className="w-10 h-10 bg-gradient-to-br from-[#1E7F43] to-[#15593A] rounded-full flex items-center justify-center text-white">
                {order.buyerName.charAt(0)}
              </div>
              <div>
                <p className="text-sm">{order.buyerName}</p>
                <p className="text-xs text-gray-500">{order.buyer.location}</p>
              </div>
            </div>

            <div className="bg-gray-50 rounded-lg p-2 mb-2">
              <p className="text-sm text-gray-700">{order.product}</p>
              <p className="text-xs text-gray-500">Quantity: {order.quantity}</p>
            </div>

            <div className="flex items-center justify-between">
              <span className="text-sm text-gray-600">Total</span>
              <span className="text-green-600">PKR {order.total.toLocaleString()}</span>
            </div>
          </button>
        ))}
      </div>
    </AgriBackground>
  );

  // Order Detail View
  const renderOrderDetail = () => {
    if (!selectedOrder) return null;

    return (
      <AgriBackground variant="soil" opacity={5}>
        <div className="bg-white border-b sticky top-0 z-10">
          <button
            onClick={() => setView('orders')}
            className="flex items-center gap-2 text-[#1E7F43] p-4 hover:bg-green-50 transition-colors"
          >
            <div className="bg-green-50 rounded-full p-1">
              <ShoppingBag className="w-5 h-5" />
            </div>
            <span>Back to Orders</span>
          </button>
          <div className="px-4 pb-4">
            <h2>Order {selectedOrder.id}</h2>
            <p className="text-sm text-gray-500">{selectedOrder.date}</p>
          </div>
        </div>

        <div className="p-4 space-y-4 pb-24">
          {/* Status Timeline */}
          <div className="bg-white rounded-2xl p-4 shadow-md">
            <h4 className="mb-4">Order Status</h4>
            <div className="space-y-3">
              {['new', 'accepted', 'packed', 'shipped', 'delivered'].map((status, idx) => {
                const currentIdx = ['new', 'accepted', 'packed', 'shipped', 'delivered'].indexOf(selectedOrder.status);
                const isCompleted = idx <= currentIdx;
                const isCurrent = idx === currentIdx;
                
                return (
                  <div key={status} className="flex items-center gap-3">
                    <div className={`w-8 h-8 rounded-full flex items-center justify-center ${
                      isCompleted ? 'bg-green-500 text-white' : 'bg-gray-200 text-gray-400'
                    }`}>
                      {isCompleted ? <CheckCircle className="w-5 h-5" /> : <Clock className="w-5 h-5" />}
                    </div>
                    <div className="flex-1">
                      <p className={`text-sm capitalize ${isCurrent ? 'text-green-600' : ''}`}>
                        {status}
                      </p>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

          {/* Buyer Info */}
          <div className="bg-white rounded-2xl p-4 shadow-md">
            <h4 className="mb-3">Buyer Information</h4>
            <div className="flex items-center gap-3 mb-3">
              <div className="w-12 h-12 bg-gradient-to-br from-[#1E7F43] to-[#15593A] rounded-full flex items-center justify-center text-white text-xl">
                {selectedOrder.buyer.name.charAt(0)}
              </div>
              <div>
                <p>{selectedOrder.buyer.name}</p>
                <p className="text-sm text-gray-500">{selectedOrder.buyer.location}</p>
              </div>
            </div>
            <div className="bg-blue-50 rounded-lg p-3 border border-blue-200">
              <p className="text-sm text-blue-800">📞 {selectedOrder.buyer.phone}</p>
            </div>
          </div>

          {/* Order Details */}
          <div className="bg-white rounded-2xl p-4 shadow-md">
            <h4 className="mb-3">Order Details</h4>
            <div className="space-y-2">
              <div className="flex items-center justify-between text-sm">
                <span className="text-gray-600">Product</span>
                <span>{selectedOrder.product}</span>
              </div>
              <div className="flex items-center justify-between text-sm">
                <span className="text-gray-600">Quantity</span>
                <span>{selectedOrder.quantity}</span>
              </div>
              <div className="border-t pt-2 flex items-center justify-between">
                <span>Total Amount</span>
                <span className="text-xl text-green-600">PKR {selectedOrder.total.toLocaleString()}</span>
              </div>
            </div>
          </div>
        </div>

        {/* Fixed Bottom Actions */}
        {selectedOrder.status === 'new' && (
          <div className="fixed bottom-0 left-0 right-0 bg-white border-t p-4 shadow-lg">
            <div className="flex gap-3 max-w-md mx-auto">
              <Button
                variant="outline"
                className="flex-1 rounded-xl border-red-500 text-red-500"
              >
                Reject
              </Button>
              <Button
                className="flex-1 rounded-xl bg-[#1E7F43] hover:bg-[#15593A]"
              >
                Accept Order
              </Button>
            </div>
          </div>
        )}

        {selectedOrder.status === 'accepted' && (
          <div className="fixed bottom-0 left-0 right-0 bg-white border-t p-4 shadow-lg">
            <Button
              className="w-full max-w-md mx-auto rounded-xl bg-[#1E7F43] hover:bg-[#15593A]"
            >
              Mark as Packed
            </Button>
          </div>
        )}

        {selectedOrder.status === 'packed' && (
          <div className="fixed bottom-0 left-0 right-0 bg-white border-t p-4 shadow-lg">
            <Button
              className="w-full max-w-md mx-auto rounded-xl bg-[#1E7F43] hover:bg-[#15593A]"
            >
              <Truck className="w-4 h-4 mr-2" />
              Mark as Shipped
            </Button>
          </div>
        )}
      </AgriBackground>
    );
  };

  // Analytics View
  const renderAnalytics = () => (
    <AgriBackground variant="sunrise" opacity={8}>
      <AgriHero 
        title="Performance Analytics"
        subtitle="Track your business growth"
        icon={<BarChart3 className="w-8 h-8" />}
        variant="crops"
      />

      <div className="p-4 space-y-4">
        {/* Revenue Card */}
        <div className="bg-gradient-to-r from-green-500 to-green-600 text-white rounded-2xl p-5 shadow-lg">
          <p className="text-white/80 text-sm mb-1">Total Revenue This Month</p>
          <p className="text-3xl mb-2">PKR 145,000</p>
          <div className="flex items-center gap-2 text-sm">
            <TrendingUp className="w-4 h-4" />
            <span>+18% from last month</span>
          </div>
        </div>

        {/* Best Selling Products */}
        <div className="bg-white rounded-2xl p-4 shadow-md">
          <h4 className="mb-3">Best Selling Products</h4>
          <div className="space-y-3">
            {products.sort((a, b) => b.sales - a.sales).slice(0, 3).map((product, idx) => (
              <div key={product.id} className="flex items-center gap-3">
                <div className="w-8 h-8 bg-gradient-to-br from-[#1E7F43] to-[#15593A] rounded-full flex items-center justify-center text-white text-sm">
                  {idx + 1}
                </div>
                <img src={product.image} alt={product.name} className="w-12 h-12 object-cover rounded-lg" />
                <div className="flex-1">
                  <p className="text-sm mb-1">{product.name}</p>
                  <p className="text-xs text-gray-500">{product.sales} sales</p>
                </div>
                <div className="flex items-center gap-1 text-xs">
                  <Star className="w-3 h-3 fill-yellow-400 text-yellow-400" />
                  <span>{product.rating}</span>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Customer Ratings */}
        <div className="bg-white rounded-2xl p-4 shadow-md">
          <h4 className="mb-3">Customer Ratings</h4>
          <div className="text-center mb-4">
            <p className="text-4xl text-green-600 mb-1">4.5</p>
            <div className="flex items-center justify-center gap-1 mb-1">
              {[1, 2, 3, 4, 5].map((star) => (
                <Star key={star} className={`w-5 h-5 ${star <= 4 ? 'fill-yellow-400 text-yellow-400' : 'text-gray-300'}`} />
              ))}
            </div>
            <p className="text-sm text-gray-500">Based on 127 reviews</p>
          </div>
        </div>
      </div>
    </AgriBackground>
  );

  // Profile View
  const renderProfile = () => (
    <AgriBackground variant="crops" opacity={8}>
      <AgriHero 
        title="Supplier Profile"
        subtitle="Manage your business information"
        icon={<User className="w-8 h-8" />}
        variant="wheat"
      />

      <div className="p-4 space-y-4">
        {/* Profile Card */}
        <div className="bg-white rounded-2xl p-6 shadow-md text-center">
          <div className="w-24 h-24 bg-gradient-to-br from-[#1E7F43] to-[#15593A] rounded-full flex items-center justify-center text-white text-3xl mx-auto mb-4">
            AS
          </div>
          <h3 className="mb-1">AgriSupply Store</h3>
          <p className="text-sm text-gray-500 mb-2">Verified Supplier</p>
          <Badge className="bg-blue-500">✓ Verified Business</Badge>
        </div>

        {/* Business Info */}
        <div className="bg-white rounded-2xl p-4 shadow-md space-y-3">
          <h4 className="mb-3">Business Information</h4>
          <div>
            <label className="block text-sm text-gray-500 mb-1">Business Name</label>
            <Input defaultValue="AgriSupply Store" className="rounded-xl" />
          </div>
          <div>
            <label className="block text-sm text-gray-500 mb-1">Location</label>
            <Input defaultValue="Faisalabad, Punjab" className="rounded-xl" />
          </div>
          <div>
            <label className="block text-sm text-gray-500 mb-1">Contact Number</label>
            <Input defaultValue="+92 300 1234567" className="rounded-xl" />
          </div>
          <div>
            <label className="block text-sm text-gray-500 mb-1">WhatsApp</label>
            <Input defaultValue="+92 300 1234567" className="rounded-xl" />
          </div>
        </div>

        {/* Actions */}
        <div className="space-y-2">
          <Button
            variant="outline"
            className="w-full rounded-xl border-red-500 text-red-500"
            onClick={onLogout}
          >
            Logout
          </Button>
        </div>
      </div>
    </AgriBackground>
  );

  // Render based on view
  const renderContent = () => {
    if (view === 'addProduct' || view === 'editProduct') return renderProductForm();
    if (view === 'orderDetail') return renderOrderDetail();
    
    if (activeTab === 'home') return renderHome();
    if (activeTab === 'products') return renderProducts();
    if (activeTab === 'orders') return renderOrders();
    if (activeTab === 'analytics') return renderAnalytics();
    if (activeTab === 'profile') return renderProfile();
    
    return renderHome();
  };

  return (
    <div className="min-h-screen bg-gray-50 pb-20">
      {renderContent()}

      {/* Bottom Navigation */}
      <div className="fixed bottom-0 left-0 right-0 bg-white border-t border-gray-200 shadow-lg">
        <div className="flex justify-around items-center h-20 max-w-md mx-auto">
          {tabs.map((tab) => {
            const Icon = tab.icon;
            const isActive = activeTab === tab.id;
            return (
              <button
                key={tab.id}
                onClick={() => {
                  setActiveTab(tab.id as any);
                  setView('home');
                }}
                className={`flex flex-col items-center justify-center gap-1 px-4 py-2 transition-colors ${
                  isActive ? 'text-[#1E7F43]' : 'text-gray-500'
                }`}
              >
                <Icon className={`w-6 h-6 ${isActive ? 'fill-[#1E7F43]/10' : ''}`} />
                <span className="text-xs">{tab.label}</span>
              </button>
            );
          })}
        </div>
      </div>
    </div>
  );
}