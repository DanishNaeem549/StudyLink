import { MessageCircle, Users, CheckCircle2, Clock, TrendingUp } from 'lucide-react';
import { Button } from '../ui/button';

interface ExpertDashboardProps {
  onLogout: () => void;
}

export default function ExpertDashboard({ onLogout }: ExpertDashboardProps) {
  const consultations = [
    { id: 1, farmer: 'Ahmed Ali', topic: 'Tomato Leaf Curl Issue', time: '5 min ago', status: 'active' },
    { id: 2, farmer: 'Hassan Raza', topic: 'Wheat Fertilizer Question', time: '2 hours ago', status: 'pending' },
    { id: 3, farmer: 'Ali Khan', topic: 'Pest Control Advice', time: '1 day ago', status: 'completed' }
  ];

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <div className="bg-gradient-to-r from-blue-500 to-blue-600 text-white p-6">
        <h2 className="text-2xl mb-1">Expert Dashboard</h2>
        <p className="text-white/80 text-sm">Dr. Muhammad Hassan</p>
        <p className="text-white/80 text-xs">Crop Diseases Specialist</p>
      </div>

      <div className="p-4 space-y-4">
        {/* Stats */}
        <div className="grid grid-cols-2 gap-3">
          <div className="bg-white rounded-2xl p-4">
            <MessageCircle className="w-6 h-6 text-blue-500 mb-2" />
            <p className="text-2xl text-gray-800 mb-1">12</p>
            <p className="text-sm text-gray-600">Active Chats</p>
          </div>

          <div className="bg-white rounded-2xl p-4">
            <Clock className="w-6 h-6 text-orange-500 mb-2" />
            <p className="text-2xl text-gray-800 mb-1">5</p>
            <p className="text-sm text-gray-600">Pending</p>
          </div>

          <div className="bg-white rounded-2xl p-4">
            <CheckCircle2 className="w-6 h-6 text-green-500 mb-2" />
            <p className="text-2xl text-gray-800 mb-1">1,247</p>
            <p className="text-sm text-gray-600">Completed</p>
          </div>

          <div className="bg-white rounded-2xl p-4">
            <TrendingUp className="w-6 h-6 text-purple-500 mb-2" />
            <p className="text-2xl text-gray-800 mb-1">4.9</p>
            <p className="text-sm text-gray-600">Rating</p>
          </div>
        </div>

        {/* Consultation Requests */}
        <div className="bg-white rounded-2xl p-5">
          <h3 className="text-gray-800 mb-4">Recent Consultations</h3>
          <div className="space-y-3">
            {consultations.map((item) => (
              <div key={item.id} className="p-4 bg-gray-50 rounded-xl">
                <div className="flex items-center justify-between mb-2">
                  <div>
                    <h4 className="text-gray-800">{item.farmer}</h4>
                    <p className="text-sm text-gray-600">{item.topic}</p>
                  </div>
                  <span className={`px-2 py-1 rounded-full text-xs ${
                    item.status === 'active' ? 'bg-green-100 text-green-700' :
                    item.status === 'pending' ? 'bg-orange-100 text-orange-700' :
                    'bg-gray-100 text-gray-700'
                  }`}>
                    {item.status}
                  </span>
                </div>
                <p className="text-xs text-gray-500">{item.time}</p>
              </div>
            ))}
          </div>
        </div>

        {/* Availability Toggle */}
        <div className="bg-white rounded-2xl p-5">
          <div className="flex items-center justify-between">
            <div>
              <h3 className="text-gray-800 mb-1">Availability Status</h3>
              <p className="text-sm text-gray-600">You're currently online</p>
            </div>
            <div className="bg-green-500 rounded-full w-14 h-7 flex items-center px-1">
              <div className="bg-white rounded-full w-6 h-6 ml-auto"></div>
            </div>
          </div>
        </div>

        <Button onClick={onLogout} variant="destructive" className="w-full">
          Logout
        </Button>
      </div>
    </div>
  );
}
