import { useState } from 'react';
import { Bell, Truck, MapPin, DollarSign, Settings, Package, CheckCircle2, Clock, Navigation } from 'lucide-react';

interface TransporterDashboardProps {
  onLogout: () => void;
}

type View = 'dashboard' | 'requests' | 'active' | 'routes' | 'earnings' | 'profile';

export default function TransporterDashboard({ onLogout }: TransporterDashboardProps) {
  const [view, setView] = useState<View>('dashboard');
  const [requests, setRequests] = useState([
    {
      id: 1,
      farmer: 'Ahmed Ali',
      pickup: 'Farm, GT Road, Lahore',
      dropoff: 'Lahore Mandi',
      crop: 'Tomatoes',
      quantity: '500 kg',
      distance: '12 km',
      fare: 800,
      date: 'Dec 21, 2024',
      status: 'pending'
    },
    {
      id: 2,
      farmer: 'Hassan Raza',
      pickup: 'Farm, Multan Road, Lahore',
      dropoff: 'Green Valley Cold Storage',
      crop: 'Potatoes',
      quantity: '1000 kg',
      distance: '8 km',
      fare: 600,
      date: 'Dec 21, 2024',
      status: 'pending'
    }
  ]);

  const [activeJobs, setActiveJobs] = useState([
    {
      id: 3,
      farmer: 'Ali Khan',
      pickup: 'Farm, Ferozepur Road',
      dropoff: 'Karachi Market',
      crop: 'Onions',
      quantity: '800 kg',
      distance: '1200 km',
      fare: 12000,
      status: 'on-way',
      progress: 30
    }
  ]);

  const handleAcceptRequest = (requestId: number) => {
    const request = requests.find(r => r.id === requestId);
    if (request) {
      setActiveJobs([...activeJobs, { ...request, status: 'accepted', progress: 0 }]);
      setRequests(requests.filter(r => r.id !== requestId));
    }
  };

  const handleRejectRequest = (requestId: number) => {
    setRequests(requests.filter(r => r.id !== requestId));
  };

  // Dashboard View
  if (view === 'dashboard') {
    return (
      <div className="min-h-screen bg-gray-50 pb-20">
        {/* Header */}
        <div className="bg-gradient-to-r from-orange-500 to-orange-600 text-white p-6">
          <div className="flex items-center justify-between mb-4">
            <div>
              <h2 className="text-2xl mb-1">Welcome, Bilal!</h2>
              <p className="text-white/80 text-sm">Transport Provider</p>
            </div>
            <div className="relative">
              <Bell className="w-6 h-6" />
              <div className="absolute -top-1 -right-1 bg-red-500 rounded-full w-5 h-5 flex items-center justify-center text-xs">
                {requests.length}
              </div>
            </div>
          </div>

          {/* Availability Toggle */}
          <div className="bg-white/10 rounded-2xl p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-lg mb-1">You're Online</p>
                <p className="text-white/80 text-sm">Accepting new requests</p>
              </div>
              <div className="bg-green-500 rounded-full w-14 h-7 flex items-center px-1">
                <div className="bg-white rounded-full w-6 h-6 ml-auto"></div>
              </div>
            </div>
          </div>
        </div>

        <div className="p-4 space-y-4">
          {/* Quick Stats */}
          <div className="grid grid-cols-2 gap-3">
            <div className="bg-white rounded-2xl p-4 border-2 border-gray-200">
              <div className="bg-red-100 rounded-full w-12 h-12 flex items-center justify-center mb-3">
                <Bell className="w-6 h-6 text-red-600" />
              </div>
              <p className="text-2xl text-gray-800 mb-1">{requests.length}</p>
              <p className="text-sm text-gray-600">New Requests</p>
            </div>

            <div className="bg-white rounded-2xl p-4 border-2 border-gray-200">
              <div className="bg-blue-100 rounded-full w-12 h-12 flex items-center justify-center mb-3">
                <Truck className="w-6 h-6 text-blue-600" />
              </div>
              <p className="text-2xl text-gray-800 mb-1">{activeJobs.length}</p>
              <p className="text-sm text-gray-600">Active Jobs</p>
            </div>

            <div className="bg-white rounded-2xl p-4 border-2 border-gray-200">
              <div className="bg-green-100 rounded-full w-12 h-12 flex items-center justify-center mb-3">
                <DollarSign className="w-6 h-6 text-green-600" />
              </div>
              <p className="text-2xl text-gray-800 mb-1">₨18.5K</p>
              <p className="text-sm text-gray-600">This Month</p>
            </div>

            <div className="bg-white rounded-2xl p-4 border-2 border-gray-200">
              <div className="bg-purple-100 rounded-full w-12 h-12 flex items-center justify-center mb-3">
                <CheckCircle2 className="w-6 h-6 text-purple-600" />
              </div>
              <p className="text-2xl text-gray-800 mb-1">24</p>
              <p className="text-sm text-gray-600">Completed</p>
            </div>
          </div>

          {/* Action Cards */}
          <div className="grid grid-cols-1 gap-3">
            <button 
              onClick={() => setView('requests')}
              className="bg-gradient-to-r from-red-500 to-red-600 text-white rounded-2xl p-6 text-left hover:shadow-lg transition-shadow"
            >
              <div className="flex items-center justify-between">
                <div>
                  <h3 className="text-xl mb-1">New Transport Requests</h3>
                  <p className="text-white/80 text-sm">{requests.length} farmers need your service</p>
                </div>
                <Bell className="w-8 h-8" />
              </div>
            </button>

            <button 
              onClick={() => setView('active')}
              className="bg-gradient-to-r from-blue-500 to-blue-600 text-white rounded-2xl p-6 text-left hover:shadow-lg transition-shadow"
            >
              <div className="flex items-center justify-between">
                <div>
                  <h3 className="text-xl mb-1">Active Jobs</h3>
                  <p className="text-white/80 text-sm">Track your ongoing deliveries</p>
                </div>
                <Truck className="w-8 h-8" />
              </div>
            </button>

            <button 
              onClick={() => setView('routes')}
              className="bg-gradient-to-r from-purple-500 to-purple-600 text-white rounded-2xl p-6 text-left hover:shadow-lg transition-shadow"
            >
              <div className="flex items-center justify-between">
                <div>
                  <h3 className="text-xl mb-1">My Routes</h3>
                  <p className="text-white/80 text-sm">Manage preferred routes</p>
                </div>
                <Navigation className="w-8 h-8" />
              </div>
            </button>

            <button 
              onClick={() => setView('earnings')}
              className="bg-gradient-to-r from-green-500 to-green-600 text-white rounded-2xl p-6 text-left hover:shadow-lg transition-shadow"
            >
              <div className="flex items-center justify-between">
                <div>
                  <h3 className="text-xl mb-1">Earnings</h3>
                  <p className="text-white/80 text-sm">View payment history</p>
                </div>
                <DollarSign className="w-8 h-8" />
              </div>
            </button>
          </div>

          {/* Vehicle Info */}
          <div className="bg-white rounded-2xl p-5">
            <h3 className="text-gray-800 mb-4">Vehicle Information</h3>
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <span className="text-gray-600 text-sm">Type</span>
                <span className="text-gray-800">Mini Truck</span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-gray-600 text-sm">Capacity</span>
                <span className="text-gray-800">1500 kg</span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-gray-600 text-sm">Number Plate</span>
                <span className="text-gray-800">LHR-1234</span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-gray-600 text-sm">Rate</span>
                <span className="text-gray-800">₨50/km</span>
              </div>
            </div>
          </div>
        </div>

        {/* Bottom Navigation */}
        <div className="fixed bottom-0 left-0 right-0 bg-white border-t border-gray-200 shadow-lg">
          <div className="flex justify-around items-center h-20 max-w-md mx-auto">
            <button onClick={() => setView('dashboard')} className="flex flex-col items-center justify-center gap-1 px-4 py-2 text-orange-500">
              <Truck className="w-6 h-6" />
              <span className="text-xs">Dashboard</span>
            </button>
            <button onClick={() => setView('requests')} className="flex flex-col items-center justify-center gap-1 px-4 py-2 text-gray-500 relative">
              <Bell className="w-6 h-6" />
              {requests.length > 0 && (
                <div className="absolute top-1 right-2 bg-red-500 rounded-full w-5 h-5 flex items-center justify-center text-xs text-white">
                  {requests.length}
                </div>
              )}
              <span className="text-xs">Requests</span>
            </button>
            <button onClick={() => setView('active')} className="flex flex-col items-center justify-center gap-1 px-4 py-2 text-gray-500">
              <Package className="w-6 h-6" />
              <span className="text-xs">Active</span>
            </button>
            <button onClick={() => setView('profile')} className="flex flex-col items-center justify-center gap-1 px-4 py-2 text-gray-500">
              <Settings className="w-6 h-6" />
              <span className="text-xs">Profile</span>
            </button>
          </div>
        </div>
      </div>
    );
  }

  // Requests View
  if (view === 'requests') {
    return (
      <div className="min-h-screen bg-gray-50 pb-20">
        <div className="bg-gradient-to-r from-red-500 to-red-600 text-white p-6">
          <button onClick={() => setView('dashboard')} className="mb-3">← Back</button>
          <h2 className="text-2xl">New Transport Requests</h2>
          <p className="text-white/80 text-sm">{requests.length} pending requests</p>
        </div>

        <div className="p-4 space-y-3">
          {requests.length === 0 ? (
            <div className="bg-white rounded-2xl p-8 text-center">
              <Clock className="w-16 h-16 text-gray-300 mx-auto mb-3" />
              <p className="text-gray-600">No new requests at the moment</p>
            </div>
          ) : (
            requests.map((request) => (
              <div key={request.id} className="bg-white rounded-2xl p-5 border-2 border-gray-200">
                <div className="flex items-center justify-between mb-3">
                  <div>
                    <h3 className="text-gray-800 text-lg">{request.farmer}</h3>
                    <p className="text-sm text-gray-500">{request.date}</p>
                  </div>
                  <div className="text-right">
                    <p className="text-orange-600 text-2xl">₨{request.fare}</p>
                    <p className="text-xs text-gray-500">{request.distance}</p>
                  </div>
                </div>

                <div className="space-y-2 mb-4">
                  <div className="flex items-start gap-2">
                    <MapPin className="w-5 h-5 text-green-500 flex-shrink-0 mt-0.5" />
                    <div>
                      <p className="text-xs text-gray-500">Pickup</p>
                      <p className="text-sm text-gray-800">{request.pickup}</p>
                    </div>
                  </div>
                  <div className="flex items-start gap-2">
                    <MapPin className="w-5 h-5 text-red-500 flex-shrink-0 mt-0.5" />
                    <div>
                      <p className="text-xs text-gray-500">Drop-off</p>
                      <p className="text-sm text-gray-800">{request.dropoff}</p>
                    </div>
                  </div>
                </div>

                <div className="flex items-center gap-4 mb-4 text-sm text-gray-600">
                  <span>🌾 {request.crop}</span>
                  <span>📦 {request.quantity}</span>
                </div>

                <div className="flex gap-2">
                  <button
                    onClick={() => handleRejectRequest(request.id)}
                    className="flex-1 bg-gray-100 text-gray-700 py-3 rounded-xl hover:bg-gray-200 transition-colors"
                  >
                    Reject
                  </button>
                  <button
                    onClick={() => handleAcceptRequest(request.id)}
                    className="flex-1 bg-orange-500 text-white py-3 rounded-xl hover:bg-orange-600 transition-colors"
                  >
                    Accept
                  </button>
                </div>
              </div>
            ))
          )}
        </div>
      </div>
    );
  }

  // Active Jobs View
  if (view === 'active') {
    return (
      <div className="min-h-screen bg-gray-50 pb-20">
        <div className="bg-gradient-to-r from-blue-500 to-blue-600 text-white p-6">
          <button onClick={() => setView('dashboard')} className="mb-3">← Back</button>
          <h2 className="text-2xl">Active Jobs</h2>
          <p className="text-white/80 text-sm">{activeJobs.length} ongoing delivery</p>
        </div>

        <div className="p-4 space-y-3">
          {activeJobs.map((job) => (
            <div key={job.id} className="bg-white rounded-2xl p-5 border-2 border-blue-200">
              <div className="flex items-center justify-between mb-3">
                <div>
                  <div className="bg-blue-100 text-blue-700 px-3 py-1 rounded-full text-xs inline-block mb-2">
                    {job.status === 'accepted' ? 'Accepted' : 
                     job.status === 'on-way' ? 'On the Way' :
                     job.status === 'loaded' ? 'Loaded' : 'In Transit'}
                  </div>
                  <h3 className="text-gray-800 text-lg">{job.farmer}</h3>
                </div>
                <p className="text-blue-600 text-2xl">₨{job.fare}</p>
              </div>

              <div className="space-y-2 mb-4">
                <div className="flex items-start gap-2">
                  <MapPin className="w-5 h-5 text-green-500 flex-shrink-0 mt-0.5" />
                  <div>
                    <p className="text-xs text-gray-500">Pickup</p>
                    <p className="text-sm text-gray-800">{job.pickup}</p>
                  </div>
                </div>
                <div className="flex items-start gap-2">
                  <MapPin className="w-5 h-5 text-red-500 flex-shrink-0 mt-0.5" />
                  <div>
                    <p className="text-xs text-gray-500">Drop-off</p>
                    <p className="text-sm text-gray-800">{job.dropoff}</p>
                  </div>
                </div>
              </div>

              {/* Progress */}
              <div className="mb-4">
                <div className="flex items-center justify-between text-sm mb-2">
                  <span className="text-gray-600">Progress</span>
                  <span className="text-gray-800">{job.progress}%</span>
                </div>
                <div className="bg-gray-200 rounded-full h-2">
                  <div 
                    className="bg-blue-500 rounded-full h-2 transition-all"
                    style={{ width: `${job.progress}%` }}
                  ></div>
                </div>
              </div>

              <div className="flex gap-2">
                <button className="flex-1 bg-gray-100 text-gray-700 py-3 rounded-xl hover:bg-gray-200 transition-colors">
                  Call Farmer
                </button>
                <button className="flex-1 bg-blue-500 text-white py-3 rounded-xl hover:bg-blue-600 transition-colors">
                  Update Status
                </button>
              </div>
            </div>
          ))}

          {activeJobs.length === 0 && (
            <div className="bg-white rounded-2xl p-8 text-center">
              <Truck className="w-16 h-16 text-gray-300 mx-auto mb-3" />
              <p className="text-gray-600">No active jobs</p>
            </div>
          )}
        </div>
      </div>
    );
  }

  // Routes View
  if (view === 'routes') {
    return (
      <div className="min-h-screen bg-gray-50 pb-20">
        <div className="bg-gradient-to-r from-purple-500 to-purple-600 text-white p-6">
          <button onClick={() => setView('dashboard')} className="mb-3">← Back</button>
          <h2 className="text-2xl">My Routes</h2>
          <p className="text-white/80 text-sm">Preferred routes & pooling</p>
        </div>

        <div className="p-4 space-y-4">
          <button className="w-full bg-gradient-to-r from-purple-500 to-purple-600 text-white rounded-2xl p-5 text-left hover:shadow-lg transition-shadow">
            <div className="flex items-center justify-between mb-2">
              <h3 className="text-lg">Add New Route</h3>
              <span className="text-3xl">+</span>
            </div>
            <p className="text-white/80 text-sm">Set your preferred routes for regular trips</p>
          </button>

          <div className="bg-white rounded-2xl p-5">
            <h3 className="text-gray-800 mb-4">Saved Routes</h3>
            <div className="space-y-3">
              <div className="p-4 bg-purple-50 border-2 border-purple-200 rounded-xl">
                <div className="flex items-center justify-between mb-2">
                  <h4 className="text-gray-800">Lahore → Karachi</h4>
                  <span className="bg-green-100 text-green-700 px-2 py-1 rounded-full text-xs">Active</span>
                </div>
                <p className="text-sm text-gray-600">1200 km • ₨10/km</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  }

  // Earnings View
  if (view === 'earnings') {
    return (
      <div className="min-h-screen bg-gray-50 pb-20">
        <div className="bg-gradient-to-r from-green-500 to-green-600 text-white p-6">
          <button onClick={() => setView('dashboard')} className="mb-3">← Back</button>
          <h2 className="text-2xl mb-3">Earnings</h2>
          <div className="bg-white/10 rounded-2xl p-4">
            <p className="text-white/80 text-sm mb-1">This Month</p>
            <p className="text-4xl">₨18,500</p>
          </div>
        </div>

        <div className="p-4 space-y-4">
          <div className="grid grid-cols-3 gap-3">
            <div className="bg-white rounded-2xl p-4 text-center">
              <p className="text-gray-500 text-sm mb-1">Today</p>
              <p className="text-xl text-gray-800">₨1.2K</p>
            </div>
            <div className="bg-white rounded-2xl p-4 text-center">
              <p className="text-gray-500 text-sm mb-1">Week</p>
              <p className="text-xl text-gray-800">₨5.8K</p>
            </div>
            <div className="bg-white rounded-2xl p-4 text-center">
              <p className="text-gray-500 text-sm mb-1">Month</p>
              <p className="text-xl text-gray-800">₨18.5K</p>
            </div>
          </div>

          <div className="bg-white rounded-2xl p-5">
            <h3 className="text-gray-800 mb-4">Recent Trips</h3>
            <div className="space-y-3">
              {[
                { date: 'Dec 20', route: 'Lahore → Karachi', amount: 12000 },
                { date: 'Dec 19', route: 'Lahore → Storage', amount: 600 },
                { date: 'Dec 18', route: 'Farm → Mandi', amount: 800 }
              ].map((trip, idx) => (
                <div key={idx} className="flex items-center justify-between p-3 bg-gray-50 rounded-xl">
                  <div>
                    <p className="text-gray-800 text-sm">{trip.route}</p>
                    <p className="text-xs text-gray-500">{trip.date}</p>
                  </div>
                  <p className="text-green-600">+₨{trip.amount}</p>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    );
  }

  // Profile View
  if (view === 'profile') {
    return (
      <div className="min-h-screen bg-gray-50 pb-20">
        <div className="bg-gradient-to-r from-orange-500 to-orange-600 text-white p-6">
          <button onClick={() => setView('dashboard')} className="mb-3">← Back</button>
          <h2 className="text-2xl">Profile & Settings</h2>
        </div>

        <div className="p-4 space-y-4">
          <div className="bg-white rounded-2xl p-5">
            <h3 className="text-gray-800 mb-4">Account</h3>
            <button onClick={onLogout} className="w-full bg-red-500 text-white py-3 rounded-xl hover:bg-red-600 transition-colors">
              Logout
            </button>
          </div>
        </div>
      </div>
    );
  }

  return null;
}
