import { useState } from 'react';
import { motion } from 'motion/react';
import {
  ArrowLeft,
  MapPin,
  Truck,
  CheckCircle2,
  Clock,
  Phone,
  MessageCircle,
  QrCode,
  Thermometer,
  Package,
  AlertCircle,
  Navigation,
  BadgeCheck,
  Download,
  Share2,
  Star,
  DollarSign,
  Snowflake,
  Calendar
} from 'lucide-react';
import { Button } from '../ui/button';
import { Badge } from '../ui/badge';
import { useLanguage } from '../../contexts/LanguageContext';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from '../ui/dialog';

type OrderStatus = 'scheduled' | 'picked_up' | 'in_transit' | 'stored' | 'delivered';

interface OrderDetails {
  orderId: string;
  status: OrderStatus;
  cropName: string;
  grade: string;
  quantity: number;
  buyerName: string;
  buyerVerified: boolean;
  transportType: string;
  storageUsed: boolean;
  storageFacility?: string;
  temperature?: string;
  storageRemaining?: string;
  totalValue: number;
  netEarnings: number;
}

interface TimelineStep {
  id: string;
  label: string;
  status: 'completed' | 'active' | 'pending';
  timestamp?: string;
  icon: any;
}

interface TransporterInfo {
  name: string;
  phone: string;
  rating: number;
  vehicleNumber: string;
}

const MOCK_ORDER: OrderDetails = {
  orderId: 'AGV87654321',
  status: 'in_transit',
  cropName: 'Tomato',
  grade: 'A',
  quantity: 500,
  buyerName: 'Karachi Fresh Foods',
  buyerVerified: true,
  transportType: 'AgriVault Transport',
  storageUsed: true,
  storageFacility: 'FreshKeep Cold Storage',
  temperature: '2-4°C',
  storageRemaining: '2 days remaining',
  totalValue: 29000,
  netEarnings: 27350,
};

const TRANSPORTER: TransporterInfo = {
  name: 'Zahid Khan',
  phone: '+92 300 1234567',
  rating: 4.9,
  vehicleNumber: 'LHR-5432',
};

interface OrderTrackingProps {
  onBack: () => void;
}

export default function OrderTracking({ onBack }: OrderTrackingProps) {
  const [showQR, setShowQR] = useState(false);
  const [showConfirmDelivery, setShowConfirmDelivery] = useState(false);
  const { language, t } = useLanguage();

  const getTimeline = (): TimelineStep[] => {
    const timeline: TimelineStep[] = [
      {
        id: '1',
        label: t('pickupScheduled', 'Pickup Scheduled'),
        status: 'completed',
        timestamp: 'Today, 10:00 AM',
        icon: Calendar,
      },
      {
        id: '2',
        label: t('pickedUp', 'Picked Up'),
        status: 'completed',
        timestamp: 'Today, 10:15 AM',
        icon: CheckCircle2,
      },
      {
        id: '3',
        label: t('inTransit', 'In Transit'),
        status: 'active',
        timestamp: 'ETA: 12:30 PM',
        icon: Truck,
      },
    ];

    if (MOCK_ORDER.storageUsed) {
      timeline.push({
        id: '4',
        label: t('stored', 'In Cold Storage'),
        status: 'pending',
        icon: Snowflake,
      });
    }

    timeline.push({
      id: '5',
      label: t('delivered', 'Delivered'),
      status: 'pending',
      icon: CheckCircle2,
    });

    return timeline;
  };

  const getStatusBadge = (status: OrderStatus) => {
    const statusConfig = {
      scheduled: { label: t('scheduled', 'Scheduled'), color: 'bg-blue-500' },
      picked_up: { label: t('pickedUp', 'Picked Up'), color: 'bg-purple-500' },
      in_transit: { label: t('inTransit', 'In Transit'), color: 'bg-orange-500' },
      stored: { label: t('stored', 'In Storage'), color: 'bg-cyan-500' },
      delivered: { label: t('delivered', 'Delivered'), color: 'bg-green-500' },
    };

    const config = statusConfig[status];
    return (
      <Badge className={`${config.color} text-white border-0`}>
        {config.label}
      </Badge>
    );
  };

  const confirmDelivery = () => {
    setShowConfirmDelivery(false);
    // Handle delivery confirmation
  };

  return (
    <div className="min-h-screen bg-gradient-to-b from-[#F5F9F5] to-white pb-24">
      {/* Header */}
      <div className="bg-gradient-to-r from-[#1E7F43] to-[#15593A] text-white p-4">
        <div className="flex items-center gap-3 mb-3">
          <button
            onClick={onBack}
            className="p-2 hover:bg-white/20 rounded-full transition"
          >
            <ArrowLeft className="w-5 h-5" />
          </button>
          <div className="flex-1">
            <h1 className="text-xl font-semibold">{t('orderTracking', 'Order Tracking')}</h1>
            <p className="text-xs text-white/80">{t('orderId', 'Order ID')}: #{MOCK_ORDER.orderId}</p>
          </div>
          {getStatusBadge(MOCK_ORDER.status)}
        </div>
      </div>

      <div className="p-4 space-y-4">
        {/* Map View */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="bg-white rounded-2xl overflow-hidden shadow-sm border border-gray-100"
        >
          {/* Map Placeholder */}
          <div className="relative h-48 bg-gradient-to-br from-green-100 to-blue-100 flex items-center justify-center">
            <div className="absolute inset-0 opacity-10">
              <svg className="w-full h-full" viewBox="0 0 200 200">
                <path d="M 20 100 Q 60 60, 100 100 T 180 100" stroke="#1E7F43" strokeWidth="3" fill="none" />
              </svg>
            </div>
            
            {/* Location Markers */}
            <div className="absolute top-4 left-4">
              <div className="bg-green-600 text-white p-2 rounded-full shadow-lg">
                <MapPin className="w-4 h-4" />
              </div>
              <p className="text-xs font-medium mt-1 bg-white px-2 py-1 rounded shadow">
                {t('farm', 'Farm')}
              </p>
            </div>

            <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2">
              <motion.div
                animate={{ scale: [1, 1.1, 1] }}
                transition={{ repeat: Infinity, duration: 2 }}
                className="bg-orange-500 text-white p-3 rounded-full shadow-lg"
              >
                <Truck className="w-5 h-5" />
              </motion.div>
              <p className="text-xs font-medium mt-1 bg-white px-2 py-1 rounded shadow text-center">
                {t('enRoute', 'En Route')}
              </p>
            </div>

            <div className="absolute bottom-4 right-4">
              <div className="bg-blue-600 text-white p-2 rounded-full shadow-lg">
                {MOCK_ORDER.storageUsed ? <Snowflake className="w-4 h-4" /> : <Package className="w-4 h-4" />}
              </div>
              <p className="text-xs font-medium mt-1 bg-white px-2 py-1 rounded shadow">
                {MOCK_ORDER.storageUsed ? t('storage', 'Storage') : t('buyer', 'Buyer')}
              </p>
            </div>
          </div>

          {/* ETA Info */}
          <div className="p-4 bg-gradient-to-r from-orange-50 to-amber-50 border-t border-orange-100">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Clock className="w-5 h-5 text-orange-600" />
                <div>
                  <p className="text-xs text-gray-600">{t('estimatedArrival', 'Estimated Arrival')}</p>
                  <p className="font-semibold text-gray-800">Today, 12:30 PM</p>
                </div>
              </div>
              <div className="text-right">
                <p className="text-xs text-gray-600">{t('distance', 'Distance')}</p>
                <p className="font-semibold text-gray-800">8.5 km</p>
              </div>
            </div>
          </div>
        </motion.div>

        {/* Timeline */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1 }}
          className="bg-white rounded-2xl p-4 shadow-sm border border-gray-100"
        >
          <h3 className="font-semibold text-gray-800 mb-4">{t('trackingTimeline', 'Tracking Timeline')}</h3>
          
          <div className="space-y-4">
            {getTimeline().map((step, index) => {
              const Icon = step.icon;
              const isLast = index === getTimeline().length - 1;
              
              return (
                <div key={step.id} className="flex gap-3">
                  {/* Icon */}
                  <div className="relative">
                    <div
                      className={`w-10 h-10 rounded-full flex items-center justify-center ${
                        step.status === 'completed'
                          ? 'bg-green-100 text-green-600'
                          : step.status === 'active'
                          ? 'bg-orange-100 text-orange-600'
                          : 'bg-gray-100 text-gray-400'
                      }`}
                    >
                      <Icon className="w-5 h-5" />
                    </div>
                    {!isLast && (
                      <div
                        className={`absolute left-5 top-10 w-0.5 h-8 ${
                          step.status === 'completed' ? 'bg-green-300' : 'bg-gray-200'
                        }`}
                      />
                    )}
                  </div>

                  {/* Content */}
                  <div className="flex-1 pb-4">
                    <p className="font-medium text-gray-800">{step.label}</p>
                    {step.timestamp && (
                      <p className="text-xs text-gray-500 mt-1">{step.timestamp}</p>
                    )}
                    {step.status === 'active' && (
                      <motion.div
                        initial={{ width: 0 }}
                        animate={{ width: '60%' }}
                        transition={{ duration: 2, repeat: Infinity }}
                        className="h-1 bg-orange-500 rounded-full mt-2"
                      />
                    )}
                  </div>
                </div>
              );
            })}
          </div>
        </motion.div>

        {/* Order Summary */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2 }}
          className="bg-white rounded-2xl p-4 shadow-sm border border-gray-100"
        >
          <h3 className="font-semibold text-gray-800 mb-3">{t('orderSummary', 'Order Summary')}</h3>
          
          <div className="grid grid-cols-2 gap-3">
            <div className="bg-gray-50 rounded-lg p-3">
              <p className="text-xs text-gray-500 mb-1">{t('produce', 'Produce')}</p>
              <p className="font-semibold text-gray-800">{MOCK_ORDER.cropName}</p>
              <Badge className="mt-1 text-xs bg-green-100 text-green-700">
                {t('grade', 'Grade')} {MOCK_ORDER.grade}
              </Badge>
            </div>
            <div className="bg-gray-50 rounded-lg p-3">
              <p className="text-xs text-gray-500 mb-1">{t('quantity', 'Quantity')}</p>
              <p className="font-semibold text-gray-800">{MOCK_ORDER.quantity} kg</p>
            </div>
            <div className="bg-gray-50 rounded-lg p-3">
              <p className="text-xs text-gray-500 mb-1">{t('buyer', 'Buyer')}</p>
              <div className="flex items-center gap-1">
                <p className="font-semibold text-gray-800 text-sm">{MOCK_ORDER.buyerName}</p>
                {MOCK_ORDER.buyerVerified && (
                  <BadgeCheck className="w-3 h-3 text-blue-500" />
                )}
              </div>
            </div>
            <div className="bg-gray-50 rounded-lg p-3">
              <p className="text-xs text-gray-500 mb-1">{t('transport', 'Transport')}</p>
              <p className="font-semibold text-gray-800 text-sm">{MOCK_ORDER.transportType}</p>
            </div>
          </div>
        </motion.div>

        {/* Transporter Info */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.3 }}
          className="bg-white rounded-2xl p-4 shadow-sm border border-gray-100"
        >
          <h3 className="font-semibold text-gray-800 mb-3">{t('transporterDetails', 'Transporter Details')}</h3>
          
          <div className="flex items-center gap-3 mb-4">
            <div className="w-12 h-12 bg-gradient-to-br from-[#1E7F43] to-[#15593A] rounded-full flex items-center justify-center text-white font-semibold">
              ZK
            </div>
            <div className="flex-1">
              <p className="font-semibold text-gray-800">{TRANSPORTER.name}</p>
              <div className="flex items-center gap-2 mt-1">
                <Star className="w-3 h-3 fill-yellow-400 text-yellow-400" />
                <span className="text-xs font-medium">{TRANSPORTER.rating}</span>
                <span className="text-xs text-gray-500">• {TRANSPORTER.vehicleNumber}</span>
              </div>
            </div>
          </div>

          <div className="flex gap-2">
            <Button className="flex-1 bg-[#1E7F43] hover:bg-[#15593A]">
              <Phone className="w-4 h-4 mr-2" />
              {t('call', 'Call')}
            </Button>
            <Button variant="outline" className="flex-1">
              <MessageCircle className="w-4 h-4 mr-2" />
              {t('chat', 'Chat')}
            </Button>
          </div>
        </motion.div>

        {/* Storage Status (Conditional) */}
        {MOCK_ORDER.storageUsed && (
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.4 }}
            className="bg-gradient-to-br from-cyan-50 to-blue-50 rounded-2xl p-4 border border-cyan-200"
          >
            <div className="flex items-center gap-2 mb-3">
              <Snowflake className="w-5 h-5 text-cyan-600" />
              <h3 className="font-semibold text-gray-800">{t('coldStorageStatus', 'Cold Storage Status')}</h3>
            </div>

            <div className="space-y-3">
              <div className="bg-white rounded-lg p-3">
                <p className="text-xs text-gray-600 mb-1">{t('facility', 'Facility')}</p>
                <p className="font-semibold text-gray-800">{MOCK_ORDER.storageFacility}</p>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div className="bg-white rounded-lg p-3">
                  <p className="text-xs text-gray-600 mb-1">{t('temperature', 'Temperature')}</p>
                  <div className="flex items-center gap-1">
                    <Thermometer className="w-4 h-4 text-cyan-600" />
                    <p className="font-semibold text-gray-800">{MOCK_ORDER.temperature}</p>
                  </div>
                </div>
                <div className="bg-white rounded-lg p-3">
                  <p className="text-xs text-gray-600 mb-1">{t('remaining', 'Remaining')}</p>
                  <p className="font-semibold text-gray-800 text-sm">{MOCK_ORDER.storageRemaining}</p>
                </div>
              </div>

              <div className="bg-cyan-100 rounded-lg p-3">
                <div className="flex items-start gap-2">
                  <AlertCircle className="w-4 h-4 text-cyan-700 flex-shrink-0 mt-0.5" />
                  <p className="text-xs text-cyan-900">
                    {t('optimalConditions', 'Your produce is stored under optimal conditions.')}
                  </p>
                </div>
              </div>
            </div>
          </motion.div>
        )}

        {/* AgriTag Section */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.5 }}
          className="bg-gradient-to-br from-purple-50 to-indigo-50 rounded-2xl p-4 border border-purple-200"
        >
          <div className="flex items-center justify-between mb-3">
            <div className="flex items-center gap-2">
              <QrCode className="w-5 h-5 text-purple-600" />
              <h3 className="font-semibold text-gray-800">{t('agriTag', 'AgriTag')}</h3>
            </div>
            <Button
              variant="outline"
              size="sm"
              onClick={() => setShowQR(true)}
            >
              {t('view', 'View')}
            </Button>
          </div>

          <div className="space-y-2">
            <div className="flex items-center gap-2 text-sm text-gray-700">
              <CheckCircle2 className="w-4 h-4 text-green-600" />
              {t('traceabilityEnabled', 'Produce traceability enabled')}
            </div>
            <div className="flex items-center gap-2 text-sm text-gray-700">
              <CheckCircle2 className="w-4 h-4 text-green-600" />
              {t('historyLinked', 'Buyer & storage history linked')}
            </div>
          </div>

          <div className="flex gap-2 mt-3">
            <Button variant="outline" size="sm" className="flex-1">
              <Download className="w-3 h-3 mr-1" />
              {t('download', 'Download')}
            </Button>
            <Button variant="outline" size="sm" className="flex-1">
              <Share2 className="w-3 h-3 mr-1" />
              {t('share', 'Share')}
            </Button>
          </div>
        </motion.div>

        {/* Payment Status */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.6 }}
          className="bg-white rounded-2xl p-4 shadow-sm border border-gray-100"
        >
          <h3 className="font-semibold text-gray-800 mb-3 flex items-center gap-2">
            <DollarSign className="w-5 h-5 text-green-600" />
            {t('paymentStatus', 'Payment Status')}
          </h3>

          <div className="space-y-3">
            <div className="flex items-center gap-3">
              <CheckCircle2 className="w-5 h-5 text-green-600" />
              <div className="flex-1">
                <p className="text-sm font-medium text-gray-800">{t('paymentInitiated', 'Payment Initiated')}</p>
                <p className="text-xs text-gray-500">{t('fundsInEscrow', 'Funds held in escrow')}</p>
              </div>
            </div>

            <div className="flex items-center gap-3 opacity-50">
              <Clock className="w-5 h-5 text-gray-400" />
              <div className="flex-1">
                <p className="text-sm font-medium text-gray-600">{t('deliveryConfirmation', 'Delivery Confirmation')}</p>
                <p className="text-xs text-gray-500">{t('pendingDelivery', 'Pending delivery')}</p>
              </div>
            </div>

            <div className="flex items-center gap-3 opacity-50">
              <Clock className="w-5 h-5 text-gray-400" />
              <div className="flex-1">
                <p className="text-sm font-medium text-gray-600">{t('paymentReleased', 'Payment Released')}</p>
                <p className="text-xs text-gray-500">{t('afterConfirmation', 'After confirmation')}</p>
              </div>
            </div>

            <div className="bg-green-50 rounded-lg p-3 border border-green-200 mt-3">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-xs text-gray-600">{t('expectedEarnings', 'Expected Earnings')}</p>
                  <p className="text-xl font-bold text-green-600">₨{MOCK_ORDER.netEarnings.toLocaleString()}</p>
                </div>
                <BadgeCheck className="w-8 h-8 text-green-600" />
              </div>
            </div>
          </div>
        </motion.div>

        {/* Notifications */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.7 }}
          className="bg-amber-50 rounded-xl p-3 border border-amber-200"
        >
          <div className="flex items-start gap-2">
            <AlertCircle className="w-5 h-5 text-amber-600 flex-shrink-0 mt-0.5" />
            <div>
              <p className="text-sm font-medium text-amber-900">{t('recentUpdate', 'Recent Update')}</p>
              <p className="text-xs text-amber-800 mt-1">
                {t('updateMessage', 'Transport vehicle is 15 minutes away from storage facility.')}
              </p>
            </div>
          </div>
        </motion.div>
      </div>

      {/* Bottom Action (When Delivered) */}
      {MOCK_ORDER.status === 'delivered' && (
        <div className="fixed bottom-0 left-0 right-0 bg-white border-t border-gray-200 p-4 shadow-lg">
          <Button
            onClick={() => setShowConfirmDelivery(true)}
            className="w-full bg-[#1E7F43] hover:bg-[#15593A] text-white"
            size="lg"
          >
            <CheckCircle2 className="w-5 h-5 mr-2" />
            {t('confirmDelivery', 'Confirm Delivery')}
          </Button>
        </div>
      )}

      {/* QR Code Dialog */}
      <Dialog open={showQR} onOpenChange={setShowQR}>
        <DialogContent className="max-w-sm">
          <DialogHeader>
            <DialogTitle>{t('agriTag', 'AgriTag QR Code')}</DialogTitle>
            <DialogDescription>
              {t('scanQR', 'Scan to view complete produce history')}
            </DialogDescription>
          </DialogHeader>
          <div className="flex flex-col items-center py-6">
            <div className="w-48 h-48 bg-gray-100 rounded-lg flex items-center justify-center">
              <QrCode className="w-32 h-32 text-gray-400" />
            </div>
            <p className="text-sm text-gray-600 mt-4">
              {t('agriTagId', 'AgriTag ID')}: #{MOCK_ORDER.orderId}
            </p>
          </div>
        </DialogContent>
      </Dialog>

      {/* Confirm Delivery Dialog */}
      <Dialog open={showConfirmDelivery} onOpenChange={setShowConfirmDelivery}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <CheckCircle2 className="w-6 h-6 text-green-600" />
              {t('confirmDelivery', 'Confirm Delivery')}
            </DialogTitle>
            <DialogDescription>
              {t('confirmDeliveryMessage', 'By confirming, payment will be released to your account within 24 hours.')}
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4 py-4">
            <div className="bg-green-50 rounded-lg p-4 border border-green-200">
              <p className="text-sm text-gray-700 mb-2">{t('paymentToBeReleased', 'Payment to be released:')}</p>
              <p className="text-3xl font-bold text-green-600">₨{MOCK_ORDER.netEarnings.toLocaleString()}</p>
            </div>
            <div className="flex gap-3">
              <Button
                variant="outline"
                onClick={() => setShowConfirmDelivery(false)}
                className="flex-1"
              >
                {t('cancel', 'Cancel')}
              </Button>
              <Button
                onClick={confirmDelivery}
                className="flex-1 bg-[#1E7F43] hover:bg-[#15593A]"
              >
                {t('confirm', 'Confirm')}
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}
