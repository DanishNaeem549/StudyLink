import { useState } from 'react';
import BuyerOffers from './BuyerOffers';
import OrderConfirmation from './OrderConfirmation';
import OrderTracking from './OrderTracking';
import { ArrowLeft } from 'lucide-react';
import { Button } from '../ui/button';

type MarketplaceStep = 'offers' | 'confirmation' | 'tracking';

interface MarketplaceDemoProps {
  onClose?: () => void;
}

export default function MarketplaceDemo({ onClose }: MarketplaceDemoProps) {
  const [currentStep, setCurrentStep] = useState<MarketplaceStep>('offers');
  const [acceptedBidId, setAcceptedBidId] = useState<string | null>(null);

  const handleAcceptOffer = (bidId: string) => {
    setAcceptedBidId(bidId);
    setCurrentStep('confirmation');
  };

  const handleConfirmOrder = () => {
    setCurrentStep('tracking');
  };

  const handleBackFromOffers = () => {
    // Return to market module
    if (onClose) {
      onClose();
    }
  };

  const handleBackFromConfirmation = () => {
    setCurrentStep('offers');
  };

  const handleBackFromTracking = () => {
    setCurrentStep('confirmation');
  };

  return (
    <div className="min-h-screen">
      {currentStep === 'offers' && (
        <BuyerOffers
          onBack={handleBackFromOffers}
          onAcceptOffer={handleAcceptOffer}
        />
      )}

      {currentStep === 'confirmation' && (
        <OrderConfirmation
          onBack={handleBackFromConfirmation}
          onConfirm={handleConfirmOrder}
        />
      )}

      {currentStep === 'tracking' && (
        <OrderTracking onBack={handleBackFromTracking} />
      )}
    </div>
  );
}