import { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import {
  ArrowLeft,
  Edit3,
  TrendingUp,
  MapPin,
  Star,
  CheckCircle2,
  MessageCircle,
  User,
  Truck,
  Home,
  Sparkles,
  Award,
  ShieldCheck,
  ChevronRight,
  BadgeCheck
} from 'lucide-react';
import { Button } from '../ui/button';
import { Badge } from '../ui/badge';
import { useLanguage } from '../../contexts/LanguageContext';
import {
  Sheet,
  SheetContent,
  SheetDescription,
  SheetHeader,
  SheetTitle,
} from '../ui/sheet';

interface Bid {
  id: string;
  buyerName: string;
  buyerCompany: string;
  pricePerKg: number;
  totalValue: number;
  distance: number;
  deliveryType: 'pickup' | 'delivery';
  rating: number;
  reviewCount: number;
  verified: boolean;
  status: 'best' | 'market' | 'trusted' | 'default';
  avatar?: string;
}

interface ProduceDetails {
  cropName: string;
  quantity: number;
  grade: 'A' | 'B' | 'C';
  expectedPriceMin: number;
  expectedPriceMax: number;
}

const MOCK_PRODUCE: ProduceDetails = {
  cropName: 'Tomato',
  quantity: 500,
  grade: 'A',
  expectedPriceMin: 45,
  expectedPriceMax: 55,
};

const MOCK_BIDS: Bid[] = [
  {
    id: '1',
    buyerName: 'Karachi Fresh Foods',
    buyerCompany: 'KFF Traders',
    pricePerKg: 58,
    totalValue: 29000,
    distance: 12,
    deliveryType: 'pickup',
    rating: 4.8,
    reviewCount: 234,
    verified: true,
    status: 'best',
    avatar: 'KF',
  },
  {
    id: '2',
    buyerName: 'Metro Wholesale',
    buyerCompany: 'Metro Markets',
    pricePerKg: 54,
    totalValue: 27000,
    distance: 8,
    deliveryType: 'pickup',
    rating: 4.7,
    reviewCount: 456,
    verified: true,
    status: 'trusted',
    avatar: 'MW',
  },
  {
    id: '3',
    buyerName: 'Al-Madina Traders',
    buyerCompany: 'AMD Trading Co.',
    pricePerKg: 52,
    totalValue: 26000,
    distance: 15,
    deliveryType: 'delivery',
    rating: 4.5,
    reviewCount: 189,
    verified: true,
    status: 'market',
    avatar: 'AM',
  },
  {
    id: '4',
    buyerName: 'Green Valley Exports',
    buyerCompany: 'GV Export House',
    pricePerKg: 50,
    totalValue: 25000,
    distance: 25,
    deliveryType: 'pickup',
    rating: 4.6,
    reviewCount: 312,
    verified: false,
    status: 'default',
    avatar: 'GV',
  },
];

interface BuyerOffersProps {
  onBack: () => void;
  onAcceptOffer: (bidId: string) => void;
}

export default function BuyerOffers({ onBack, onAcceptOffer }: BuyerOffersProps) {
  const [selectedBid, setSelectedBid] = useState<Bid | null>(null);
  const [showConfirmation, setShowConfirmation] = useState(false);
  const { language, t } = useLanguage();

  const getGradeColor = (grade: string) => {
    switch (grade) {
      case 'A': return 'bg-green-100 text-green-700 border-green-300';
      case 'B': return 'bg-yellow-100 text-yellow-700 border-yellow-300';
      case 'C': return 'bg-orange-100 text-orange-700 border-orange-300';
      default: return 'bg-gray-100 text-gray-700 border-gray-300';
    }
  };

  const getStatusBadge = (status: string) => {
    switch (status) {
      case 'best':
        return (
          <Badge className="bg-green-500 text-white border-0">
            <TrendingUp className="w-3 h-3 mr-1" />
            {t('bestPrice', 'Best Price')}
          </Badge>
        );
      case 'market':
        return (
          <Badge className="bg-yellow-500 text-white border-0">
            {t('marketRate', 'Near Market Rate')}
          </Badge>
        );
      case 'trusted':
        return (
          <Badge className="bg-blue-500 text-white border-0">
            <ShieldCheck className="w-3 h-3 mr-1" />
            {t('trustedBuyer', 'Trusted Buyer')}
          </Badge>
        );
      default:
        return null;
    }
  };

  const handleAcceptOffer = (bid: Bid) => {
    setSelectedBid(bid);
    setShowConfirmation(true);
  };

  const confirmAcceptance = () => {
    if (selectedBid) {
      onAcceptOffer(selectedBid.id);
      setShowConfirmation(false);
    }
  };

  const platformFee = selectedBid ? selectedBid.totalValue * 0.03 : 0;
  const netEarnings = selectedBid ? selectedBid.totalValue - platformFee : 0;

  return (
    <div className="min-h-screen bg-gradient-to-b from-[#F5F9F5] to-white">
      {/* Header */}
      <div className="bg-gradient-to-r from-[#1E7F43] to-[#15593A] text-white p-4 pb-6">
        <div className="flex items-center gap-3 mb-4">
          <button
            onClick={onBack}
            className="p-2 hover:bg-white/20 rounded-full transition"
          >
            <ArrowLeft className="w-5 h-5" />
          </button>
          <div className="flex-1">
            <h1 className="text-xl font-semibold">{t('buyerOffers', 'Buyer Offers')}</h1>
            <p className="text-sm text-white/80">
              {t('compareBids', 'Compare bids and choose the best price')}
            </p>
          </div>
        </div>

        {/* Progress Indicator */}
        <div className="space-y-2">
          <div className="flex justify-between text-xs">
            <span>{t('step', 'Step')} 2 {t('of', 'of')} 3</span>
            <span>66%</span>
          </div>
          <div className="h-1.5 bg-white/20 rounded-full overflow-hidden">
            <motion.div
              initial={{ width: '33%' }}
              animate={{ width: '66%' }}
              transition={{ duration: 0.5 }}
              className="h-full bg-white rounded-full"
            />
          </div>
        </div>
      </div>

      <div className="p-4 space-y-4 pb-24">
        {/* Produce Summary Card */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="bg-white rounded-2xl p-4 shadow-sm border border-gray-100"
          style={{
            backgroundImage: 'url("data:image/svg+xml,%3Csvg width=\'100\' height=\'100\' xmlns=\'http://www.w3.org/2000/svg\'%3E%3Cpath d=\'M10 10h80v80H10z\' fill=\'%231E7F43\' opacity=\'0.02\'/%3E%3C/svg%3E")',
          }}
        >
          <div className="flex items-start justify-between mb-3">
            <div className="flex-1">
              <div className="flex items-center gap-2 mb-2">
                <h2 className="text-lg font-semibold text-gray-800">
                  {MOCK_PRODUCE.cropName}
                </h2>
                <Badge className={`${getGradeColor(MOCK_PRODUCE.grade)} border`}>
                  {t('grade', 'Grade')} {MOCK_PRODUCE.grade}
                </Badge>
              </div>
              <p className="text-sm text-gray-600">
                <span className="font-medium text-gray-800">{MOCK_PRODUCE.quantity} kg</span>
              </p>
              <p className="text-xs text-gray-500 mt-1">
                {t('expectedRange', 'Expected')}: ₨{MOCK_PRODUCE.expectedPriceMin}-{MOCK_PRODUCE.expectedPriceMax}/{t('kg', 'kg')}
              </p>
            </div>
            <button className="p-2 hover:bg-gray-100 rounded-full transition">
              <Edit3 className="w-4 h-4 text-gray-600" />
            </button>
          </div>
        </motion.div>

        {/* AI Hint Banner */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1 }}
          className="bg-gradient-to-r from-amber-50 to-yellow-50 rounded-xl p-3 border border-amber-200"
        >
          <div className="flex items-start gap-2">
            <Sparkles className="w-5 h-5 text-amber-600 flex-shrink-0 mt-0.5" />
            <div className="flex-1">
              <p className="text-sm text-amber-900">
                <span className="font-medium">💡 {t('aiInsight', 'AI Insight')}:</span>{' '}
                {t('aiHint', 'The best offer is 12% higher than today\'s mandi price!')}
              </p>
            </div>
          </div>
        </motion.div>

        {/* Bids Section */}
        <div className="space-y-3">
          <h3 className="text-sm font-semibold text-gray-700 px-1">
            {MOCK_BIDS.length} {t('activeBids', 'Active Bids')}
          </h3>

          {MOCK_BIDS.map((bid, index) => (
            <motion.div
              key={bid.id}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.1 + index * 0.05 }}
              className={`bg-white rounded-xl p-4 shadow-sm border-2 transition-all ${
                bid.status === 'best' ? 'border-green-300 shadow-green-100' : 'border-gray-100'
              }`}
            >
              {/* Status Badge */}
              {bid.status !== 'default' && (
                <div className="mb-3">
                  {getStatusBadge(bid.status)}
                </div>
              )}

              {/* Buyer Info */}
              <div className="flex items-start gap-3 mb-3">
                <div className="w-12 h-12 bg-gradient-to-br from-[#1E7F43] to-[#15593A] rounded-full flex items-center justify-center text-white font-semibold">
                  {bid.avatar}
                </div>
                <div className="flex-1">
                  <div className="flex items-center gap-2">
                    <h4 className="font-semibold text-gray-800">{bid.buyerName}</h4>
                    {bid.verified && (
                      <BadgeCheck className="w-4 h-4 text-blue-500" />
                    )}
                  </div>
                  <p className="text-xs text-gray-500">{bid.buyerCompany}</p>
                  <div className="flex items-center gap-3 mt-1">
                    <div className="flex items-center gap-1">
                      <Star className="w-3 h-3 fill-yellow-400 text-yellow-400" />
                      <span className="text-xs font-medium text-gray-700">{bid.rating}</span>
                      <span className="text-xs text-gray-400">({bid.reviewCount})</span>
                    </div>
                    <div className="flex items-center gap-1 text-xs text-gray-500">
                      <MapPin className="w-3 h-3" />
                      {bid.distance} km
                    </div>
                  </div>
                </div>
              </div>

              {/* Price Details */}
              <div className="bg-gray-50 rounded-lg p-3 mb-3">
                <div className="flex items-center justify-between mb-2">
                  <span className="text-sm text-gray-600">{t('pricePerKg', 'Price per kg')}</span>
                  <span className="text-lg font-bold text-[#1E7F43]">₨{bid.pricePerKg}</span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-sm text-gray-600">{t('totalOffer', 'Total Offer')}</span>
                  <span className="text-xl font-bold text-gray-800">₨{bid.totalValue.toLocaleString()}</span>
                </div>
              </div>

              {/* Delivery Type */}
              <div className="flex items-center gap-2 mb-3">
                {bid.deliveryType === 'pickup' ? (
                  <>
                    <Truck className="w-4 h-4 text-gray-600" />
                    <span className="text-sm text-gray-600">{t('buyerPickup', 'Buyer Pickup')}</span>
                  </>
                ) : (
                  <>
                    <Home className="w-4 h-4 text-gray-600" />
                    <span className="text-sm text-gray-600">{t('homeDelivery', 'Home Delivery')}</span>
                  </>
                )}
              </div>

              {/* Actions */}
              <div className="flex gap-2">
                <Button
                  onClick={() => handleAcceptOffer(bid)}
                  className="flex-1 bg-[#1E7F43] hover:bg-[#15593A] text-white"
                >
                  <CheckCircle2 className="w-4 h-4 mr-2" />
                  {t('acceptOffer', 'Accept Offer')}
                </Button>
                <Button
                  variant="outline"
                  size="icon"
                  className="border-gray-300"
                >
                  <MessageCircle className="w-4 h-4" />
                </Button>
              </div>

              {/* View Profile Link */}
              <button className="w-full mt-2 text-center text-xs text-gray-500 hover:text-[#1E7F43] transition flex items-center justify-center gap-1">
                <User className="w-3 h-3" />
                {t('viewProfile', 'View Buyer Profile')}
                <ChevronRight className="w-3 h-3" />
              </button>
            </motion.div>
          ))}
        </div>

        {/* Trust Section */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.4 }}
          className="bg-gradient-to-br from-blue-50 to-indigo-50 rounded-xl p-4 border border-blue-200"
        >
          <h4 className="font-semibold text-gray-800 mb-3 flex items-center gap-2">
            <ShieldCheck className="w-5 h-5 text-blue-600" />
            {t('trustTransparency', 'Trust & Transparency')}
          </h4>
          <div className="space-y-2">
            <div className="flex items-center gap-2 text-sm text-gray-700">
              <CheckCircle2 className="w-4 h-4 text-green-600" />
              {t('securedPayments', 'Payments secured by AgriVault')}
            </div>
            <div className="flex items-center gap-2 text-sm text-gray-700">
              <CheckCircle2 className="w-4 h-4 text-green-600" />
              {t('noMiddleman', 'No middleman involvement')}
            </div>
            <div className="flex items-center gap-2 text-sm text-gray-700">
              <CheckCircle2 className="w-4 h-4 text-green-600" />
              {t('digitalRecord', 'Digital record will be generated (AgriTag)')}
            </div>
          </div>
        </motion.div>
      </div>

      {/* Confirmation Bottom Sheet */}
      <Sheet open={showConfirmation} onOpenChange={setShowConfirmation}>
        <SheetContent side="bottom" className="rounded-t-3xl">
          <SheetHeader>
            <SheetTitle className="flex items-center gap-2">
              <CheckCircle2 className="w-6 h-6 text-green-600" />
              {t('confirmOffer', 'Confirm Offer')}
            </SheetTitle>
            <SheetDescription>
              {t('reviewFinalDetails', 'Review the final details before accepting')}
            </SheetDescription>
          </SheetHeader>

          {selectedBid && (
            <div className="mt-6 space-y-4">
              {/* Buyer Info */}
              <div className="bg-gray-50 rounded-lg p-3">
                <p className="text-xs text-gray-500 mb-1">{t('buyer', 'Buyer')}</p>
                <p className="font-semibold text-gray-800">{selectedBid.buyerName}</p>
              </div>

              {/* Earnings Breakdown */}
              <div className="border border-gray-200 rounded-lg p-4">
                <h4 className="font-semibold text-gray-800 mb-3">{t('earningsBreakdown', 'Earnings Breakdown')}</h4>
                <div className="space-y-2">
                  <div className="flex justify-between text-sm">
                    <span className="text-gray-600">{t('grossAmount', 'Gross Amount')}</span>
                    <span className="font-medium">₨{selectedBid.totalValue.toLocaleString()}</span>
                  </div>
                  <div className="flex justify-between text-sm">
                    <span className="text-gray-600">{t('platformFee', 'Platform Fee')} (3%)</span>
                    <span className="text-red-600">-₨{platformFee.toLocaleString()}</span>
                  </div>
                  <div className="border-t pt-2 mt-2">
                    <div className="flex justify-between">
                      <span className="font-semibold text-gray-800">{t('netEarnings', 'Net Earnings')}</span>
                      <span className="text-xl font-bold text-green-600">₨{netEarnings.toLocaleString()}</span>
                    </div>
                  </div>
                </div>
              </div>

              {/* Actions */}
              <div className="flex gap-3">
                <Button
                  variant="outline"
                  onClick={() => setShowConfirmation(false)}
                  className="flex-1"
                >
                  {t('cancel', 'Cancel')}
                </Button>
                <Button
                  onClick={confirmAcceptance}
                  className="flex-1 bg-[#1E7F43] hover:bg-[#15593A]"
                >
                  {t('confirmAccept', 'Confirm & Accept')}
                </Button>
              </div>
            </div>
          )}
        </SheetContent>
      </Sheet>
    </div>
  );
}
