import { useState } from 'react';
import { motion } from 'motion/react';
import {
  ArrowLeft,
  CheckCircle2,
  Truck,
  Users,
  Home,
  Warehouse,
  Calendar,
  Clock,
  MapPin,
  BadgeCheck,
  Star,
  QrCode,
  Download,
  Share2,
  Shield,
  Lock,
  Sparkles,
  Info,
  ChevronRight,
  Snowflake
} from 'lucide-react';
import { Button } from '../ui/button';
import { Badge } from '../ui/badge';
import { useLanguage } from '../../contexts/LanguageContext';
import { Switch } from '../ui/switch';
import { RadioGroup, RadioGroupItem } from '../ui/radio-group';
import { Label } from '../ui/label';

interface AcceptedOffer {
  buyerName: string;
  buyerCompany: string;
  verified: boolean;
  rating: number;
  distance: number;
  cropName: string;
  grade: string;
  quantity: number;
  pricePerKg: number;
  totalValue: number;
}

interface TransportOption {
  id: string;
  name: string;
  type: 'agrivault' | 'pooled' | 'buyer' | 'self';
  cost: number;
  pickupTime: string;
  route: string;
  icon: any;
}

interface StorageFacility {
  id: string;
  name: string;
  pricePerDay: number;
  capacity: string;
  distance: number;
  temperature: string;
}

const MOCK_OFFER: AcceptedOffer = {
  buyerName: 'Karachi Fresh Foods',
  buyerCompany: 'KFF Traders',
  verified: true,
  rating: 4.8,
  distance: 12,
  cropName: 'Tomato',
  grade: 'A',
  quantity: 500,
  pricePerKg: 58,
  totalValue: 29000,
};

const TRANSPORT_OPTIONS: TransportOption[] = [
  {
    id: '1',
    name: 'AgriVault Transport',
    type: 'agrivault',
    cost: 800,
    pickupTime: 'Today, 2:00 PM',
    route: 'Direct route, 45 mins',
    icon: Truck,
  },
  {
    id: '2',
    name: 'Shared Transport Pool',
    type: 'pooled',
    cost: 450,
    pickupTime: 'Tomorrow, 8:00 AM',
    route: 'Multi-stop, 2 hours',
    icon: Users,
  },
  {
    id: '3',
    name: 'Buyer Pickup',
    type: 'buyer',
    cost: 0,
    pickupTime: 'Tomorrow, 10:00 AM',
    route: 'Buyer arranged',
    icon: Home,
  },
];

const STORAGE_FACILITIES: StorageFacility[] = [
  {
    id: '1',
    name: 'FreshKeep Cold Storage',
    pricePerDay: 150,
    capacity: 'Available: 2 tons',
    distance: 3,
    temperature: '2-4°C',
  },
  {
    id: '2',
    name: 'AgriCool Storage Hub',
    pricePerDay: 120,
    capacity: 'Available: 1.5 tons',
    distance: 7,
    temperature: '2-4°C',
  },
];

interface OrderConfirmationProps {
  onBack: () => void;
  onConfirm: () => void;
}

export default function OrderConfirmation({ onBack, onConfirm }: OrderConfirmationProps) {
  const [selectedTransport, setSelectedTransport] = useState<string>('1');
  const [useStorage, setUseStorage] = useState(false);
  const [selectedStorage, setSelectedStorage] = useState<string>('1');
  const [storageDuration, setStorageDuration] = useState(3);
  const { language, t } = useLanguage();

  const transportCost = TRANSPORT_OPTIONS.find(t => t.id === selectedTransport)?.cost || 0;
  const storageCost = useStorage ? (STORAGE_FACILITIES.find(s => s.id === selectedStorage)?.pricePerDay || 0) * storageDuration : 0;
  const platformFee = MOCK_OFFER.totalValue * 0.03;
  const totalDeductions = transportCost + storageCost + platformFee;
  const netEarnings = MOCK_OFFER.totalValue - totalDeductions;
  const profitIncrease = useStorage ? 18 : 0;

  return (
    <div className="min-h-screen bg-gradient-to-b from-[#F5F9F5] to-white pb-24">
      {/* Header */}
      <div className="bg-gradient-to-r from-[#1E7F43] to-[#15593A] text-white p-4 pb-6">
        <div className="flex items-center gap-3 mb-4">
          <button
            onClick={onBack}
            className="p-2 hover:bg-white/20 rounded-full transition"
          >
            <ArrowLeft className="w-5 h-5" />
          </button>
          <div className="flex-1">
            <h1 className="text-xl font-semibold">{t('orderConfirmation', 'Order Confirmation & Logistics')}</h1>
            <p className="text-sm text-white/80">
              {t('reviewConfirmMove', 'Review, confirm, and move your produce safely')}
            </p>
          </div>
        </div>

        {/* Progress Indicator */}
        <div className="space-y-2">
          <div className="flex justify-between text-xs">
            <span>{t('step', 'Step')} 3 {t('of', 'of')} 3</span>
            <span>100%</span>
          </div>
          <div className="h-1.5 bg-white/20 rounded-full overflow-hidden">
            <motion.div
              initial={{ width: '66%' }}
              animate={{ width: '100%' }}
              transition={{ duration: 0.5 }}
              className="h-full bg-white rounded-full"
            />
          </div>
        </div>
      </div>

      <div className="p-4 space-y-4">
        {/* Accepted Offer Summary */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="bg-gradient-to-br from-green-50 to-emerald-50 rounded-2xl p-4 border-2 border-green-200"
        >
          <div className="flex items-center gap-2 mb-3">
            <CheckCircle2 className="w-6 h-6 text-green-600" />
            <h2 className="text-lg font-semibold text-gray-800">{t('offerAccepted', 'Offer Accepted')}</h2>
          </div>

          <div className="flex items-start gap-3 mb-4">
            <div className="w-12 h-12 bg-gradient-to-br from-[#1E7F43] to-[#15593A] rounded-full flex items-center justify-center text-white font-semibold">
              KF
            </div>
            <div className="flex-1">
              <div className="flex items-center gap-2">
                <h4 className="font-semibold text-gray-800">{MOCK_OFFER.buyerName}</h4>
                {MOCK_OFFER.verified && (
                  <BadgeCheck className="w-4 h-4 text-blue-500" />
                )}
              </div>
              <p className="text-xs text-gray-600">{MOCK_OFFER.buyerCompany}</p>
              <div className="flex items-center gap-2 mt-1">
                <Star className="w-3 h-3 fill-yellow-400 text-yellow-400" />
                <span className="text-xs font-medium">{MOCK_OFFER.rating}</span>
                <span className="text-xs text-gray-500">•</span>
                <MapPin className="w-3 h-3 text-gray-500" />
                <span className="text-xs text-gray-500">{MOCK_OFFER.distance} km</span>
              </div>
            </div>
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div className="bg-white rounded-lg p-3">
              <p className="text-xs text-gray-500">{t('produce', 'Produce')}</p>
              <p className="font-semibold text-gray-800">{MOCK_OFFER.cropName}</p>
              <Badge className="mt-1 text-xs bg-green-100 text-green-700">
                {t('grade', 'Grade')} {MOCK_OFFER.grade}
              </Badge>
            </div>
            <div className="bg-white rounded-lg p-3">
              <p className="text-xs text-gray-500">{t('quantity', 'Quantity')}</p>
              <p className="font-semibold text-gray-800">{MOCK_OFFER.quantity} kg</p>
            </div>
            <div className="bg-white rounded-lg p-3">
              <p className="text-xs text-gray-500">{t('pricePerKg', 'Price/kg')}</p>
              <p className="font-semibold text-[#1E7F43]">₨{MOCK_OFFER.pricePerKg}</p>
            </div>
            <div className="bg-white rounded-lg p-3">
              <p className="text-xs text-gray-500">{t('totalValue', 'Total Value')}</p>
              <p className="font-semibold text-gray-800">₨{MOCK_OFFER.totalValue.toLocaleString()}</p>
            </div>
          </div>
        </motion.div>

        {/* Transport Options */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1 }}
          className="bg-white rounded-2xl p-4 shadow-sm border border-gray-100"
        >
          <h3 className="font-semibold text-gray-800 mb-3 flex items-center gap-2">
            <Truck className="w-5 h-5 text-[#1E7F43]" />
            {t('selectTransport', 'Select Transport')}
          </h3>

          <RadioGroup value={selectedTransport} onValueChange={setSelectedTransport}>
            <div className="space-y-3">
              {TRANSPORT_OPTIONS.map((option) => {
                const Icon = option.icon;
                return (
                  <div
                    key={option.id}
                    className={`border-2 rounded-xl p-3 cursor-pointer transition ${
                      selectedTransport === option.id
                        ? 'border-[#1E7F43] bg-green-50'
                        : 'border-gray-200 hover:border-gray-300'
                    }`}
                    onClick={() => setSelectedTransport(option.id)}
                  >
                    <div className="flex items-start gap-3">
                      <RadioGroupItem value={option.id} id={option.id} className="mt-1" />
                      <div className="flex-1">
                        <div className="flex items-center gap-2 mb-1">
                          <Icon className="w-4 h-4 text-gray-600" />
                          <Label htmlFor={option.id} className="font-medium text-gray-800 cursor-pointer">
                            {option.name}
                          </Label>
                        </div>
                        <div className="text-xs text-gray-600 space-y-1">
                          <div className="flex items-center gap-2">
                            <Clock className="w-3 h-3" />
                            <span>{option.pickupTime}</span>
                          </div>
                          <div className="flex items-center gap-2">
                            <MapPin className="w-3 h-3" />
                            <span>{option.route}</span>
                          </div>
                        </div>
                        <div className="mt-2">
                          {option.cost === 0 ? (
                            <Badge className="bg-blue-100 text-blue-700">{t('free', 'Free')}</Badge>
                          ) : (
                            <span className="text-sm font-semibold text-[#1E7F43]">₨{option.cost}</span>
                          )}
                        </div>
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          </RadioGroup>
        </motion.div>

        {/* Cold Storage Option */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2 }}
          className="bg-white rounded-2xl p-4 shadow-sm border border-gray-100"
        >
          <div className="flex items-center justify-between mb-3">
            <h3 className="font-semibold text-gray-800 flex items-center gap-2">
              <Snowflake className="w-5 h-5 text-blue-500" />
              {t('coldStorage', 'Cold Storage')}
            </h3>
            <Switch checked={useStorage} onCheckedChange={setUseStorage} />
          </div>

          {useStorage && (
            <motion.div
              initial={{ opacity: 0, height: 0 }}
              animate={{ opacity: 1, height: 'auto' }}
              className="space-y-3"
            >
              {/* AI Tip */}
              <div className="bg-gradient-to-r from-amber-50 to-yellow-50 rounded-lg p-3 border border-amber-200">
                <div className="flex items-start gap-2">
                  <Sparkles className="w-4 h-4 text-amber-600 flex-shrink-0 mt-0.5" />
                  <p className="text-xs text-amber-900">
                    <span className="font-medium">💡 {t('aiTip', 'AI Tip')}:</span>{' '}
                    {t('storageProfit', 'Using cold storage increased your expected profit by')} {profitIncrease}%
                  </p>
                </div>
              </div>

              {/* Storage Facilities */}
              <RadioGroup value={selectedStorage} onValueChange={setSelectedStorage}>
                {STORAGE_FACILITIES.map((facility) => (
                  <div
                    key={facility.id}
                    className={`border-2 rounded-lg p-3 cursor-pointer transition ${
                      selectedStorage === facility.id
                        ? 'border-blue-500 bg-blue-50'
                        : 'border-gray-200 hover:border-gray-300'
                    }`}
                    onClick={() => setSelectedStorage(facility.id)}
                  >
                    <div className="flex items-start gap-3">
                      <RadioGroupItem value={facility.id} id={facility.id} className="mt-1" />
                      <div className="flex-1">
                        <Label htmlFor={facility.id} className="font-medium text-gray-800 cursor-pointer">
                          {facility.name}
                        </Label>
                        <div className="text-xs text-gray-600 space-y-1 mt-1">
                          <div className="flex items-center justify-between">
                            <span>{facility.capacity}</span>
                            <Badge variant="outline" className="text-xs">
                              <MapPin className="w-3 h-3 mr-1" />
                              {facility.distance} km
                            </Badge>
                          </div>
                          <div className="flex items-center gap-2">
                            <Snowflake className="w-3 h-3 text-blue-500" />
                            <span>{facility.temperature}</span>
                          </div>
                          <div className="font-semibold text-blue-600 mt-2">
                            ₨{facility.pricePerDay}/{t('day', 'day')}
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                ))}
              </RadioGroup>

              {/* Storage Duration */}
              <div className="bg-gray-50 rounded-lg p-3">
                <Label className="text-sm font-medium text-gray-700 mb-2 block">
                  {t('storageDuration', 'Storage Duration')}: {storageDuration} {t('days', 'days')}
                </Label>
                <input
                  type="range"
                  min="1"
                  max="14"
                  value={storageDuration}
                  onChange={(e) => setStorageDuration(Number(e.target.value))}
                  className="w-full"
                />
                <div className="flex justify-between text-xs text-gray-500 mt-1">
                  <span>1 {t('day', 'day')}</span>
                  <span>14 {t('days', 'days')}</span>
                </div>
              </div>
            </motion.div>
          )}
        </motion.div>

        {/* Earnings Breakdown */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.3 }}
          className="bg-white rounded-2xl p-4 shadow-sm border-2 border-gray-200"
        >
          <h3 className="font-semibold text-gray-800 mb-3">{t('earningsBreakdown', 'Earnings Breakdown')}</h3>
          <div className="space-y-2">
            <div className="flex justify-between text-sm">
              <span className="text-gray-600">{t('grossSale', 'Gross Sale Amount')}</span>
              <span className="font-medium">₨{MOCK_OFFER.totalValue.toLocaleString()}</span>
            </div>
            {transportCost > 0 && (
              <div className="flex justify-between text-sm">
                <span className="text-gray-600">{t('transportCost', 'Transport Cost')}</span>
                <span className="text-red-600">-₨{transportCost}</span>
              </div>
            )}
            {useStorage && storageCost > 0 && (
              <div className="flex justify-between text-sm">
                <span className="text-gray-600">{t('storageCost', 'Storage Cost')} ({storageDuration} days)</span>
                <span className="text-red-600">-₨{storageCost}</span>
              </div>
            )}
            <div className="flex justify-between text-sm">
              <span className="text-gray-600">{t('platformFee', 'Platform Service Fee')} (3%)</span>
              <span className="text-red-600">-₨{platformFee.toFixed(0)}</span>
            </div>
            <div className="border-t-2 border-gray-200 pt-2 mt-2">
              <div className="flex justify-between items-center">
                <span className="font-semibold text-gray-800">{t('netEarnings', 'Net Earnings')}</span>
                <span className="text-2xl font-bold text-green-600">₨{netEarnings.toLocaleString()}</span>
              </div>
            </div>
          </div>
        </motion.div>

        {/* AgriTag Generation */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.4 }}
          className="bg-gradient-to-br from-purple-50 to-indigo-50 rounded-2xl p-4 border border-purple-200"
        >
          <div className="flex items-start gap-3 mb-3">
            <div className="w-12 h-12 bg-white rounded-lg flex items-center justify-center">
              <QrCode className="w-6 h-6 text-purple-600" />
            </div>
            <div className="flex-1">
              <h3 className="font-semibold text-gray-800">{t('agriTag', 'Digital Produce Profile (AgriTag)')}</h3>
              <p className="text-xs text-gray-600 mt-1">
                {t('digitalVerification', 'Your produce is now digitally verified')}
              </p>
            </div>
          </div>

          <div className="bg-white rounded-lg p-3 mb-3">
            <div className="flex items-center justify-center">
              <div className="w-32 h-32 bg-gray-100 rounded-lg flex items-center justify-center">
                <QrCode className="w-20 h-20 text-gray-400" />
              </div>
            </div>
            <p className="text-center text-xs text-gray-500 mt-2">
              {t('agriTagId', 'AgriTag ID')}: #AGV{Date.now().toString().slice(-8)}
            </p>
          </div>

          <div className="flex gap-2">
            <Button variant="outline" className="flex-1 text-xs" size="sm">
              <Download className="w-3 h-3 mr-1" />
              {t('download', 'Download')}
            </Button>
            <Button variant="outline" className="flex-1 text-xs" size="sm">
              <Share2 className="w-3 h-3 mr-1" />
              {t('share', 'Share')}
            </Button>
          </div>
        </motion.div>

        {/* Payment Security */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.5 }}
          className="bg-gradient-to-br from-blue-50 to-cyan-50 rounded-xl p-4 border border-blue-200"
        >
          <h4 className="font-semibold text-gray-800 mb-3 flex items-center gap-2">
            <Shield className="w-5 h-5 text-blue-600" />
            {t('paymentSecurity', 'Payment & Security')}
          </h4>
          <div className="space-y-2">
            <div className="flex items-center gap-2 text-sm text-gray-700">
              <Lock className="w-4 h-4 text-green-600" />
              {t('secureDigitalPayment', 'Secure digital payment')}
            </div>
            <div className="flex items-center gap-2 text-sm text-gray-700">
              <Lock className="w-4 h-4 text-green-600" />
              {t('escrowTransaction', 'Escrow-based transaction')}
            </div>
            <div className="flex items-center gap-2 text-sm text-gray-700">
              <Lock className="w-4 h-4 text-green-600" />
              {t('paymentAfterDelivery', 'Payment release after delivery confirmation')}
            </div>
            <div className="flex items-center gap-2 text-sm text-gray-700">
              <CheckCircle2 className="w-4 h-4 text-green-600" />
              {t('noMiddlemen', 'No middlemen involvement')}
            </div>
          </div>
        </motion.div>

        {/* Order Tracking Preview */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.6 }}
          className="bg-gray-50 rounded-xl p-4 border border-gray-200"
        >
          <div className="flex items-center justify-between">
            <div>
              <h4 className="font-medium text-gray-800">{t('nextSteps', 'Next Steps')}</h4>
              <p className="text-xs text-gray-600 mt-1">{t('liveTracking', 'Live tracking will be available')}</p>
            </div>
            <ChevronRight className="w-5 h-5 text-gray-400" />
          </div>
        </motion.div>
      </div>

      {/* Bottom Action Bar */}
      <div className="fixed bottom-0 left-0 right-0 bg-white border-t border-gray-200 p-4 shadow-lg">
        <div className="flex gap-3">
          <Button
            variant="outline"
            onClick={onBack}
            className="flex-1"
          >
            {t('cancel', 'Cancel Order')}
          </Button>
          <Button
            onClick={onConfirm}
            className="flex-1 bg-[#1E7F43] hover:bg-[#15593A] text-white"
          >
            <CheckCircle2 className="w-4 h-4 mr-2" />
            {t('confirmSchedule', 'Confirm & Schedule Pickup')}
          </Button>
        </div>
      </div>
    </div>
  );
}
