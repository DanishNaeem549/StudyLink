import { createContext, useContext, useState, useEffect, ReactNode } from 'react';

type Language = 'en' | 'ur';

interface LanguageContextType {
  language: Language;
  toggleLanguage: () => void;
  t: (key: string) => string;
  isRTL: boolean;
}

const LanguageContext = createContext<LanguageContextType | undefined>(undefined);

// Translation dictionary
const translations: Record<Language, Record<string, string>> = {
  en: {
    // Common
    'common.home': 'Home',
    'common.profile': 'Profile',
    'common.logout': 'Logout',
    'common.search': 'Search',
    'common.save': 'Save',
    'common.cancel': 'Cancel',
    'common.edit': 'Edit',
    'common.delete': 'Delete',
    'common.view': 'View',
    'common.back': 'Back',
    'common.next': 'Next',
    'common.submit': 'Submit',
    'common.loading': 'Loading...',
    
    // Dashboard
    'dashboard.welcome': 'Welcome back!',
    'dashboard.farmer': 'Farmer Dashboard',
    'dashboard.supplier': 'Supplier Dashboard',
    'dashboard.buyer': 'Buyer Dashboard',
    'dashboard.quickActions': 'Quick Actions',
    
    // AI Chat
    'ai.copilot': 'AI Copilot',
    'ai.assistant': 'AI Assistant',
    'ai.community': 'Community',
    'ai.listening': 'Listening...',
    'ai.speaking': 'Speaking...',
    'ai.tapToSpeak': 'Tap to speak',
    'ai.greeting': 'Hello! I\'m your AgriVault AI Copilot. How can I help you today?',
    'ai.askAnything': 'Ask me anything...',
    'ai.voiceInput': 'Voice Input',
    'ai.textInput': 'Text Input',
    'ai.playAudio': 'Play audio response',
    
    // Voice Features
    'voice.recordingOffline': 'Recording offline',
    'voice.savedLocally': 'Saved locally',
    'voice.uploadingWhenConnected': 'Uploading when connected',
    'voice.pressToRecord': 'Press and hold to record',
    'voice.releaseToSend': 'Release to send',
    'voice.swipeToCancel': 'Swipe to cancel',
    'voice.duration': 'Duration',
    'voice.play': 'Play',
    'voice.pause': 'Pause',
    
    // Products
    'products.myProducts': 'My Products',
    'products.addNew': 'Add New Product',
    'products.browse': 'Browse Products',
    'products.price': 'Price',
    'products.stock': 'Stock',
    'products.available': 'Available',
    
    // Orders
    'orders.myOrders': 'My Orders',
    'orders.activeOrders': 'Active Orders',
    'orders.viewAll': 'View All',
    'orders.orderDetail': 'Order Detail',
    'orders.status': 'Status',
    
    // Community
    'community.members': 'members',
    'community.reply': 'Reply',
    'community.report': 'Report',
    'community.guidelines': 'Community guidelines apply. Be respectful.',
    
    // Status
    'status.online': 'Online',
    'status.offline': 'Offline',
    'status.syncing': 'Syncing...',
  },
  ur: {
    // Common
    'common.home': 'ہوم',
    'common.profile': 'پروفائل',
    'common.logout': 'لاگ آؤٹ',
    'common.search': 'تلاش کریں',
    'common.save': 'محفوظ کریں',
    'common.cancel': 'منسوخ کریں',
    'common.edit': 'ترمیم',
    'common.delete': 'حذف کریں',
    'common.view': 'دیکھیں',
    'common.back': 'واپس',
    'common.next': 'اگلا',
    'common.submit': 'جمع کرائیں',
    'common.loading': 'لوڈ ہو رہا ہے...',
    
    // Dashboard
    'dashboard.welcome': 'خوش آمدید!',
    'dashboard.farmer': 'کسان ڈیش بورڈ',
    'dashboard.supplier': 'سپلائر ڈیش بورڈ',
    'dashboard.buyer': 'خریدار ڈیش بورڈ',
    'dashboard.quickActions': 'فوری اقدامات',
    
    // AI Chat
    'ai.copilot': 'اے آئی کوپائلٹ',
    'ai.assistant': 'اے آئی معاون',
    'ai.community': 'کمیونٹی',
    'ai.listening': 'سن رہا ہوں...',
    'ai.speaking': 'بول رہا ہوں...',
    'ai.tapToSpeak': 'بولنے کے لیے ٹیپ کریں',
    'ai.greeting': 'السلام علیکم! میں آپ کا ایگری والٹ اے آئی معاون ہوں۔ آج میں آپ کی کیسے مدد کر سکتا ہوں؟',
    'ai.askAnything': 'کچھ بھی پوچھیں...',
    'ai.voiceInput': 'آواز سے لکھیں',
    'ai.textInput': 'ٹائپ کریں',
    'ai.playAudio': 'آواز میں سنیں',
    
    // Voice Features
    'voice.recordingOffline': 'آف لائن ریکارڈنگ',
    'voice.savedLocally': 'محفوظ ہو گیا',
    'voice.uploadingWhenConnected': 'انٹرنیٹ ملنے پر بھیجا جائے گا',
    'voice.pressToRecord': 'دبا کر رکھیں اور بولیں',
    'voice.releaseToSend': 'چھوڑ کر بھیجیں',
    'voice.swipeToCancel': 'منسوخ کرنے کے لیے سوائپ کریں',
    'voice.duration': 'دورانیہ',
    'voice.play': 'چلائیں',
    'voice.pause': 'رکیں',
    
    // Products
    'products.myProducts': 'میری مصنوعات',
    'products.addNew': 'نیا اضافہ کریں',
    'products.browse': 'مصنوعات دیکھیں',
    'products.price': 'قیمت',
    'products.stock': 'اسٹاک',
    'products.available': 'دستیاب',
    
    // Orders
    'orders.myOrders': 'میرے آرڈرز',
    'orders.activeOrders': 'فعال آرڈرز',
    'orders.viewAll': 'سب دیکھیں',
    'orders.orderDetail': 'آرڈر کی تفصیل',
    'orders.status': 'حالت',
    
    // Community
    'community.members': 'ممبرز',
    'community.reply': 'جواب دیں',
    'community.report': 'رپورٹ کریں',
    'community.guidelines': 'کمیونٹی کے اصولوں پر عمل کریں۔ احترام سے بات کریں۔',
    
    // Status
    'status.online': 'آن لائن',
    'status.offline': 'آف لائن',
    'status.syncing': 'سنک ہو رہا ہے...',
  }
};

export function LanguageProvider({ children }: { children: ReactNode }) {
  const [language, setLanguage] = useState<Language>('en');

  // Load saved language preference
  useEffect(() => {
    const savedLanguage = localStorage.getItem('agrivault-language') as Language;
    if (savedLanguage && (savedLanguage === 'en' || savedLanguage === 'ur')) {
      setLanguage(savedLanguage);
    }
  }, []);

  // Save language preference and update document direction
  useEffect(() => {
    localStorage.setItem('agrivault-language', language);
    document.documentElement.dir = language === 'ur' ? 'rtl' : 'ltr';
    document.documentElement.lang = language === 'ur' ? 'ur' : 'en';
  }, [language]);

  const toggleLanguage = () => {
    setLanguage(prev => prev === 'en' ? 'ur' : 'en');
  };

  const t = (key: string): string => {
    return translations[language][key] || key;
  };

  const isRTL = language === 'ur';

  return (
    <LanguageContext.Provider value={{ language, toggleLanguage, t, isRTL }}>
      {children}
    </LanguageContext.Provider>
  );
}

export function useLanguage() {
  const context = useContext(LanguageContext);
  if (!context) {
    throw new Error('useLanguage must be used within LanguageProvider');
  }
  return context;
}
