import { useState, useEffect } from 'react';
import SplashScreen from './components/SplashScreen';
import RoleSelection from './components/RoleSelection';
import Login from './components/Login';
import FarmerDashboard from './components/farmer/FarmerDashboard';
import TransporterDashboard from './components/transporter/TransporterDashboard';
import StorageDashboard from './components/storage/StorageDashboard';
import ExpertDashboard from './components/expert/ExpertDashboard';
import AdminDashboard from './components/admin/AdminDashboard';
import SupplierDashboard from './components/supplier/SupplierDashboard';
import BuyerDashboard from './components/buyer/BuyerDashboard';
import AIChat from './components/AIChat';
import { LanguageProvider } from './contexts/LanguageContext';

export type UserRole = 'farmer' | 'transporter' | 'storage' | 'expert' | 'admin' | 'supplier' | 'buyer' | null;

function App() {
  const [screen, setScreen] = useState<'splash' | 'role' | 'login' | 'dashboard'>('splash');
  const [userRole, setUserRole] = useState<UserRole>(null);
  const [isChatOpen, setIsChatOpen] = useState(false);

  useEffect(() => {
    // Auto-transition from splash screen
    const timer = setTimeout(() => {
      setScreen('role');
    }, 2500);
    return () => clearTimeout(timer);
  }, []);

  const handleRoleSelect = (role: UserRole) => {
    setUserRole(role);
    setScreen('login');
  };

  const handleLogin = () => {
    setScreen('dashboard');
  };

  const handleLogout = () => {
    setUserRole(null);
    setScreen('role');
  };

  return (
    <LanguageProvider>
      <div className="min-h-screen bg-gray-50">
        {screen === 'splash' && <SplashScreen />}
        {screen === 'role' && <RoleSelection onSelectRole={handleRoleSelect} />}
        {screen === 'login' && <Login role={userRole} onLogin={handleLogin} />}
        {screen === 'dashboard' && userRole === 'farmer' && <FarmerDashboard onLogout={handleLogout} />}
        {screen === 'dashboard' && userRole === 'transporter' && <TransporterDashboard onLogout={handleLogout} />}
        {screen === 'dashboard' && userRole === 'storage' && <StorageDashboard onLogout={handleLogout} />}
        {screen === 'dashboard' && userRole === 'expert' && <ExpertDashboard onLogout={handleLogout} />}
        {screen === 'dashboard' && userRole === 'admin' && <AdminDashboard onLogout={handleLogout} />}
        {screen === 'dashboard' && userRole === 'supplier' && <SupplierDashboard onLogout={handleLogout} />}
        {screen === 'dashboard' && userRole === 'buyer' && <BuyerDashboard onLogout={handleLogout} />}
        
        {/* AI Chat Assistant - Available on dashboard screens */}
        {screen === 'dashboard' && (
          <AIChat 
            isOpen={isChatOpen} 
            onToggle={() => setIsChatOpen(!isChatOpen)}
            userRole={userRole}
          />
        )}
      </div>
    </LanguageProvider>
  );
}

export default App;